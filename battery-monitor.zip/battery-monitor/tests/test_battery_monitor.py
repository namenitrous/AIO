import base64
from datetime import datetime
import json
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from ajazz_mouse import (
    AjazzMouseController,
    build_battery_poll_packet,
    build_set_angle_snap_packet,
    build_set_dpi_table_packet,
    build_set_lod_packet,
    build_set_motion_sync_packet,
    build_set_option0_packet,
    build_set_poll_rate_packet,
    parse_battery_frame,
)
from ajazz_rgb import (
    AjazzRgbController,
    TFT_BLOCK_SIZE,
    TFT_FRAME_BYTES,
    build_dongle_clock_packet,
    build_dongle_lighting_packet,
    build_dongle_sleep_packet,
    build_rf_battery_query,
    build_tft_screen_blocks,
    build_wired_clock_sequence,
    build_wired_lighting_sequence,
    build_wired_sleep_sequence,
    parse_hex_color,
    parse_rf_battery_reply,
)
from battery_reader import (
    compute_current_amps,
    compute_health_percent,
    derive_status_label,
    read_battery_telemetry,
)
from electricity_report import ElectricityReportTracker, compute_live_power_breakdown
from power_metrics import (
    CpuPowerMonitor,
    GpuPowerMonitor,
    get_cpu_max_state,
    get_overlay_power_mode,
    get_power_plan_info,
    set_cpu_max_state,
    set_performance_profile,
)
from server import (
    StateStatsTracker,
    TelemetryStore,
    _is_instance_running,
    _make_handler,
    _pick_port,
    build_autostart_command,
    classify_power_state,
    compute_derived_power_metrics,
    get_autostart_status,
    set_autostart_enabled,
)
from system_specs import SystemSpecsCache, get_uptime_seconds
from http.server import ThreadingHTTPServer


class TestBatteryReader(unittest.TestCase):
    def test_compute_current_amps(self):
        self.assertAlmostEqual(compute_current_amps(32784, 16392), 2.0, places=3)
        self.assertAlmostEqual(compute_current_amps(-16392, 16392), -1.0, places=3)
        self.assertEqual(compute_current_amps(0, 16392), 0.0)
        self.assertIsNone(compute_current_amps(1000, 0))
        self.assertIsNone(compute_current_amps(None, 16392))

    def test_compute_health_percent(self):
        self.assertEqual(compute_health_percent(41811, 58751), 71.2)
        self.assertEqual(compute_health_percent(60000, 58751), 100.0)
        self.assertIsNone(compute_health_percent(None, 58751))
        self.assertIsNone(compute_health_percent(41811, 0))

    def test_derive_status_label(self):
        self.assertEqual(derive_status_label(False, False, False, False, False), "No battery detected")
        self.assertEqual(derive_status_label(True, True, True, False, False), "Charging")
        self.assertEqual(derive_status_label(True, False, False, True, False), "On battery")
        self.assertEqual(derive_status_label(True, True, False, False, False), "Plugged in, idle")
        self.assertEqual(derive_status_label(True, False, False, True, True), "Critically low")

    def test_derived_power_metrics(self):
        charge = compute_derived_power_metrics(
            {
                "rate_mw": 20000,
                "full_charge_mwh": 40000,
                "design_mwh": 50000,
                "remaining_mwh": 20000,
            }
        )
        self.assertEqual(charge["c_rate"], 0.5)
        self.assertEqual(charge["pct_per_hour"], 50.0)
        self.assertEqual(charge["time_to_full_sec"], 3600)
        self.assertIsNone(charge["calc_runtime_sec"])
        self.assertEqual(charge["wear_mwh"], 10000)
        self.assertEqual(charge["wear_percent"], 20.0)

        discharge = compute_derived_power_metrics(
            {
                "rate_mw": -10000,
                "full_charge_mwh": 40000,
                "design_mwh": 50000,
                "remaining_mwh": 20000,
            }
        )
        self.assertEqual(discharge["c_rate"], -0.25)
        self.assertEqual(discharge["pct_per_hour"], -25.0)
        self.assertEqual(discharge["calc_runtime_sec"], 7200)
        self.assertIsNone(discharge["time_to_full_sec"])

    def test_live_hardware_and_system_power_read(self):
        sample = read_battery_telemetry()
        self.assertTrue(sample.battery_present)
        self.assertIsNotNone(sample.voltage_mv)
        self.assertGreater(sample.voltage_mv, 0)
        self.assertIsNotNone(sample.percentage)

        plan, _ = get_power_plan_info(ac_online=sample.ac_online)
        self.assertTrue(bool(plan))

        cpu = CpuPowerMonitor()
        cpu.read()
        cpu_info = cpu.read()
        self.assertGreater(cpu_info["cpu_cores_logical"], 0)
        self.assertIsNotNone(cpu_info["cpu_current_mhz"])

        gpu = GpuPowerMonitor(enabled=True)
        gpu_info = gpu.read()
        self.assertIn("available", gpu_info)


class TestStateStats(unittest.TestCase):
    def test_classify_track_persist_and_events(self):
        with tempfile.TemporaryDirectory() as tmp:
            stats_file = Path(tmp) / "stats.json"
            tracker = StateStatsTracker(stats_path=stats_file)
            self.assertEqual(
                classify_power_state({"charging": True, "discharging": False, "rate_mw": 35000}),
                "charge",
            )
            self.assertEqual(
                classify_power_state({"charging": False, "discharging": False, "rate_mw": 0}),
                "idle",
            )
            self.assertEqual(
                classify_power_state({"charging": False, "discharging": True, "rate_mw": -18000}),
                "discharge",
            )

            tracker.record({"timestamp": 100.0, "ac_online": True, "charging": True, "discharging": False, "rate_mw": 36000, "power_w": 36.0, "current_a": 2.1, "voltage_v": 16.5, "c_rate": 0.9, "percentage": 80})
            tracker.record({"timestamp": 102.0, "ac_online": True, "charging": True, "discharging": False, "rate_mw": 36000, "power_w": 36.0, "current_a": 2.1, "voltage_v": 16.6, "c_rate": 0.9, "percentage": 81})
            tracker.record({"timestamp": 103.0, "ac_online": True, "charging": False, "discharging": False, "rate_mw": 0, "power_w": 0.0, "current_a": 0.0, "voltage_v": 16.4, "c_rate": 0.0, "percentage": 81})
            tracker.record({"timestamp": 105.0, "ac_online": False, "charging": False, "discharging": True, "rate_mw": -18000, "power_w": -18.0, "current_a": -1.1, "voltage_v": 16.0, "c_rate": -0.45, "percentage": 80})

            s = tracker.summary()
            self.assertEqual(s["charge"]["samples"], 2)
            self.assertEqual(s["charge"]["avg_power_w"], 36.0)
            self.assertGreater(s["charge"]["energy_mwh"], 0)
            self.assertEqual(s["idle"]["samples"], 1)
            self.assertEqual(s["discharge"]["samples"], 1)
            self.assertLess(s["discharge"]["energy_mwh"], 0)
            self.assertEqual(len(tracker.get_events()), 2)

            tracker.save(force=True)
            reloaded = StateStatsTracker(stats_path=stats_file)
            self.assertEqual(reloaded.summary()["charge"]["samples"], 2)
            self.assertEqual(len(reloaded.get_events()), 2)

            reloaded.clear_events()
            self.assertEqual(len(reloaded.get_events()), 0)

            reloaded.reset()
            self.assertEqual(reloaded.summary()["charge"]["samples"], 0)

    def test_charge_limit_80_guard_and_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            stats_file = Path(tmp) / "stats.json"
            tracker = StateStatsTracker(stats_path=stats_file, enable_sound=False)
            self.assertFalse(tracker.charge_guard_status()["enabled"])

            status = tracker.set_charge_limit_80(True)
            self.assertTrue(status["enabled"])
            self.assertFalse(status["triggered"])

            # Below 80% while charging -> not triggered
            tracker.record({"timestamp": 200.0, "ac_online": True, "charging": True, "discharging": False, "rate_mw": 30000, "power_w": 30.0, "current_a": 1.8, "voltage_v": 16.5, "percentage": 79})
            self.assertFalse(tracker.charge_guard_status()["triggered"])

            # Crosses 80% while charging -> triggered + event logged
            tracker.record({"timestamp": 201.0, "ac_online": True, "charging": True, "discharging": False, "rate_mw": 30000, "power_w": 30.0, "current_a": 1.8, "voltage_v": 16.5, "percentage": 80})
            st = tracker.charge_guard_status()
            self.assertTrue(st["triggered"])
            self.assertFalse(st["dismissed"])
            self.assertTrue(any(e["type"] == "limit80" for e in tracker.get_events()))

            # Dismiss banner
            tracker.dismiss_charge_limit_alert()
            self.assertTrue(tracker.charge_guard_status()["dismissed"])

            # Unplugging AC resets trigger
            tracker.record({"timestamp": 202.0, "ac_online": False, "charging": False, "discharging": True, "rate_mw": -15000, "power_w": -15.0, "current_a": -0.9, "voltage_v": 16.0, "percentage": 80})
            self.assertFalse(tracker.charge_guard_status()["triggered"])

            # Preference persists across reload
            reloaded = StateStatsTracker(stats_path=stats_file, enable_sound=False)
            self.assertTrue(reloaded.charge_guard_status()["enabled"])


class TestServerEndpoints(unittest.TestCase):
    def test_http_endpoints(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = TelemetryStore(maxlen=20, stats_path=Path(tmp) / "stats.json", enable_gpu=True)
            store.sample_once()
            stop_evt = threading.Event()
            server = ThreadingHTTPServer(("127.0.0.1", 0), _make_handler(store, stop_evt))
            port = server.server_address[1]
            t = threading.Thread(target=server.serve_forever, daemon=True)
            t.start()
            try:
                for static_path in ("/", "/styles.css", "/app.js"):
                    with urlopen(f"http://127.0.0.1:{port}{static_path}") as resp:
                        self.assertEqual(resp.status, 200)
                        body = resp.read().decode("utf-8")
                        self.assertGreater(len(body), 100)
                        if static_path == "/":
                            self.assertIn("Battery & Power", body)

                with urlopen(f"http://127.0.0.1:{port}/api/telemetry?limit=10") as resp:
                    self.assertEqual(resp.status, 200)
                    data = json.loads(resp.read().decode("utf-8"))
                    self.assertIn("latest", data)
                    self.assertIn("history", data)
                    self.assertIn("active_state", data)
                    self.assertIn("state_stats", data)
                    self.assertIn("events", data)
                    self.assertIn("charge_guard", data)
                    self.assertIn("electricity", data)
                    self.assertIn("cpu", data["latest"])
                    self.assertIn("gpu", data["latest"])
                    self.assertIn("cpu_power_w", data["history"][0])
                    self.assertIn("power_plan", data["latest"])
                    self.assertIn("performance_profile", data["latest"])
                    self.assertEqual(set(data["state_stats"].keys()), {"charge", "idle", "discharge"})

                with urlopen(f"http://127.0.0.1:{port}/api/electricity") as resp:
                    self.assertEqual(resp.status, 200)
                    elec_get = json.loads(resp.read().decode("utf-8"))
                    self.assertIn("settings", elec_get)
                    self.assertIn("sessions", elec_get)
                    self.assertIsNotNone(elec_get["current_session"])

                elec_set_req = Request(
                    f"http://127.0.0.1:{port}/api/electricity/settings",
                    data=json.dumps({"tariff_preset": "r2_3500", "base_overhead_w": 15.0, "adapter_efficiency_pct": 90.0}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(elec_set_req) as resp:
                    elec_post = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(elec_post["ok"])
                    self.assertEqual(elec_post["settings"]["tariff_preset"], "r2_3500")
                    self.assertEqual(elec_post["settings"]["base_overhead_w"], 15.0)
                    self.assertEqual(elec_post["settings"]["adapter_efficiency_pct"], 90.0)

                with urlopen(f"http://127.0.0.1:{port}/api/electricity/export.csv") as resp:
                    self.assertEqual(resp.status, 200)
                    elec_csv = resp.read().decode("utf-8")
                    self.assertTrue(elec_csv.startswith("session_id,boot_time,last_seen"))

                elec_rst_req = Request(
                    f"http://127.0.0.1:{port}/api/electricity/reset",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(elec_rst_req) as resp:
                    self.assertEqual(resp.status, 200)

                orig_profile = get_overlay_power_mode()["profile_key"]
                orig_ac, orig_dc = get_cpu_max_state()
                try:
                    for mode, expected_cap in (("quiet", 99), ("performance", 100), ("balanced", 100)):
                        req = Request(
                            f"http://127.0.0.1:{port}/api/performance-mode",
                            data=json.dumps({"mode": mode}).encode("utf-8"),
                            headers={"Content-Type": "application/json"},
                            method="POST",
                        )
                        with urlopen(req) as resp:
                            self.assertEqual(resp.status, 200)
                            res_json = json.loads(resp.read().decode("utf-8"))
                            self.assertEqual(res_json["profile_key"], mode)
                            self.assertEqual(res_json["cpu_cap"], expected_cap)
                            self.assertEqual(res_json["overlay"]["cpu_max_ac"], expected_cap)

                    bad_req = Request(
                        f"http://127.0.0.1:{port}/api/performance-mode",
                        data=b'{"mode":"turbo_invalid"}',
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with self.assertRaises(HTTPError) as ctx:
                        urlopen(bad_req)
                    self.assertEqual(ctx.exception.code, 400)
                    ctx.exception.close()
                finally:
                    set_performance_profile(orig_profile)
                    if orig_ac is not None and orig_dc is not None:
                        set_cpu_max_state(orig_ac, orig_dc)

                for endpoint, body in (
                    ("/api/gpu-polling", b'{"enabled":false}'),
                    ("/api/charge-limit", b'{"enabled":true}'),
                    ("/api/charge-limit-dismiss", b"{}"),
                    ("/api/charge-limit", b'{"enabled":false}'),
                    ("/api/clear-events", b"{}"),
                    ("/api/reset-stats", b'{"clear_events":true}'),
                ):
                    req = Request(
                        f"http://127.0.0.1:{port}{endpoint}",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urlopen(req) as resp:
                        self.assertEqual(resp.status, 200)

                with urlopen(f"http://127.0.0.1:{port}/api/export.csv") as resp:
                    self.assertEqual(resp.status, 200)
                    csv_text = resp.read().decode("utf-8")
                    self.assertTrue(csv_text.startswith("timestamp,state,voltage_v"))
                    self.assertIn("cpu_power_w,gpu_power_w", csv_text.splitlines()[0])

                with urlopen(f"http://127.0.0.1:{port}/api/specs") as resp:
                    self.assertEqual(resp.status, 200)
                    specs = json.loads(resp.read().decode("utf-8"))
                    self.assertIn("uptime_seconds", specs)
                    self.assertIn("system", specs)
                    self.assertIn("cpu", specs)
                    self.assertIn("ram", specs)
                    self.assertIn("disks", specs)
                    self.assertIn("network", specs)

                with urlopen(f"http://127.0.0.1:{port}/api/ajazz") as resp:
                    self.assertEqual(resp.status, 200)
                    ajazz = json.loads(resp.read().decode("utf-8"))
                    self.assertIn("connected", ajazz)
                    self.assertIn("settings", ajazz)
                    self.assertEqual(len(ajazz["modes"]), 20)

                # Mock hardware send/detect on store._ajazz so HTTP lighting/LCD tests never touch real hardware
                sent_calls = []
                clock_calls = []
                screen_calls = []
                store._ajazz._detect_fn = lambda: {
                    "link": "2.4g", "label": "2.4G Dongle", "vid": 0x0C45, "pid": 0xFDFD, "path": "mock"
                }
                store._ajazz._send_fn = lambda dev, cfg: sent_calls.append((dev["link"], dict(cfg)))
                store._ajazz._battery_fn = lambda _dev: {"percent": 82, "status": "ok"}
                store._ajazz._clock_fn = lambda dev: clock_calls.append(dev["link"])
                store._ajazz._screen_fn = lambda dev, blocks: screen_calls.append((dev["link"], len(blocks)))

                with urlopen(f"http://127.0.0.1:{port}/api/ajazz?refresh=1") as resp:
                    self.assertEqual(resp.status, 200)
                    aj_ref = json.loads(resp.read().decode("utf-8"))
                    self.assertEqual(aj_ref["battery"]["percent"], 82)
                    self.assertIn("lcd", aj_ref)

                clock_req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/clock",
                    data=b"{}",
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(clock_req) as resp:
                    self.assertEqual(resp.status, 200)
                    clock_res = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(clock_res["ok"])
                    self.assertIsNotNone(clock_res["lcd"]["last_clock_sync"])
                self.assertEqual(clock_calls, ["2.4g"])

                frame_b64 = base64.b64encode(b"\x12\x34" * (TFT_FRAME_BYTES // 2)).decode("ascii")
                # Image upload over 2.4G must fail with 400 ValueError (USB-C required)
                screen_24g_req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/screen",
                    data=json.dumps({"rgb565_b64": frame_b64}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as ctx:
                    urlopen(screen_24g_req)
                self.assertEqual(ctx.exception.code, 400)
                ctx.exception.close()

                # Switch mock keyboard to wired USB-C with FF68 screen_path
                store._ajazz._detect_fn = lambda: {
                    "link": "usb",
                    "label": "USB-C Wired",
                    "vid": 0x0C45,
                    "pid": 0x8009,
                    "path": "mock-usb",
                    "screen_path": "mock-screen",
                }
                screen_usb_req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/screen",
                    data=json.dumps({"rgb565_b64": frame_b64}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(screen_usb_req) as resp:
                    self.assertEqual(resp.status, 200)
                    screen_res = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(screen_res["ok"])
                self.assertEqual(screen_calls, [("usb", 9)])

                req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/lighting",
                    data=json.dumps({"mode": 7, "color": "#1a73e8", "brightness": 4, "speed": 2, "sleep_level": 1}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(req) as resp:
                    self.assertEqual(resp.status, 200)
                    res_ajazz = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(res_ajazz["ok"])
                    self.assertEqual(res_ajazz["settings"]["color"], "#1a73e8")
                    self.assertEqual(res_ajazz["settings"]["mode"], 7)
                    self.assertEqual(res_ajazz["settings"]["sleep_level"], 1)
                self.assertEqual(len(sent_calls), 1)

                bad_ajazz = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/lighting",
                    data=json.dumps({"mode": 99}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as ctx:
                    urlopen(bad_ajazz)
                self.assertEqual(ctx.exception.code, 400)
                ctx.exception.close()

                store._ajazz._detect_fn = lambda: None
                disc_req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz/lighting",
                    data=json.dumps({"mode": 1}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with self.assertRaises(HTTPError) as ctx:
                    urlopen(disc_req)
                self.assertEqual(ctx.exception.code, 409)
                ctx.exception.close()

                # AJ159 Pro mouse endpoints
                fake_mouse = {
                    "link": "2.4g",
                    "label": "AJAZZ 2.4G 8K",
                    "vid": 0x3151,
                    "pid": 0x402D,
                    "max_hz": 8000,
                    "path": "mock-mouse",
                }
                mouse_sent = []
                store._ajazz_mouse = AjazzMouseController(
                    state_path=Path(tmp) / "ajazz_mouse_http.json",
                    detect_fn=lambda: fake_mouse,
                    battery_fn=lambda _dev: {"percent": 86, "link_up": True, "status_hex": "01000102"},
                    send_fn=lambda _dev, st: mouse_sent.append(dict(st)),
                )
                with urlopen(f"http://127.0.0.1:{port}/api/ajazz-mouse?refresh=1") as resp:
                    mouse_get = json.loads(resp.read().decode("utf-8"))
                self.assertTrue(mouse_get["connected"])
                self.assertEqual(mouse_get["battery"]["percent"], 86)

                m_req = Request(
                    f"http://127.0.0.1:{port}/api/ajazz-mouse/settings",
                    data=json.dumps({"poll_rate_hz": 4000, "lod": 1, "active_dpi_stage": 1}).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urlopen(m_req) as resp:
                    m_post = json.loads(resp.read().decode("utf-8"))
                self.assertTrue(m_post["ok"])
                self.assertEqual(m_post["settings"]["poll_rate_hz"], 4000)
                self.assertEqual(m_post["settings"]["lod"], 1)
                self.assertEqual(len(mouse_sent), 1)

                self.assertTrue(_is_instance_running(port))
                self.assertFalse(_is_instance_running(_pick_port(0)))

                with patch(
                    "server.get_autostart_status",
                    return_value={"supported": True, "enabled": True, "command": "mock-cmd"},
                ), patch(
                    "server.set_autostart_enabled",
                    return_value={"supported": True, "enabled": False, "command": None},
                ) as mock_set_auto:
                    with urlopen(f"http://127.0.0.1:{port}/api/autostart") as resp:
                        auto_get = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(auto_get["enabled"])
                    auto_req = Request(
                        f"http://127.0.0.1:{port}/api/autostart",
                        data=json.dumps({"enabled": False}).encode("utf-8"),
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urlopen(auto_req) as resp:
                        auto_post = json.loads(resp.read().decode("utf-8"))
                    self.assertTrue(auto_post["ok"])
                    self.assertFalse(auto_post["enabled"])
                    mock_set_auto.assert_called_once_with(False)
            finally:
                server.shutdown()
                server.server_close()


class TestAjazzRgb(unittest.TestCase):
    def test_parse_hex_color(self):
        self.assertEqual(parse_hex_color("#ff6a00"), (255, 106, 0))
        self.assertEqual(parse_hex_color("00e5ff"), (0, 229, 255))
        with self.assertRaises(ValueError):
            parse_hex_color("#12345")

    def test_packet_builders(self):
        pkt = build_dongle_lighting_packet(1, 255, 0, 128, False, 5, 3, 2)
        self.assertEqual(len(pkt), 33)
        self.assertEqual(pkt[0:5], bytes([0x00, 0x05, 0x10, 0x00, 0x01]))
        self.assertEqual(pkt[5:8], bytes([255, 0, 128]))
        self.assertEqual(pkt[12:16], bytes([0, 5, 3, 2]))
        self.assertEqual(pkt[18:20], bytes([0xAA, 0x55]))
        self.assertEqual(pkt[32], sum(pkt[1:32]) & 0xFF)

        off_pkt = build_dongle_lighting_packet(0, 255, 255, 255, True, 5, 5, 3)
        self.assertEqual(off_pkt[4], 0)
        self.assertEqual(off_pkt[5:16], bytes(11))
        self.assertEqual(off_pkt[32], sum(off_pkt[1:32]) & 0xFF)

        seq = build_wired_lighting_sequence(7, 10, 20, 30, True, 4, 2, 1)
        self.assertEqual(len(seq), 5)
        self.assertTrue(all(len(p) == 64 for p in seq))
        self.assertEqual(seq[0][:2], bytes([0x04, 0x18]))
        self.assertEqual(seq[1][:2], bytes([0x04, 0x13]))
        self.assertEqual(seq[1][8], 0x01)
        self.assertEqual(seq[2][:4], bytes([7, 10, 20, 30]))
        self.assertEqual(seq[2][8:12], bytes([1, 4, 2, 1]))
        self.assertEqual(seq[2][14:16], bytes([0xAA, 0x55]))
        self.assertEqual(seq[3][:2], bytes([0x04, 0x02]))
        self.assertEqual(seq[4][:2], bytes([0x04, 0xF0]))

    def test_controller_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            state_file = Path(tmp) / "ajazz_rgb.json"
            sent = []
            ctrl = AjazzRgbController(
                state_path=state_file,
                vendor_db_path=Path(tmp) / "missing.db",
                detect_fn=lambda: {"link": "usb", "label": "USB-C Wired", "vid": 0x0C45, "pid": 0x8009, "path": "x"},
                send_fn=lambda dev, s: sent.append((dev["link"], dict(s))),
            )
            updated = ctrl.apply_lighting({"mode": 16, "color": "#00e5ff", "rainbow": True, "brightness": 4, "speed": 5, "direction": 3})
            self.assertEqual(updated["settings"]["color"], "#00e5ff")
            self.assertEqual(updated["settings"]["mode"], 16)
            self.assertEqual(len(sent), 1)

            reloaded = AjazzRgbController(
                state_path=state_file,
                vendor_db_path=Path(tmp) / "missing.db",
                detect_fn=lambda: None,
            )
            self.assertEqual(reloaded.get_state()["settings"]["color"], "#00e5ff")
            self.assertEqual(reloaded.get_state()["settings"]["direction"], 3)
            with self.assertRaises(LookupError):
                reloaded.apply_lighting({"mode": 1})

    def test_battery_clock_sleep_and_screen_packets(self):
        q = build_rf_battery_query()
        self.assertEqual(len(q), 33)
        self.assertEqual(q[0:4], bytes([0x00, 0x20, 0x01, 0x00]))
        self.assertEqual(q[32], sum(q[1:32]) & 0xFF)

        self.assertEqual(parse_rf_battery_reply(bytes([0x00, 0x20, 0x01, 0x00, 74])), {"percent": 74, "status": "ok"})
        self.assertEqual(parse_rf_battery_reply(bytes([0x20, 0x01, 0x00, 91])), {"percent": 91, "status": "ok"})
        self.assertIsNone(parse_rf_battery_reply(bytes([0x00, 0x05, 0x01, 0x00, 50])))

        dt = datetime(2026, 11, 12, 22, 35, 10)  # Thursday (weekday=3 -> Sun=0 => 4)
        wired_clk = build_wired_clock_sequence(dt)
        self.assertEqual(len(wired_clk), 4)
        self.assertTrue(all(len(p) == 64 for p in wired_clk))
        self.assertEqual(wired_clk[1][:2], bytes([0x04, 0x28]))
        self.assertEqual(wired_clk[2][2:9], bytes([0x5A, 26, 11, 12, 22, 35, 10]))

        dongle_clk = build_dongle_clock_packet(dt)
        self.assertEqual(len(dongle_clk), 33)
        self.assertEqual(dongle_clk[1], 0x0C)
        self.assertEqual(dongle_clk[14], 4)
        self.assertEqual(dongle_clk[32], sum(dongle_clk[1:32]) & 0xFF)

        wired_slp = build_wired_sleep_sequence(
            3, response_level=1, fn_toggle=True, block_win=True, block_alt_f4=False, block_alt_tab=True
        )
        self.assertEqual(wired_slp[1][:3], bytes([0x04, 0x17, 0x01]))
        self.assertEqual(wired_slp[2][2:9], bytes([1, 0, 1, 1, 3, 0, 1]))

        dongle_slp = build_dongle_sleep_packet(
            2, response_level=4, fn_toggle=False, block_win=True, block_alt_f4=True, block_alt_tab=False
        )
        self.assertEqual(len(dongle_slp), 33)
        self.assertEqual(dongle_slp[1], 0x07)
        self.assertEqual(dongle_slp[6:13], bytes([1, 1, 0, 0, 2, 0, 4]))

        blocks = build_tft_screen_blocks([b"\xAA\xBB" * (TFT_FRAME_BYTES // 2)], [100])
        self.assertEqual(len(blocks), 9)
        self.assertTrue(all(len(b) == TFT_BLOCK_SIZE for b in blocks))
        self.assertEqual(blocks[0][0], 1)
        self.assertEqual(blocks[0][1], 50)
        with self.assertRaises(ValueError):
            build_tft_screen_blocks([b"\x00" * 100])


class TestSystemSpecs(unittest.TestCase):
    def test_uptime_positive(self):
        uptime = get_uptime_seconds()
        self.assertIsInstance(uptime, int)
        self.assertGreaterEqual(uptime, 0)

    def test_cache_and_refresh(self):
        calls = []

        def fake_collect():
            calls.append(1)
            return {
                "system": {"manufacturer": "Acer", "model": "Nitro AN515-57"},
                "cpu": {"name": "i5-11400H", "cores": 6, "threads": 12},
                "ram": {"total_installed_gb": 16.0, "total_usable_gb": 15.78, "modules": []},
                "gpus": [],
                "displays": [],
                "disks": [],
                "volumes": [],
                "network": [],
            }

        with patch("system_specs.collect_system_specs", side_effect=fake_collect):
            cache = SystemSpecsCache()
            first = cache.get_specs(refresh=False)
            second = cache.get_specs(refresh=False)
            self.assertEqual(len(calls), 1)
            self.assertEqual(first["system"]["model"], "Nitro AN515-57")
            self.assertEqual(second["system"]["model"], "Nitro AN515-57")
            self.assertIn("uptime_seconds", second)

            cache.get_specs(refresh=True)
            self.assertEqual(len(calls), 2)


class TestAjazzMouse(unittest.TestCase):
    def test_battery_frame_parser(self):
        poll = build_battery_poll_packet()
        self.assertEqual(len(poll), 65)
        self.assertEqual(poll[0:2], bytes([0x00, 0xF7]))

        valid_win = bytes([0x05, 0x00, 0x00, 0x56, 0x01, 0x01, 0x01, 0x02]) + bytes(57)
        parsed = parse_battery_frame(valid_win)
        self.assertIsNotNone(parsed)
        self.assertEqual(parsed["percent"], 86)
        self.assertTrue(parsed["link_up"])

        valid_idle = bytes([0x00, 0x00, 0x00, 0x56, 0x01, 0x00, 0x01, 0x02]) + bytes(57)
        self.assertEqual(parse_battery_frame(valid_idle)["percent"], 86)

        not_ready = bytes([0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]) + bytes(57)
        self.assertIsNone(parse_battery_frame(not_ready))

        garbage = bytes([0x05, 0xAD, 0x04, 0x56, 0x01, 0x01, 0x01, 0x02]) + bytes(57)
        self.assertIsNone(parse_battery_frame(garbage))

    def test_mouse_packet_builders_and_bit7_checksum(self):
        p_rate = build_set_poll_rate_packet(0, 8000)
        self.assertEqual(len(p_rate), 65)
        self.assertEqual(p_rate[0:4], bytes([0x00, 0x04, 0x00, 0x81]))
        self.assertEqual(p_rate[8], (255 - sum(p_rate[1:8])) & 0xFF)

        p_ms = build_set_motion_sync_packet(True)
        self.assertEqual(len(p_ms), 65)
        self.assertEqual(p_ms[0:3], bytes([0x00, 0x14, 0x01]))
        self.assertEqual(p_ms[8], (255 - sum(p_ms[1:8])) & 0xFF)

        p_as = build_set_angle_snap_packet(True)
        self.assertEqual(len(p_as), 65)
        self.assertEqual(p_as[0:3], bytes([0x00, 0x12, 0x01]))
        self.assertEqual(p_as[8], (255 - sum(p_as[1:8])) & 0xFF)

        p_lod = build_set_lod_packet(1)
        self.assertEqual(len(p_lod), 65)
        self.assertEqual(p_lod[0:3], bytes([0x00, 0x11, 0x01]))
        self.assertEqual(p_lod[8], (255 - sum(p_lod[1:8])) & 0xFF)

        stages = [{"dpi": 400 + i * 400, "color": "#1a73e8"} for i in range(8)]
        p_dpi = build_set_dpi_table_packet(0, 2, 6, stages)
        self.assertEqual(len(p_dpi), 65)
        self.assertEqual(p_dpi[1:5], bytes([0x54, 0, 2, 6]))
        self.assertEqual(p_dpi[8], (255 - sum(p_dpi[1:8])) & 0xFF)
        # Stage 2 = 1200 DPI LE = 0xB0 0x04 at X pkt[9 + 2*2 .. 15] and Y pkt[25 + 2*2 .. 31]
        self.assertEqual(int.from_bytes(p_dpi[13:15], "little"), 1200)
        self.assertEqual(int.from_bytes(p_dpi[29:31], "little"), 1200)
        self.assertEqual(p_dpi[41:44], bytes([0x1A, 0x73, 0xE8]))

        p_opt = build_set_option0_packet(
            {
                "profile": 0,
                "poll_rate_hz": 2000,
                "debounce_ms": 2,
                "motion_sync": True,
                "power_save": True,
                "sleep_idle_s": 120,
                "sleep_deep_s": 600,
                "lod": 2,
                "angle_snap": True,
                "battery_led_high": "#00ff00",
                "battery_led_low": "#ff0000",
                "charging_led": False,
            }
        )
        self.assertEqual(len(p_opt), 65)
        self.assertEqual(p_opt[1], 0x53)
        self.assertEqual(p_opt[8], (255 - sum(p_opt[1:8])) & 0xFF)
        self.assertEqual(p_opt[10], 0x84)
        self.assertEqual(p_opt[11], 2)
        # flags: motion_sync (1<<2) | led_select (1<<3) | power_save (1<<4) = 0x1C
        self.assertEqual(int.from_bytes(p_opt[13:15], "little"), 0x1C)
        self.assertEqual(p_opt[53], 2)
        self.assertEqual(p_opt[54], 1)
        self.assertEqual(p_opt[55:61], bytes([0, 255, 0, 255, 0, 0]))
        self.assertEqual(p_opt[61], 0)

    def test_mouse_controller_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            state_file = Path(tmp) / "ajazz_mouse.json"
            sent = []
            ctrl = AjazzMouseController(
                state_path=state_file,
                detect_fn=lambda: {
                    "link": "2.4g",
                    "label": "AJAZZ 2.4G 8K",
                    "vid": 0x3151,
                    "pid": 0x402D,
                    "max_hz": 8000,
                    "path": "x",
                },
                battery_fn=lambda _dev: {"percent": 82, "link_up": True, "status_hex": "01010102"},
                send_fn=lambda _dev, st: sent.append(dict(st)),
            )
            state = ctrl.apply_settings(
                {
                    "poll_rate_hz": 4000,
                    "lod": 1,
                    "motion_sync": False,
                    "debounce_ms": 4,
                    "dpi_stages": [{"dpi": 800, "color": "#00e5ff"}],
                    "active_dpi_stage": 0,
                }
            )
            self.assertEqual(state["battery"]["percent"], 82)
            self.assertEqual(state["settings"]["poll_rate_hz"], 4000)
            self.assertEqual(state["settings"]["lod"], 1)
            self.assertEqual(state["settings"]["dpi_stages"][0]["dpi"], 800)
            self.assertEqual(len(sent), 1)

            reloaded = AjazzMouseController(state_path=state_file, detect_fn=lambda: None)
            self.assertEqual(reloaded.get_state()["settings"]["poll_rate_hz"], 4000)
            self.assertEqual(reloaded.get_state()["settings"]["debounce_ms"], 4)
            with self.assertRaises(LookupError):
                reloaded.apply_settings({"poll_rate_hz": 1000})


class TestElectricityReport(unittest.TestCase):
    def test_live_breakdown_ac_and_battery(self):
        settings = {
            "tariff_preset": "r1_1300",
            "tariff_idr_per_kwh": 1444.7,
            "base_overhead_w": 12.0,
            "adapter_efficiency_pct": 88.0,
        }
        ac_snap = {
            "battery_present": True,
            "ac_online": True,
            "rate_mw": 22000,
            "cpu": {"cpu_power_w": 30.0, "cpu_percent": 50.0},
            "gpu": {"power_w": 20.0},
        }
        b = compute_live_power_breakdown(ac_snap, settings)
        self.assertTrue(b["ac_online"])
        self.assertEqual(b["source"], "sensor")
        # DC system = 30 + 20 + 12 = 62W; + charge 22W = 84W DC; wall = 84 / 0.88
        self.assertAlmostEqual(b["system_w"], 62.0, places=2)
        self.assertAlmostEqual(b["wall_w"], 84.0 / 0.88, places=2)
        self.assertAlmostEqual(b["hourly_cost_idr"], (84.0 / 0.88 / 1000.0) * 1444.7, places=2)

        bat_snap = {
            "battery_present": True,
            "ac_online": False,
            "rate_mw": -25000,
            "cpu": {"cpu_power_w": 10.0, "cpu_percent": 15.0},
            "gpu": {"power_w": None},
        }
        b2 = compute_live_power_breakdown(bat_snap, settings)
        self.assertFalse(b2["ac_online"])
        self.assertEqual(b2["source"], "battery_sensor")
        self.assertAlmostEqual(b2["system_w"], 25.0, places=2)
        self.assertEqual(b2["wall_w"], 0.0)
        self.assertGreater(b2["equiv_hourly_cost_idr"], 0.0)

    def test_per_boot_session_tracking_and_cost(self):
        with tempfile.TemporaryDirectory() as tmp:
            rep_path = Path(tmp) / "electricity_report.json"
            tracker = ElectricityReportTracker(report_path=rep_path)
            tracker.update_settings({"tariff_idr_per_kwh": 1500.0, "base_overhead_w": 10.0, "adapter_efficiency_pct": 100.0})

            t0 = datetime(2026, 11, 12, 10, 0, 0).timestamp()
            snap = {
                "timestamp": t0,
                "battery_present": True,
                "ac_online": True,
                "rate_mw": 0,
                "cpu": {"cpu_power_w": 40.0, "cpu_percent": 20.0},
                "gpu": {"power_w": 50.0},
            }
            # 100W total DC / 100% eff = 100W wall. 2 samples spaced 5s apart (dt=1s + dt=5s = 6s).
            tracker.record(snap, uptime_seconds=600)
            snap["timestamp"] = t0 + 5.0
            tracker.record(snap, uptime_seconds=605)
            tracker.save(force=True)

            # Simulate restarting app during SAME boot -> must merge into same session
            reloaded = ElectricityReportTracker(report_path=rep_path)
            snap["timestamp"] = t0 + 10.0
            reloaded.record(snap, uptime_seconds=610)
            rep1 = reloaded.summary(now=t0 + 10.0)
            self.assertEqual(len(rep1["sessions"]), 1)
            cur = rep1["current_session"]
            self.assertTrue(cur["is_current"])
            # 100W * (1s + 5s + 1s on reload) = 7s -> 100W * 7 / 3600 = 0.1944 Wh
            self.assertAlmostEqual(cur["wall_energy_wh"], 100.0 * 7.0 / 3600.0, places=2)
            self.assertAlmostEqual(cur["cost_idr"], (cur["wall_energy_wh"] / 1000.0) * 1500.0, places=2)
            self.assertIsNone(cur["est_full_cost_idr"])  # < 10s warmup guard

            snap["timestamp"] = t0 + 15.0
            reloaded.record(snap, uptime_seconds=615)
            rep_warm = reloaded.summary(now=t0 + 15.0)
            self.assertEqual(len(rep_warm["daily_7d"]), 7)
            self.assertGreater(rep_warm["projection_30d"]["est_30d_cost_idr"], 0.0)
            self.assertIsNotNone(rep_warm["current_session"]["est_full_cost_idr"])

            # Simulate a REBOOT -> uptime resets to 30s -> must create a second boot session
            t_reboot = datetime(2026, 11, 12, 18, 0, 0).timestamp()
            snap["timestamp"] = t_reboot
            reloaded.record(snap, uptime_seconds=30)
            rep2 = reloaded.summary(now=t_reboot)
            self.assertEqual(len(rep2["sessions"]), 2)
            self.assertEqual(rep2["today"]["session_count"], 2)
            self.assertIn("session_id,boot_time", reloaded.export_csv())


class TestAutostart(unittest.TestCase):
    def test_build_command_and_registry_roundtrip(self):
        cmd = build_autostart_command()
        self.assertIn("server.py", cmd)
        self.assertIn("--no-open", cmd)

        import server as srv

        if srv.winreg is None:
            self.skipTest("winreg unavailable")

        test_subkey = r"Software\BatteryPowerMonitorTestRun"
        test_val = "TestEntry"
        try:
            enabled_state = set_autostart_enabled(True, subkey=test_subkey, value_name=test_val)
            self.assertTrue(enabled_state["supported"])
            self.assertTrue(enabled_state["enabled"])
            self.assertIn("--no-open", enabled_state["command"])

            read_state = get_autostart_status(subkey=test_subkey, value_name=test_val)
            self.assertTrue(read_state["enabled"])

            disabled_state = set_autostart_enabled(False, subkey=test_subkey, value_name=test_val)
            self.assertFalse(disabled_state["enabled"])
        finally:
            try:
                srv.winreg.DeleteKey(srv.winreg.HKEY_CURRENT_USER, test_subkey)
            except OSError:
                pass


if __name__ == "__main__":
    unittest.main()
