"""System power plan, dynamic CPU clock/thermal, and NVIDIA GPU power reader."""

from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import asdict, dataclass
import os
import shutil
import subprocess
import threading
import time
import uuid
import winreg

POWRPROF = ctypes.WinDLL("powrprof", use_last_error=True)
KERNEL32 = ctypes.WinDLL("kernel32", use_last_error=True)
try:
    PDH = ctypes.WinDLL("pdh", use_last_error=True)
except OSError:
    PDH = None

PROCESSOR_INFORMATION_LEVEL = 11
CREATE_NO_WINDOW = 0x08000000
PDH_FMT_DOUBLE = 0x00000200

SUB_PROCESSOR_GUID = "54533251-82be-4824-96c1-47b60b740d00"
PROCTHROTTLEMAX_GUID = "bc5038f7-23e0-4960-96da-33abaf5935ec"

PERFORMANCE_PROFILES = {
    "quiet": ("961cc777-2547-4f9d-8174-7d86181b8a7a", "Quiet", "Best power efficiency", 99),
    "balanced": ("00000000-0000-0000-0000-000000000000", "Balanced", "Balanced", 100),
    "performance": ("ded574b5-45a0-4f42-8737-46345c09c238", "Performance", "Best performance", 100),
}

OVERLAY_POWER_MODES = {
    "961cc777-2547-4f9d-8174-7d86181b8a7a": "Best power efficiency",
    "00000000-0000-0000-0000-000000000000": "Balanced",
    "ded574b5-45a0-4f42-8737-46345c09c238": "Best performance",
    "3af9b8d9-7c97-431d-ad78-34a8bfed4355": "Better battery",
}

GUID_TO_PROFILE_KEY = {
    "961cc777-2547-4f9d-8174-7d86181b8a7a": "quiet",
    "3af9b8d9-7c97-431d-ad78-34a8bfed4355": "quiet",
    "00000000-0000-0000-0000-000000000000": "balanced",
    "ded574b5-45a0-4f42-8737-46345c09c238": "performance",
}

KNOWN_POWER_PLANS = {
    "381b4222-f694-41f0-9685-ff5bb260df2e": "Balanced",
    "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c": "High performance",
    "a1841308-3541-4fab-bc81-f71556f20b4a": "Power saver",
    "e9a42b02-d5df-448d-aa00-03f14749eb61": "Ultimate Performance",
}


class _WIN_GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    def to_str(self) -> str:
        d4 = bytes(self.Data4)
        return f"{self.Data1:08x}-{self.Data2:04x}-{self.Data3:04x}-{d4[:2].hex()}-{d4[2:].hex()}"


class FILETIME(ctypes.Structure):
    _fields_ = [
        ("dwLowDateTime", wintypes.DWORD),
        ("dwHighDateTime", wintypes.DWORD),
    ]


class PROCESSOR_POWER_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("Number", wintypes.ULONG),
        ("MaxMhz", wintypes.ULONG),
        ("CurrentMhz", wintypes.ULONG),
        ("MhzLimit", wintypes.ULONG),
        ("MaxIdleState", wintypes.ULONG),
        ("CurrentIdleState", wintypes.ULONG),
    ]


class PDH_FMT_COUNTERVALUE(ctypes.Structure):
    _fields_ = [
        ("CStatus", wintypes.DWORD),
        ("pad", wintypes.DWORD),
        ("doubleValue", ctypes.c_double),
    ]


KERNEL32.GetSystemTimes.restype = wintypes.BOOL
KERNEL32.GetSystemTimes.argtypes = [
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME),
]
KERNEL32.LocalFree.restype = ctypes.c_void_p
KERNEL32.LocalFree.argtypes = [ctypes.c_void_p]

POWRPROF.CallNtPowerInformation.restype = ctypes.c_long
POWRPROF.CallNtPowerInformation.argtypes = [
    ctypes.c_int,
    ctypes.c_void_p,
    wintypes.ULONG,
    ctypes.c_void_p,
    wintypes.ULONG,
]

for _fn_name in (
    "PowerGetActualOverlayScheme",
    "PowerGetEffectiveOverlayScheme",
    "PowerSetActiveOverlayScheme",
):
    _fn = getattr(POWRPROF, _fn_name, None)
    if _fn is not None:
        _fn.restype = wintypes.DWORD
        _fn.argtypes = [ctypes.POINTER(_WIN_GUID)]

POWRPROF.PowerGetActiveScheme.restype = wintypes.DWORD
POWRPROF.PowerGetActiveScheme.argtypes = [
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.POINTER(_WIN_GUID)),
]
POWRPROF.PowerSetActiveScheme.restype = wintypes.DWORD
POWRPROF.PowerSetActiveScheme.argtypes = [ctypes.c_void_p, ctypes.POINTER(_WIN_GUID)]

for _rw_fn in ("PowerReadACValueIndex", "PowerReadDCValueIndex"):
    _fn = getattr(POWRPROF, _rw_fn, None)
    if _fn is not None:
        _fn.restype = wintypes.DWORD
        _fn.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_WIN_GUID),
            ctypes.POINTER(_WIN_GUID),
            ctypes.POINTER(_WIN_GUID),
            ctypes.POINTER(wintypes.DWORD),
        ]

for _wr_fn in ("PowerWriteACValueIndex", "PowerWriteDCValueIndex"):
    _fn = getattr(POWRPROF, _wr_fn, None)
    if _fn is not None:
        _fn.restype = wintypes.DWORD
        _fn.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(_WIN_GUID),
            ctypes.POINTER(_WIN_GUID),
            ctypes.POINTER(_WIN_GUID),
            wintypes.DWORD,
        ]

if PDH is not None:
    PDH.PdhOpenQueryW.restype = wintypes.LONG
    PDH.PdhOpenQueryW.argtypes = [wintypes.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
    PDH.PdhAddEnglishCounterW.restype = wintypes.LONG
    PDH.PdhAddEnglishCounterW.argtypes = [
        ctypes.c_void_p,
        wintypes.LPCWSTR,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p),
    ]
    PDH.PdhCollectQueryData.restype = wintypes.LONG
    PDH.PdhCollectQueryData.argtypes = [ctypes.c_void_p]
    PDH.PdhGetFormattedCounterValue.restype = wintypes.LONG
    PDH.PdhGetFormattedCounterValue.argtypes = [
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.POINTER(PDH_FMT_COUNTERVALUE),
    ]
    PDH.PdhCloseQuery.restype = wintypes.LONG
    PDH.PdhCloseQuery.argtypes = [ctypes.c_void_p]


def _guid_from_str(guid_str: str) -> _WIN_GUID:
    g = _WIN_GUID()
    ctypes.memmove(ctypes.byref(g), uuid.UUID(guid_str).bytes_le, 16)
    return g


def get_cpu_max_state() -> tuple[int | None, int | None]:
    """Return (ac_max_percent, dc_max_percent) for PROCTHROTTLEMAX."""
    p_scheme = ctypes.POINTER(_WIN_GUID)()
    if POWRPROF.PowerGetActiveScheme(None, ctypes.byref(p_scheme)) != 0 or not p_scheme:
        return None, None
    try:
        sub_proc = _guid_from_str(SUB_PROCESSOR_GUID)
        max_state = _guid_from_str(PROCTHROTTLEMAX_GUID)
        ac_val = wintypes.DWORD(0)
        dc_val = wintypes.DWORD(0)
        ac_ok = (
            POWRPROF.PowerReadACValueIndex(
                None, p_scheme, ctypes.byref(sub_proc), ctypes.byref(max_state), ctypes.byref(ac_val)
            )
            == 0
        )
        dc_ok = (
            POWRPROF.PowerReadDCValueIndex(
                None, p_scheme, ctypes.byref(sub_proc), ctypes.byref(max_state), ctypes.byref(dc_val)
            )
            == 0
        )
        return (int(ac_val.value) if ac_ok else None), (int(dc_val.value) if dc_ok else None)
    finally:
        KERNEL32.LocalFree(p_scheme)


def set_cpu_max_state(ac_percent: int, dc_percent: int) -> bool:
    """Set AC/DC PROCTHROTTLEMAX percent on active power scheme."""
    p_scheme = ctypes.POINTER(_WIN_GUID)()
    if POWRPROF.PowerGetActiveScheme(None, ctypes.byref(p_scheme)) != 0 or not p_scheme:
        return False
    try:
        sub_proc = _guid_from_str(SUB_PROCESSOR_GUID)
        max_state = _guid_from_str(PROCTHROTTLEMAX_GUID)
        ac_clamped = max(5, min(100, int(ac_percent)))
        dc_clamped = max(5, min(100, int(dc_percent)))
        rc1 = POWRPROF.PowerWriteACValueIndex(
            None, p_scheme, ctypes.byref(sub_proc), ctypes.byref(max_state), ac_clamped
        )
        rc2 = POWRPROF.PowerWriteDCValueIndex(
            None, p_scheme, ctypes.byref(sub_proc), ctypes.byref(max_state), dc_clamped
        )
        rc3 = POWRPROF.PowerSetActiveScheme(None, p_scheme)
        return rc1 == 0 and rc2 == 0 and rc3 == 0
    finally:
        KERNEL32.LocalFree(p_scheme)


def get_overlay_power_mode() -> dict:
    """Query actual and effective Windows Power Mode overlay schemes."""
    actual_guid: str | None = None
    effective_guid: str | None = None

    get_actual = getattr(POWRPROF, "PowerGetActualOverlayScheme", None)
    if get_actual is not None:
        g = _WIN_GUID()
        if get_actual(ctypes.byref(g)) == 0:
            actual_guid = g.to_str()

    get_effective = getattr(POWRPROF, "PowerGetEffectiveOverlayScheme", None)
    if get_effective is not None:
        g = _WIN_GUID()
        if get_effective(ctypes.byref(g)) == 0:
            effective_guid = g.to_str()

    profile_key = GUID_TO_PROFILE_KEY.get(actual_guid or "", "balanced")
    actual_label = OVERLAY_POWER_MODES.get(actual_guid or "", "Balanced")
    effective_label = OVERLAY_POWER_MODES.get(effective_guid or "", actual_label)
    cpu_cap_ac, cpu_cap_dc = get_cpu_max_state()
    return {
        "profile_key": profile_key,
        "actual_guid": actual_guid,
        "actual_label": actual_label,
        "effective_guid": effective_guid,
        "effective_label": effective_label,
        "cpu_max_ac": cpu_cap_ac,
        "cpu_max_dc": cpu_cap_dc,
    }


def set_performance_profile(profile_key: str) -> dict:
    """Switch NitroSense-style profile ('quiet', 'balanced', or 'performance')."""
    key = (profile_key or "").strip().lower()
    if key not in PERFORMANCE_PROFILES:
        raise ValueError(f"Unsupported performance profile: {profile_key}")

    guid_str, display_name, windows_label, cpu_cap = PERFORMANCE_PROFILES[key]
    setter = getattr(POWRPROF, "PowerSetActiveOverlayScheme", None)
    if setter is None:
        raise RuntimeError("PowerSetActiveOverlayScheme is not supported on this OS")

    g = _guid_from_str(guid_str)
    rc = setter(ctypes.byref(g))
    if rc != 0:
        raise RuntimeError(f"PowerSetActiveOverlayScheme failed with code {rc}")

    # Cap turbo boost at 99% in Quiet mode so CPU stays cool/quiet; restore 100% otherwise.
    set_cpu_max_state(cpu_cap, cpu_cap)

    current = get_overlay_power_mode()
    return {
        "ok": True,
        "profile_key": current["profile_key"],
        "display_name": display_name,
        "windows_label": windows_label,
        "cpu_cap": cpu_cap,
        "overlay": current,
    }


def _filetime_to_int(ft: FILETIME) -> int:
    return (int(ft.dwHighDateTime) << 32) | int(ft.dwLowDateTime)


def _clean_friendly_name(raw: str, guid: str) -> str:
    text = (raw or "").strip()
    if "," in text and text.startswith("@"):
        text = text.rsplit(",", 1)[-1].strip()
    if text:
        return text
    return KNOWN_POWER_PLANS.get(guid.lower(), guid)


def get_power_plan_info(ac_online: bool = True) -> tuple[str, str | None]:
    """Return (active_power_plan_name, windows_power_mode_or_none)."""
    plan_name = "Unknown"
    power_mode: str | None = None
    schemes_path = r"SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes"
    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, schemes_path) as key:
            active_guid = str(winreg.QueryValueEx(key, "ActivePowerScheme")[0]).strip("{}")
            try:
                with winreg.OpenKey(key, active_guid) as sub:
                    raw_name = str(winreg.QueryValueEx(sub, "FriendlyName")[0])
                plan_name = _clean_friendly_name(raw_name, active_guid)
            except OSError:
                plan_name = KNOWN_POWER_PLANS.get(active_guid.lower(), active_guid)

            overlay = get_overlay_power_mode()
            if overlay.get("actual_guid") is not None:
                power_mode = overlay["actual_label"]
            else:
                overlay_val = (
                    "ActiveOverlayAcPowerScheme" if ac_online else "ActiveOverlayDcPowerScheme"
                )
                try:
                    ov_guid = str(winreg.QueryValueEx(key, overlay_val)[0]).strip("{}").lower()
                    power_mode = OVERLAY_POWER_MODES.get(ov_guid)
                except OSError:
                    power_mode = None
    except OSError:
        pass
    return plan_name, power_mode


class CpuPowerMonitor:
    """Reads live CPU load, dynamic boost clock (via PDH), and thermal zone temp."""

    def __init__(self) -> None:
        self._prev_idle: int | None = None
        self._prev_kernel: int | None = None
        self._prev_user: int | None = None
        self._cpu_count = max(1, os.cpu_count() or 1)
        self._pdh_query = None
        self._pdh_perf = None
        self._pdh_temp = None
        self._pdh_pkg_power = None
        self._init_pdh()

    def _init_pdh(self) -> None:
        if PDH is None:
            return
        try:
            hq = ctypes.c_void_p()
            if PDH.PdhOpenQueryW(None, 0, ctypes.byref(hq)) != 0:
                return
            hp = ctypes.c_void_p()
            ht = ctypes.c_void_p()
            he = ctypes.c_void_p()
            if (
                PDH.PdhAddEnglishCounterW(
                    hq, r"\Processor Information(_Total)\% Processor Performance", 0, ctypes.byref(hp)
                )
                == 0
            ):
                self._pdh_perf = hp
            if (
                PDH.PdhAddEnglishCounterW(
                    hq, r"\Thermal Zone Information(*)\Temperature", 0, ctypes.byref(ht)
                )
                == 0
            ):
                self._pdh_temp = ht
            if (
                PDH.PdhAddEnglishCounterW(
                    hq, r"\Energy Meter(RAPL_Package0_PKG)\Power", 0, ctypes.byref(he)
                )
                == 0
            ):
                self._pdh_pkg_power = he
            self._pdh_query = hq
            PDH.PdhCollectQueryData(hq)
        except Exception:
            self._pdh_query = None

    def _read_pdh_metrics(self) -> tuple[float | None, float | None, float | None]:
        if PDH is None or not self._pdh_query:
            return None, None, None
        try:
            if PDH.PdhCollectQueryData(self._pdh_query) != 0:
                return None, None, None
            perf_pct: float | None = None
            temp_c: float | None = None
            pkg_power_w: float | None = None
            if self._pdh_perf:
                v = PDH_FMT_COUNTERVALUE()
                if (
                    PDH.PdhGetFormattedCounterValue(
                        self._pdh_perf, PDH_FMT_DOUBLE, None, ctypes.byref(v)
                    )
                    == 0
                    and v.CStatus == 0
                ):
                    perf_pct = float(v.doubleValue)
            if self._pdh_temp:
                v2 = PDH_FMT_COUNTERVALUE()
                if (
                    PDH.PdhGetFormattedCounterValue(
                        self._pdh_temp, PDH_FMT_DOUBLE, None, ctypes.byref(v2)
                    )
                    == 0
                    and v2.CStatus == 0
                    and v2.doubleValue > 200.0
                ):
                    temp_c = round(float(v2.doubleValue) - 273.15, 1)
            if self._pdh_pkg_power:
                v3 = PDH_FMT_COUNTERVALUE()
                if (
                    PDH.PdhGetFormattedCounterValue(
                        self._pdh_pkg_power, PDH_FMT_DOUBLE, None, ctypes.byref(v3)
                    )
                    == 0
                    and v3.CStatus == 0
                    and v3.doubleValue >= 0.0
                ):
                    pkg_power_w = round(float(v3.doubleValue) / 1000.0, 2)
            return perf_pct, temp_c, pkg_power_w
        except Exception:
            return None, None, None

    def read(self) -> dict:
        idle_ft, kernel_ft, user_ft = FILETIME(), FILETIME(), FILETIME()
        cpu_pct: float | None = None
        if KERNEL32.GetSystemTimes(
            ctypes.byref(idle_ft), ctypes.byref(kernel_ft), ctypes.byref(user_ft)
        ):
            idle = _filetime_to_int(idle_ft)
            kernel = _filetime_to_int(kernel_ft)
            user = _filetime_to_int(user_ft)
            if self._prev_idle is not None:
                d_idle = idle - self._prev_idle
                d_kernel = kernel - self._prev_kernel
                d_user = user - self._prev_user
                total = d_kernel + d_user
                if total > 0:
                    busy = max(0, (d_kernel - d_idle) + d_user)
                    cpu_pct = round(min(100.0, (busy / total) * 100.0), 1)
            self._prev_idle = idle
            self._prev_kernel = kernel
            self._prev_user = user

        base_mhz: int | None = None
        max_mhz: int | None = None
        limit_mhz: int | None = None

        arr = (PROCESSOR_POWER_INFORMATION * self._cpu_count)()
        rc = POWRPROF.CallNtPowerInformation(
            PROCESSOR_INFORMATION_LEVEL,
            None,
            0,
            ctypes.byref(arr),
            ctypes.sizeof(arr),
        )
        if rc == 0:
            currents = [int(arr[i].CurrentMhz) for i in range(self._cpu_count) if arr[i].CurrentMhz > 0]
            maxes = [int(arr[i].MaxMhz) for i in range(self._cpu_count) if arr[i].MaxMhz > 0]
            limits = [int(arr[i].MhzLimit) for i in range(self._cpu_count) if arr[i].MhzLimit > 0]
            if currents:
                base_mhz = round(sum(currents) / len(currents))
            if maxes:
                max_mhz = max(maxes)
            if limits:
                limit_mhz = round(sum(limits) / len(limits))

        perf_pct, thermal_c, pkg_power_w = self._read_pdh_metrics()
        live_mhz = base_mhz
        if perf_pct is not None and (max_mhz or base_mhz):
            ref_mhz = max_mhz or base_mhz
            live_mhz = round(ref_mhz * (perf_pct / 100.0))

        return {
            "cpu_percent": cpu_pct,
            "cpu_current_mhz": live_mhz,
            "cpu_max_mhz": max_mhz,
            "cpu_limit_mhz": limit_mhz,
            "cpu_perf_percent": round(perf_pct, 1) if perf_pct is not None else None,
            "cpu_power_w": pkg_power_w,
            "thermal_c": thermal_c,
            "cpu_cores_logical": self._cpu_count,
        }


@dataclass
class GpuTelemetry:
    available: bool
    enabled: bool
    name: str
    power_w: float | None
    power_limit_w: float | None
    temp_c: int | None
    util_percent: int | None
    clock_mhz: int | None
    pstate: str


def _parse_float(val: str) -> float | None:
    s = (val or "").strip()
    if not s or s.upper() in ("[N/A]", "N/A", "[NOT SUPPORTED]"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _parse_int(val: str) -> int | None:
    f = _parse_float(val)
    return int(round(f)) if f is not None else None


class GpuPowerMonitor:
    """Optional cached NVIDIA GPU power reader via nvidia-smi."""

    def __init__(self, enabled: bool = True, min_interval_sec: float = 2.0) -> None:
        self._lock = threading.Lock()
        self._exe = shutil.which("nvidia-smi")
        self._enabled = enabled and (self._exe is not None)
        self._min_interval = min_interval_sec
        self._last_poll = 0.0
        self._cached = GpuTelemetry(
            available=self._exe is not None,
            enabled=self._enabled,
            name="",
            power_w=None,
            power_limit_w=None,
            temp_c=None,
            util_percent=None,
            clock_mhz=None,
            pstate="",
        )

    @property
    def available(self) -> bool:
        return self._exe is not None

    def set_enabled(self, enabled: bool) -> bool:
        with self._lock:
            self._enabled = bool(enabled) and (self._exe is not None)
            self._last_poll = 0.0
            if not self._enabled:
                self._cached = GpuTelemetry(
                    available=self._exe is not None,
                    enabled=False,
                    name=self._cached.name,
                    power_w=None,
                    power_limit_w=None,
                    temp_c=None,
                    util_percent=None,
                    clock_mhz=None,
                    pstate="",
                )
            return self._enabled

    def read(self) -> dict:
        with self._lock:
            if not self._exe or not self._enabled:
                return asdict(self._cached)
            now = time.time()
            if now - self._last_poll < self._min_interval:
                return asdict(self._cached)
            exe = self._exe

        parsed = self._query_nvidia_smi(exe)
        with self._lock:
            self._last_poll = time.time()
            if parsed is not None:
                parsed.enabled = self._enabled
                self._cached = parsed
            return asdict(self._cached)

    @staticmethod
    def _query_nvidia_smi(exe: str) -> GpuTelemetry | None:
        try:
            out = subprocess.check_output(
                [
                    exe,
                    "--query-gpu=name,power.draw,power.default_limit,temperature.gpu,utilization.gpu,clocks.gr,pstate",
                    "--format=csv,noheader,nounits",
                ],
                creationflags=CREATE_NO_WINDOW,
                timeout=1.5,
                text=True,
                stderr=subprocess.DEVNULL,
            )
            line = out.strip().splitlines()[0]
            parts = [p.strip() for p in line.split(",")]
            if len(parts) < 7:
                return None
            return GpuTelemetry(
                available=True,
                enabled=True,
                name=parts[0],
                power_w=_parse_float(parts[1]),
                power_limit_w=_parse_float(parts[2]),
                temp_c=_parse_int(parts[3]),
                util_percent=_parse_int(parts[4]),
                clock_mhz=_parse_int(parts[5]),
                pstate=parts[6] if parts[6].upper() not in ("[N/A]", "N/A") else "",
            )
        except Exception:
            return None
