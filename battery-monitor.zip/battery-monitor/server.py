"""Local HTTP server and standalone window launcher for Battery Monitor."""

from __future__ import annotations

import argparse
from collections import deque
import csv
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from urllib.error import URLError
from urllib.parse import parse_qs, urlparse
from urllib.request import urlopen
import webbrowser
try:
    import winreg
except ImportError:
    winreg = None
try:
    import winsound
except ImportError:
    winsound = None

from ajazz_mouse import AjazzMouseController
from ajazz_rgb import AjazzRgbController
from battery_reader import get_system_model, read_battery_telemetry, telemetry_to_dict
from electricity_report import ElectricityReportTracker, default_report_path
from power_metrics import (
    CpuPowerMonitor,
    GpuPowerMonitor,
    get_overlay_power_mode,
    get_power_plan_info,
    set_performance_profile,
)
from system_specs import SystemSpecsCache, get_uptime_seconds

STATIC_DIR = Path(__file__).resolve().parent / "static"
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
}

EDGE_CANDIDATES = [
    Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
    Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
]


def default_stats_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    return Path(base) / "BatteryMonitor" / "state_stats.json"


def classify_power_state(snapshot: dict) -> str:
    """Classify a telemetry snapshot into 'charge', 'discharge', or 'idle'."""
    if snapshot.get("charging"):
        return "charge"
    if snapshot.get("discharging"):
        return "discharge"
    rate = snapshot.get("rate_mw")
    if rate is not None:
        if rate > 0:
            return "charge"
        if rate < 0:
            return "discharge"
    return "idle"


def compute_derived_power_metrics(snapshot: dict) -> dict:
    """Compute C-rate, %/hr, capacity wear, and time-to-full/empty estimates."""
    rate_mw = snapshot.get("rate_mw")
    full_mwh = snapshot.get("full_charge_mwh")
    design_mwh = snapshot.get("design_mwh")
    rem_mwh = snapshot.get("remaining_mwh")

    c_rate: float | None = None
    pct_per_hour: float | None = None
    time_to_full_sec: int | None = None
    calc_runtime_sec: int | None = None

    if rate_mw is not None and full_mwh and full_mwh > 0:
        c_rate = round(rate_mw / full_mwh, 3)
        pct_per_hour = round((rate_mw / full_mwh) * 100.0, 1)

    if rate_mw is not None and rem_mwh is not None:
        if rate_mw > 0 and full_mwh and full_mwh > rem_mwh:
            time_to_full_sec = int(((full_mwh - rem_mwh) / rate_mw) * 3600)
        elif rate_mw < 0 and rem_mwh > 0:
            calc_runtime_sec = int((rem_mwh / abs(rate_mw)) * 3600)

    wear_mwh: int | None = None
    wear_percent: float | None = None
    if design_mwh and full_mwh is not None and design_mwh > 0:
        wear_mwh = max(0, design_mwh - full_mwh)
        wear_percent = round(max(0.0, 100.0 - (full_mwh / design_mwh) * 100.0), 1)

    return {
        "c_rate": c_rate,
        "pct_per_hour": pct_per_hour,
        "time_to_full_sec": time_to_full_sec,
        "calc_runtime_sec": calc_runtime_sec,
        "wear_mwh": wear_mwh,
        "wear_percent": wear_percent,
    }


class StateStatsTracker:
    """Tracks live, average, peak, and energy stats per state plus transition events."""

    STATES = ("charge", "idle", "discharge")

    def __init__(self, stats_path: Path | None = None, enable_sound: bool = False) -> None:
        self._stats_path = stats_path
        self._enable_sound = enable_sound
        self._stats = {s: self._empty_bucket() for s in self.STATES}
        self._events: deque[dict] = deque(maxlen=60)
        self._last_ts: float | None = None
        self._prev_state: str | None = None
        self._prev_ac: bool | None = None
        self._prev_saver: bool | None = None
        self._prev_profile: str | None = None
        self._charge_limit_80: bool = False
        self._limit_80_triggered: bool = False
        self._limit_80_dismissed: bool = False
        self._session_started_at = time.time()
        self._last_saved = 0.0
        self._load()

    @staticmethod
    def _empty_bucket() -> dict:
        return {
            "samples": 0,
            "duration_sec": 0.0,
            "energy_mwh": 0.0,
            "sum_power_w": 0.0,
            "power_samples": 0,
            "sum_current_a": 0.0,
            "current_samples": 0,
            "sum_voltage_v": 0.0,
            "voltage_samples": 0,
            "sum_gpu_w": 0.0,
            "gpu_samples": 0,
            "last_power_w": None,
            "peak_power_w": None,
            "last_current_a": None,
            "peak_current_a": None,
            "peak_c_rate": None,
            "last_voltage_v": None,
            "last_seen": None,
        }

    def _load(self) -> None:
        if not self._stats_path or not self._stats_path.is_file():
            return
        try:
            raw = json.loads(self._stats_path.read_text(encoding="utf-8"))
            saved_stats = raw.get("stats", {})
            for s in self.STATES:
                if isinstance(saved_stats.get(s), dict):
                    merged = self._empty_bucket()
                    for k in merged:
                        if k in saved_stats[s]:
                            merged[k] = saved_stats[s][k]
                    self._stats[s] = merged
            for ev in raw.get("events", []):
                if isinstance(ev, dict):
                    self._events.append(ev)
            if isinstance(raw.get("session_started_at"), (int, float)):
                self._session_started_at = float(raw["session_started_at"])
            if isinstance(raw.get("charge_limit_80"), bool):
                self._charge_limit_80 = raw["charge_limit_80"]
        except Exception:
            pass

    def save(self, force: bool = False) -> None:
        if not self._stats_path:
            return
        now = time.time()
        if not force and now - self._last_saved < 10.0:
            return
        try:
            self._stats_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "session_started_at": self._session_started_at,
                "charge_limit_80": self._charge_limit_80,
                "stats": self._stats,
                "events": list(self._events),
            }
            self._stats_path.write_text(json.dumps(payload), encoding="utf-8")
            self._last_saved = now
        except Exception:
            pass

    def reset(self, clear_events: bool = False) -> None:
        self._stats = {s: self._empty_bucket() for s in self.STATES}
        self._last_ts = None
        self._session_started_at = time.time()
        if clear_events:
            self._events.clear()
        self.save(force=True)

    def clear_events(self) -> None:
        self._events.clear()
        self.save(force=True)

    def _push_event(self, ts: float, event_type: str, detail: str, snapshot: dict) -> None:
        self._events.appendleft(
            {
                "t": round(ts, 1),
                "type": event_type,
                "detail": detail,
                "percentage": snapshot.get("percentage"),
                "voltage_v": snapshot.get("voltage_v"),
                "power_w": snapshot.get("power_w"),
            }
        )

    def record(self, snapshot: dict) -> str:
        state = classify_power_state(snapshot)
        bucket = self._stats[state]
        now = float(snapshot.get("timestamp") or time.time())

        if self._last_ts is not None:
            dt = max(0.0, min(5.0, now - self._last_ts))
        else:
            dt = 1.0
        self._last_ts = now

        bucket["samples"] += 1
        bucket["duration_sec"] += dt
        bucket["last_seen"] = now
        vv = snapshot.get("voltage_v")
        bucket["last_voltage_v"] = vv
        if vv is not None:
            bucket["sum_voltage_v"] += vv
            bucket["voltage_samples"] += 1

        gpu_w = (snapshot.get("gpu") or {}).get("power_w")
        if gpu_w is not None:
            bucket["sum_gpu_w"] += gpu_w
            bucket["gpu_samples"] += 1

        rate_mw = snapshot.get("rate_mw")
        if rate_mw is not None:
            bucket["energy_mwh"] += (rate_mw * dt) / 3600.0

        pw = snapshot.get("power_w")
        if pw is not None:
            bucket["sum_power_w"] += pw
            bucket["power_samples"] += 1
            bucket["last_power_w"] = pw
            if bucket["peak_power_w"] is None or abs(pw) > abs(bucket["peak_power_w"]):
                bucket["peak_power_w"] = pw

        cur = snapshot.get("current_a")
        if cur is not None:
            bucket["sum_current_a"] += cur
            bucket["current_samples"] += 1
            bucket["last_current_a"] = cur
            if bucket["peak_current_a"] is None or abs(cur) > abs(bucket["peak_current_a"]):
                bucket["peak_current_a"] = cur

        c_rate = snapshot.get("c_rate")
        if c_rate is not None:
            if bucket["peak_c_rate"] is None or abs(c_rate) > abs(bucket["peak_c_rate"]):
                bucket["peak_c_rate"] = c_rate

        ac = bool(snapshot.get("ac_online"))
        saver = bool(snapshot.get("battery_saver"))

        if self._prev_state is not None and state != self._prev_state:
            self._push_event(
                now,
                "state",
                f"{self._prev_state.capitalize()} -> {state.capitalize()}",
                snapshot,
            )
        elif self._prev_ac is not None and ac != self._prev_ac:
            self._push_event(
                now,
                "ac",
                "AC adapter connected" if ac else "AC adapter disconnected",
                snapshot,
            )

        if self._prev_saver is not None and saver != self._prev_saver:
            self._push_event(
                now,
                "saver",
                "Battery Saver enabled" if saver else "Battery Saver disabled",
                snapshot,
            )

        profile = snapshot.get("performance_profile")
        if self._prev_profile is not None and profile and profile != self._prev_profile:
            self._push_event(
                now,
                "mode",
                f"Performance mode -> {profile.capitalize()}",
                snapshot,
            )

        pct = snapshot.get("percentage")
        if not self._charge_limit_80 or not ac or (pct is not None and pct < 78):
            self._limit_80_triggered = False
            self._limit_80_dismissed = False
        elif self._charge_limit_80 and ac and state == "charge" and pct is not None and pct >= 80:
            if not self._limit_80_triggered:
                self._limit_80_triggered = True
                self._limit_80_dismissed = False
                self._push_event(
                    now,
                    "limit80",
                    "80% charge target reached — unplug AC adapter",
                    snapshot,
                )
                if self._enable_sound and winsound is not None:
                    try:
                        winsound.MessageBeep(winsound.MB_ICONASTERISK)
                    except Exception:
                        pass

        self._prev_state = state
        self._prev_ac = ac
        self._prev_saver = saver
        self._prev_profile = profile
        self.save(force=False)
        return state

    def summary(self) -> dict:
        out = {}
        for state in self.STATES:
            b = self._stats[state]
            avg_p = (
                round(b["sum_power_w"] / b["power_samples"], 2)
                if b["power_samples"] > 0
                else None
            )
            avg_c = (
                round(b["sum_current_a"] / b["current_samples"], 3)
                if b["current_samples"] > 0
                else None
            )
            avg_v = (
                round(b["sum_voltage_v"] / b["voltage_samples"], 3)
                if b["voltage_samples"] > 0
                else None
            )
            avg_gpu = (
                round(b["sum_gpu_w"] / b["gpu_samples"], 2)
                if b["gpu_samples"] > 0
                else None
            )
            out[state] = {
                "samples": b["samples"],
                "duration_sec": round(b["duration_sec"], 1),
                "energy_mwh": round(b["energy_mwh"], 1),
                "energy_wh": round(b["energy_mwh"] / 1000.0, 3),
                "last_power_w": b["last_power_w"],
                "avg_power_w": avg_p,
                "peak_power_w": b["peak_power_w"],
                "last_current_a": b["last_current_a"],
                "avg_current_a": avg_c,
                "peak_current_a": b["peak_current_a"],
                "peak_c_rate": b["peak_c_rate"],
                "last_voltage_v": b["last_voltage_v"],
                "avg_voltage_v": avg_v,
                "avg_gpu_w": avg_gpu,
                "last_seen": b["last_seen"],
            }
        return out

    def get_events(self) -> list[dict]:
        return list(self._events)

    def set_charge_limit_80(self, enabled: bool) -> dict:
        self._charge_limit_80 = bool(enabled)
        if not self._charge_limit_80:
            self._limit_80_triggered = False
            self._limit_80_dismissed = False
        self.save(force=True)
        return self.charge_guard_status()

    def dismiss_charge_limit_alert(self) -> dict:
        self._limit_80_dismissed = True
        return self.charge_guard_status()

    def charge_guard_status(self) -> dict:
        return {
            "enabled": self._charge_limit_80,
            "target_pct": 80,
            "triggered": self._limit_80_triggered,
            "dismissed": self._limit_80_dismissed,
            "hardware_cut_supported": False,
            "hardware_note": "Software alert only (hardware EC cut requires Acer Care Center / Admin WMI)",
        }

    @property
    def session_started_at(self) -> float:
        return self._session_started_at


class TelemetryStore:
    """Thread-safe ring buffer of live battery, CPU, and GPU power readings."""

    def __init__(
        self,
        maxlen: int = 900,
        stats_path: Path | None = None,
        enable_gpu: bool = True,
        enable_sound: bool = False,
    ) -> None:
        self._lock = threading.Lock()
        self._history: deque[dict] = deque(maxlen=maxlen)
        self._model = get_system_model()
        self._latest: dict | None = None
        self._state_tracker = StateStatsTracker(stats_path=stats_path, enable_sound=enable_sound)
        self._active_state = "idle"
        self._cpu_mon = CpuPowerMonitor()
        self._gpu_mon = GpuPowerMonitor(enabled=enable_gpu)
        self._specs_cache = SystemSpecsCache()
        ajazz_path = (Path(stats_path).parent / "ajazz_rgb.json") if stats_path else None
        self._ajazz = AjazzRgbController(state_path=ajazz_path)
        mouse_path = (Path(stats_path).parent / "ajazz_mouse.json") if stats_path else None
        self._ajazz_mouse = AjazzMouseController(state_path=mouse_path)
        self._electricity = ElectricityReportTracker(report_path=default_report_path(stats_path))

    def warmup_specs(self) -> None:
        self._specs_cache.warmup_async()

    def get_specs(self, refresh: bool = False) -> dict:
        return self._specs_cache.get_specs(refresh=refresh)

    def get_ajazz_state(self, force_battery: bool = False) -> dict:
        return self._ajazz.get_state(force_battery=force_battery)

    def apply_ajazz_lighting(self, payload: dict) -> dict:
        return self._ajazz.apply_lighting(payload)

    def sync_ajazz_clock(self) -> dict:
        return self._ajazz.sync_clock()

    def upload_ajazz_screen(self, payload: dict) -> dict:
        return self._ajazz.upload_lcd_image(payload)

    def get_ajazz_lcd_preview(self) -> bytes | None:
        return self._ajazz.get_lcd_preview_png()

    def get_ajazz_mouse_state(self, force_battery: bool = False) -> dict:
        return self._ajazz_mouse.get_state(force_battery=force_battery)

    def apply_ajazz_mouse_settings(self, payload: dict) -> dict:
        return self._ajazz_mouse.apply_settings(payload)

    def sample_once(self) -> dict:
        snapshot = telemetry_to_dict(read_battery_telemetry(device_model=self._model))
        snapshot.update(compute_derived_power_metrics(snapshot))

        plan_name, power_mode = get_power_plan_info(ac_online=bool(snapshot.get("ac_online")))
        overlay = get_overlay_power_mode()
        cpu_info = self._cpu_mon.read()
        gpu_info = self._gpu_mon.read()

        snapshot["power_plan"] = plan_name
        snapshot["power_mode"] = power_mode
        snapshot["performance_profile"] = overlay["profile_key"]
        snapshot["overlay_mode"] = overlay
        snapshot["cpu"] = cpu_info
        snapshot["gpu"] = gpu_info
        uptime_sec = get_uptime_seconds()

        with self._lock:
            active_state = self._state_tracker.record(snapshot)
            elec_live = self._electricity.record(snapshot, uptime_seconds=uptime_sec)
            snapshot["power_state_key"] = active_state
            snapshot["electricity"] = elec_live
            point = {
                "t": round(snapshot["timestamp"], 2),
                "voltage_v": snapshot["voltage_v"],
                "voltage_mv": snapshot["voltage_mv"],
                "current_a": snapshot["current_a"],
                "power_w": snapshot["power_w"],
                "rate_mw": snapshot["rate_mw"],
                "cpu_power_w": cpu_info.get("cpu_power_w"),
                "gpu_power_w": gpu_info.get("power_w"),
                "cpu_percent": cpu_info.get("cpu_percent"),
                "percentage": snapshot["percentage"],
                "remaining_mwh": snapshot["remaining_mwh"],
                "status": snapshot["status_label"],
                "state_key": active_state,
                "ac_online": snapshot["ac_online"],
                "charging": snapshot["charging"],
                "discharging": snapshot["discharging"],
            }
            self._latest = snapshot
            self._active_state = active_state
            self._history.append(point)
        return snapshot

    def set_gpu_polling(self, enabled: bool) -> bool:
        return self._gpu_mon.set_enabled(enabled)

    def set_charge_limit_80(self, enabled: bool) -> dict:
        with self._lock:
            status = self._state_tracker.set_charge_limit_80(enabled)
            if self._latest is not None:
                self._state_tracker.record(self._latest)
                status = self._state_tracker.charge_guard_status()
            return status

    def dismiss_charge_limit_alert(self) -> dict:
        with self._lock:
            return self._state_tracker.dismiss_charge_limit_alert()

    def reset_stats(self, clear_events: bool = False) -> None:
        with self._lock:
            self._state_tracker.reset(clear_events=clear_events)
            if self._latest is not None:
                self._active_state = self._state_tracker.record(self._latest)

    def clear_events(self) -> None:
        with self._lock:
            self._state_tracker.clear_events()

    def persist(self) -> None:
        with self._lock:
            self._state_tracker.save(force=True)
            self._electricity.save(force=True)

    def get_electricity_report(self) -> dict:
        with self._lock:
            report = self._electricity.summary()
        report["autostart"] = get_autostart_status()
        return report

    def update_electricity_settings(self, payload: dict) -> dict:
        with self._lock:
            return self._electricity.update_settings(payload)

    def reset_electricity_report(self) -> dict:
        with self._lock:
            report = self._electricity.reset_history()
            if self._latest is not None:
                self._electricity.record(self._latest, uptime_seconds=get_uptime_seconds())
                report = self._electricity.summary()
            return report

    def export_electricity_csv(self) -> str:
        with self._lock:
            return self._electricity.export_csv()

    def get_payload(self, limit: int = 300) -> dict:
        with self._lock:
            latest = self._latest
            history = list(self._history)[-max(1, min(limit, len(self._history) or 1)) :]
            state_stats = self._state_tracker.summary()
            active_state = self._active_state
            events = self._state_tracker.get_events()
            session_started_at = self._state_tracker.session_started_at
            charge_guard = self._state_tracker.charge_guard_status()
            electricity = self._electricity.summary()
        if latest is None:
            latest = self.sample_once()
            with self._lock:
                history = list(self._history)
                state_stats = self._state_tracker.summary()
                active_state = self._active_state
                events = self._state_tracker.get_events()
                session_started_at = self._state_tracker.session_started_at
                charge_guard = self._state_tracker.charge_guard_status()
                electricity = self._electricity.summary()
        return {
            "latest": latest,
            "history": history,
            "active_state": active_state,
            "state_stats": state_stats,
            "events": events,
            "session_started_at": session_started_at,
            "charge_guard": charge_guard,
            "electricity": electricity,
        }

    def export_csv(self) -> str:
        with self._lock:
            rows = list(self._history)
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(
            [
                "timestamp",
                "state",
                "voltage_v",
                "voltage_mv",
                "current_a",
                "power_w",
                "rate_mw",
                "cpu_power_w",
                "gpu_power_w",
                "cpu_percent",
                "percentage",
                "remaining_mwh",
                "status",
            ]
        )
        for row in rows:
            iso = datetime.fromtimestamp(row["t"]).isoformat(timespec="seconds")
            writer.writerow(
                [
                    iso,
                    row.get("state_key"),
                    row["voltage_v"],
                    row["voltage_mv"],
                    row["current_a"],
                    row["power_w"],
                    row["rate_mw"],
                    row.get("cpu_power_w"),
                    row.get("gpu_power_w"),
                    row.get("cpu_percent"),
                    row["percentage"],
                    row["remaining_mwh"],
                    row["status"],
                ]
            )
        return buf.getvalue()


def _make_handler(store: TelemetryStore, shutdown_event: threading.Event):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args) -> None:
            return

        def _read_json_body(self, max_bytes: int = 8192) -> dict:
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                length = 0
            if length <= 0 or length > max_bytes:
                return {}
            try:
                return json.loads(self.rfile.read(length).decode("utf-8"))
            except Exception:
                return {}

        def _send_bytes(
            self, status: int, body: bytes, content_type: str, extra_headers: dict | None = None
        ) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            if extra_headers:
                for k, v in extra_headers.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            parsed = urlparse(self.path)
            path = parsed.path

            if path == "/api/telemetry":
                qs = parse_qs(parsed.query)
                try:
                    limit = int(qs.get("limit", ["300"])[0])
                except ValueError:
                    limit = 300
                limit = max(10, min(900, limit))
                payload = json.dumps(store.get_payload(limit=limit)).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/specs":
                qs = parse_qs(parsed.query)
                refresh = qs.get("refresh", ["0"])[0] in ("1", "true", "yes")
                payload = json.dumps(store.get_specs(refresh=refresh)).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/ajazz":
                qs = parse_qs(parsed.query)
                refresh = qs.get("refresh", ["0"])[0] in ("1", "true", "yes")
                payload = json.dumps(store.get_ajazz_state(force_battery=refresh)).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/ajazz/lcd-preview":
                png = store.get_ajazz_lcd_preview()
                if not png:
                    self._send_bytes(HTTPStatus.NOT_FOUND, b"No preview", "text/plain; charset=utf-8")
                    return
                self._send_bytes(HTTPStatus.OK, png, "image/png")
                return

            if path == "/api/ajazz-mouse":
                qs = parse_qs(parsed.query)
                refresh = qs.get("refresh", ["0"])[0] in ("1", "true", "yes")
                payload = json.dumps(store.get_ajazz_mouse_state(force_battery=refresh)).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/export.csv":
                csv_data = store.export_csv().encode("utf-8")
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                self._send_bytes(
                    HTTPStatus.OK,
                    csv_data,
                    "text/csv; charset=utf-8",
                    {"Content-Disposition": f'attachment; filename="battery_log_{stamp}.csv"'},
                )
                return

            if path == "/api/electricity":
                payload = json.dumps(store.get_electricity_report()).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/autostart":
                payload = json.dumps(get_autostart_status()).encode("utf-8")
                self._send_bytes(HTTPStatus.OK, payload, "application/json; charset=utf-8")
                return

            if path == "/api/electricity/export.csv":
                csv_data = store.export_electricity_csv().encode("utf-8")
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                self._send_bytes(
                    HTTPStatus.OK,
                    csv_data,
                    "text/csv; charset=utf-8",
                    {"Content-Disposition": f'attachment; filename="electricity_report_{stamp}.csv"'},
                )
                return

            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            target = (STATIC_DIR / rel).resolve()
            if not str(target).startswith(str(STATIC_DIR.resolve())) or not target.is_file():
                self._send_bytes(HTTPStatus.NOT_FOUND, b"Not found", "text/plain; charset=utf-8")
                return

            ctype = CONTENT_TYPES.get(target.suffix.lower(), "application/octet-stream")
            self._send_bytes(HTTPStatus.OK, target.read_bytes(), ctype)

        def do_POST(self) -> None:
            path = urlparse(self.path).path
            if path == "/api/reset-stats":
                body = self._read_json_body()
                store.reset_stats(clear_events=bool(body.get("clear_events", False)))
                self._send_bytes(HTTPStatus.OK, b'{"ok":true}', "application/json")
                return
            if path == "/api/clear-events":
                store.clear_events()
                self._send_bytes(HTTPStatus.OK, b'{"ok":true}', "application/json")
                return
            if path == "/api/gpu-polling":
                body = self._read_json_body()
                enabled = store.set_gpu_polling(bool(body.get("enabled", True)))
                store.sample_once()
                self._send_bytes(
                    HTTPStatus.OK,
                    json.dumps({"ok": True, "enabled": enabled}).encode("utf-8"),
                    "application/json",
                )
                return
            if path == "/api/charge-limit":
                body = self._read_json_body()
                guard = store.set_charge_limit_80(bool(body.get("enabled", False)))
                self._send_bytes(
                    HTTPStatus.OK,
                    json.dumps({"ok": True, "charge_guard": guard}).encode("utf-8"),
                    "application/json",
                )
                return
            if path == "/api/charge-limit-dismiss":
                guard = store.dismiss_charge_limit_alert()
                self._send_bytes(
                    HTTPStatus.OK,
                    json.dumps({"ok": True, "charge_guard": guard}).encode("utf-8"),
                    "application/json",
                )
                return
            if path == "/api/performance-mode":
                body = self._read_json_body()
                mode = str(body.get("mode", "")).strip().lower()
                try:
                    result = set_performance_profile(mode)
                    store.sample_once()
                    self._send_bytes(
                        HTTPStatus.OK,
                        json.dumps(result).encode("utf-8"),
                        "application/json",
                    )
                except ValueError as exc:
                    self._send_bytes(
                        HTTPStatus.BAD_REQUEST,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                except Exception as exc:
                    self._send_bytes(
                        HTTPStatus.INTERNAL_SERVER_ERROR,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                return
            ajazz_post_routes = {
                "/api/ajazz/lighting": store.apply_ajazz_lighting,
                "/api/ajazz/clock": lambda _body: store.sync_ajazz_clock(),
                "/api/ajazz/screen": store.upload_ajazz_screen,
                "/api/ajazz-mouse/settings": store.apply_ajazz_mouse_settings,
            }
            if path in ajazz_post_routes:
                max_len = 8 * 1024 * 1024 if path == "/api/ajazz/screen" else 8192
                body = self._read_json_body(max_bytes=max_len)
                fn = ajazz_post_routes[path]
                try:
                    state = fn(body)
                    self._send_bytes(
                        HTTPStatus.OK,
                        json.dumps({"ok": True, **state}).encode("utf-8"),
                        "application/json",
                    )
                except ValueError as exc:
                    self._send_bytes(
                        HTTPStatus.BAD_REQUEST,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                except LookupError as exc:
                    self._send_bytes(
                        HTTPStatus.CONFLICT,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                except Exception as exc:
                    self._send_bytes(
                        HTTPStatus.INTERNAL_SERVER_ERROR,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                return
            if path == "/api/electricity/settings":
                body = self._read_json_body()
                try:
                    report = store.update_electricity_settings(body)
                    self._send_bytes(
                        HTTPStatus.OK,
                        json.dumps({"ok": True, **report}).encode("utf-8"),
                        "application/json",
                    )
                except ValueError as exc:
                    self._send_bytes(
                        HTTPStatus.BAD_REQUEST,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                return
            if path == "/api/electricity/reset":
                report = store.reset_electricity_report()
                self._send_bytes(
                    HTTPStatus.OK,
                    json.dumps({"ok": True, **report}).encode("utf-8"),
                    "application/json",
                )
                return
            if path == "/api/autostart":
                body = self._read_json_body()
                try:
                    status = set_autostart_enabled(bool(body.get("enabled", False)))
                    self._send_bytes(
                        HTTPStatus.OK,
                        json.dumps({"ok": True, **status}).encode("utf-8"),
                        "application/json",
                    )
                except OSError as exc:
                    self._send_bytes(
                        HTTPStatus.INTERNAL_SERVER_ERROR,
                        json.dumps({"ok": False, "error": str(exc)}).encode("utf-8"),
                        "application/json",
                    )
                return
            if path == "/api/shutdown":
                self._send_bytes(HTTPStatus.OK, b'{"ok":true}', "application/json")
                shutdown_event.set()
                return
            self._send_bytes(HTTPStatus.NOT_FOUND, b"Not found", "text/plain; charset=utf-8")

    return Handler


AUTOSTART_RUN_SUBKEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
AUTOSTART_VALUE_NAME = "BatteryPowerMonitor"


def build_autostart_command() -> str:
    """Return the quoted pythonw command line to start the background tracker at login."""
    exe = Path(sys.executable)
    pythonw_candidate = exe.with_name("pythonw.exe")
    if pythonw_candidate.is_file():
        exe = pythonw_candidate
    return f'"{exe}" "{Path(__file__).resolve()}" --no-open'


def get_autostart_status(
    subkey: str = AUTOSTART_RUN_SUBKEY,
    value_name: str = AUTOSTART_VALUE_NAME,
) -> dict:
    """Query whether Windows per-user Run autostart is configured."""
    if winreg is None:
        return {"supported": False, "enabled": False, "command": None}
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, subkey, 0, winreg.KEY_READ) as key:
            cmd, _ = winreg.QueryValueEx(key, value_name)
        return {"supported": True, "enabled": bool(cmd), "command": str(cmd)}
    except FileNotFoundError:
        return {"supported": True, "enabled": False, "command": None}
    except OSError:
        return {"supported": False, "enabled": False, "command": None}


def set_autostart_enabled(
    enabled: bool,
    subkey: str = AUTOSTART_RUN_SUBKEY,
    value_name: str = AUTOSTART_VALUE_NAME,
) -> dict:
    """Enable or disable Windows per-user Run autostart."""
    if winreg is None:
        raise OSError("Windows Registry is not available on this platform.")
    with winreg.CreateKeyEx(
        winreg.HKEY_CURRENT_USER,
        subkey,
        0,
        winreg.KEY_SET_VALUE | winreg.KEY_READ,
    ) as key:
        if enabled:
            winreg.SetValueEx(key, value_name, 0, winreg.REG_SZ, build_autostart_command())
        else:
            try:
                winreg.DeleteValue(key, value_name)
            except FileNotFoundError:
                pass
    return get_autostart_status(subkey=subkey, value_name=value_name)


def _is_instance_running(port: int, timeout: float = 0.6) -> bool:
    """Return True if a Battery Monitor HTTP instance already responds on localhost:port."""
    try:
        with urlopen(f"http://127.0.0.1:{port}/api/electricity", timeout=timeout) as resp:
            return resp.status == 200
    except (URLError, OSError, TimeoutError, ValueError):
        return False


def _pick_port(preferred: int) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex(("127.0.0.1", preferred)) != 0:
            return preferred
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _find_edge() -> Path | None:
    for candidate in EDGE_CANDIDATES:
        if candidate.is_file():
            return candidate
    found = shutil.which("msedge")
    return Path(found) if found else None


def _open_app_window(url: str, use_browser: bool = False) -> tuple[subprocess.Popen | None, str | None]:
    """Open the UI in standalone Edge app mode or fallback browser."""
    edge_path = None if use_browser else _find_edge()
    if edge_path is not None:
        temp_profile = tempfile.mkdtemp(prefix="battery_monitor_edge_")
        edge_proc = subprocess.Popen(
            [
                str(edge_path),
                f"--app={url}",
                "--window-size=500,880",
                f"--user-data-dir={temp_profile}",
                "--no-first-run",
                "--no-default-browser-check",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return edge_proc, temp_profile
    webbrowser.open(url)
    return None, None


def main() -> None:
    parser = argparse.ArgumentParser(description="Battery & Power Monitor app")
    parser.add_argument("--port", type=int, default=18765, help="Local server port")
    parser.add_argument(
        "--browser",
        action="store_true",
        help="Open in default browser instead of standalone app window",
    )
    parser.add_argument("--no-open", action="store_true", help="Start server without opening a window")
    args = parser.parse_args()

    if _is_instance_running(args.port):
        existing_url = f"http://127.0.0.1:{args.port}/"
        print(f"Battery Monitor already running at {existing_url}")
        if args.no_open:
            return
        edge_proc, temp_profile = _open_app_window(existing_url, use_browser=args.browser)
        try:
            if edge_proc is not None:
                while edge_proc.poll() is None:
                    time.sleep(0.3)
        except KeyboardInterrupt:
            pass
        finally:
            if temp_profile and os.path.isdir(temp_profile):
                shutil.rmtree(temp_profile, ignore_errors=True)
        return

    store = TelemetryStore(maxlen=900, stats_path=default_stats_path(), enable_sound=True)
    store.sample_once()
    store.warmup_specs()

    shutdown_event = threading.Event()

    def sampler_loop() -> None:
        while not shutdown_event.wait(1.0):
            try:
                store.sample_once()
            except Exception:
                pass

    sampler = threading.Thread(target=sampler_loop, daemon=True)
    sampler.start()

    port = _pick_port(args.port)
    server = ThreadingHTTPServer(("127.0.0.1", port), _make_handler(store, shutdown_event))
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    url = f"http://127.0.0.1:{port}/"
    print(f"Battery Monitor running at {url}")

    edge_proc = None
    temp_profile = None
    try:
        if not args.no_open:
            edge_proc, temp_profile = _open_app_window(url, use_browser=args.browser)

        if edge_proc is not None:
            while not shutdown_event.is_set():
                if edge_proc.poll() is not None:
                    break
                time.sleep(0.3)
        else:
            while not shutdown_event.is_set():
                time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown_event.set()
        store.persist()
        server.shutdown()
        server.server_close()
        if temp_profile and os.path.isdir(temp_profile):
            shutil.rmtree(temp_profile, ignore_errors=True)


if __name__ == "__main__":
    main()
