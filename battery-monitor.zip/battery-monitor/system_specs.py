"""Hardware and OS specification collector for Windows laptops."""

from __future__ import annotations

import ctypes
import json
import subprocess
import threading
import time

CREATE_NO_WINDOW = 0x08000000

SMBIOS_MEMORY_TYPES = {
    20: "DDR",
    21: "DDR2",
    24: "DDR3",
    26: "DDR4",
    30: "LPDDR4",
    34: "DDR5",
    35: "LPDDR5",
}

_PS_SPECS_SCRIPT = r"""
$cs = Get-CimInstance Win32_ComputerSystem
$csp = Get-CimInstance Win32_ComputerSystemProduct
$bb = Get-CimInstance Win32_BaseBoard
$bios = Get-CimInstance Win32_BIOS
$os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$ram = @(Get-CimInstance Win32_PhysicalMemory)
$gpu = @(Get-CimInstance Win32_VideoController)
$pd = @(Get-PhysicalDisk -ErrorAction SilentlyContinue)
$gd = @(Get-Disk -ErrorAction SilentlyContinue)
$vols = @(Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter })
$mons = @(Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorID -ErrorAction SilentlyContinue)
$nets = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)

$diskList = @()
if ($pd.Count -gt 0) {
  foreach ($d in $pd) {
    $matchGd = $gd | Where-Object { $_.FriendlyName -eq $d.FriendlyName -and [math]::Abs($_.Size - $d.Size) -lt 104857600 } | Select-Object -First 1
    $diskList += [PSCustomObject]@{
      FriendlyName = $d.FriendlyName
      MediaType = [string]$d.MediaType
      BusType = [string]$d.BusType
      SizeGB = [math]::Round($d.Size / 1GB, 2)
      PartitionStyle = if ($matchGd) { [string]$matchGd.PartitionStyle } else { "" }
      OperationalStatus = if ($matchGd) { [string]$matchGd.OperationalStatus } else { [string]$d.OperationalStatus }
    }
  }
} else {
  foreach ($d in $gd) {
    $diskList += [PSCustomObject]@{
      FriendlyName = $d.FriendlyName
      MediaType = ""
      BusType = [string]$d.BusType
      SizeGB = [math]::Round($d.Size / 1GB, 2)
      PartitionStyle = [string]$d.PartitionStyle
      OperationalStatus = [string]$d.OperationalStatus
    }
  }
}

[PSCustomObject]@{
  system = [PSCustomObject]@{
    manufacturer = $cs.Manufacturer
    model = $cs.Model
    product_name = $csp.Name
    family = $cs.SystemFamily
    baseboard = ("$($bb.Manufacturer) $($bb.Product)").Trim()
    bios_version = $bios.SMBIOSBIOSVersion
    os_name = "$($os.Caption) ($($os.OSArchitecture), Build $($os.BuildNumber))"
    last_boot = if ($os.LastBootUpTime) { $os.LastBootUpTime.ToString("yyyy-MM-dd HH:mm:ss") } else { "" }
  }
  cpu = [PSCustomObject]@{
    name = ($cpu.Name -replace '\s+', ' ').Trim()
    cores = $cpu.NumberOfCores
    threads = $cpu.NumberOfLogicalProcessors
    max_clock_mhz = $cpu.MaxClockSpeed
    l2_cache_kb = $cpu.L2CacheSize
    l3_cache_kb = $cpu.L3CacheSize
  }
  ram = [PSCustomObject]@{
    total_usable_gb = [math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
    modules = @($ram | ForEach-Object {
      [PSCustomObject]@{
        slot = ($_.DeviceLocator -replace '\s+', ' ').Trim()
        manufacturer = ($_.Manufacturer -replace '\s+', ' ').Trim()
        part_number = ($_.PartNumber -replace '\s+', ' ').Trim()
        capacity_gb = [math]::Round($_.Capacity / 1GB, 2)
        rated_mhz = $_.Speed
        configured_mhz = $_.ConfiguredClockSpeed
        memory_type_id = $_.SMBIOSMemoryType
      }
    })
  }
  gpus = @($gpu | ForEach-Object {
    [PSCustomObject]@{
      name = $_.Name
      vram_gb = if ($_.AdapterRAM) { [math]::Round($_.AdapterRAM / 1GB, 2) } else { $null }
      width = $_.CurrentHorizontalResolution
      height = $_.CurrentVerticalResolution
      refresh_hz = $_.CurrentRefreshRate
      driver_version = $_.DriverVersion
    }
  })
  displays = @($mons | ForEach-Object {
    [PSCustomObject]@{
      manufacturer = (($_.ManufacturerName | Where-Object { $_ } | ForEach-Object { [char]$_ }) -join '').Trim()
      name = (($_.UserFriendlyName | Where-Object { $_ } | ForEach-Object { [char]$_ }) -join '').Trim()
    }
  })
  disks = $diskList
  volumes = @($vols | Sort-Object DriveLetter | ForEach-Object {
    $sz = [math]::Round($_.Size / 1GB, 2)
    $fr = [math]::Round($_.SizeRemaining / 1GB, 2)
    [PSCustomObject]@{
      drive = "$($_.DriveLetter):"
      label = [string]$_.FileSystemLabel
      filesystem = [string]$_.FileSystem
      size_gb = $sz
      free_gb = $fr
      used_gb = [math]::Round($sz - $fr, 2)
    }
  })
  network = @($nets | ForEach-Object {
    [PSCustomObject]@{
      name = $_.Name
      description = $_.InterfaceDescription
      status = [string]$_.Status
      link_speed = [string]$_.LinkSpeed
    }
  })
} | ConvertTo-Json -Depth 5
"""


def get_uptime_seconds() -> int:
    """Return Windows system uptime in seconds via GetTickCount64."""
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=False)
        kernel32.GetTickCount64.restype = ctypes.c_uint64
        return int(kernel32.GetTickCount64() // 1000)
    except Exception:
        return 0


def _enrich_specs(raw: dict) -> dict:
    ram = raw.get("ram") or {}
    modules = ram.get("modules") or []
    configured_speeds = [m["configured_mhz"] for m in modules if m.get("configured_mhz")]
    mem_types = {
        SMBIOS_MEMORY_TYPES.get(m.get("memory_type_id"), "")
        for m in modules
        if m.get("memory_type_id")
    }
    mem_types.discard("")
    for m in modules:
        m["memory_type"] = SMBIOS_MEMORY_TYPES.get(m.get("memory_type_id"), "RAM")
    ram["running_mhz"] = min(configured_speeds) if configured_speeds else None
    ram["memory_type"] = ", ".join(sorted(mem_types)) if mem_types else "DDR"
    ram["total_installed_gb"] = round(sum(float(m.get("capacity_gb") or 0) for m in modules), 2)
    raw["ram"] = ram
    raw["collected_at"] = time.time()
    return raw


def collect_system_specs() -> dict:
    """Collect hardware and OS specifications via PowerShell CIM."""
    out = subprocess.check_output(
        [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            _PS_SPECS_SCRIPT,
        ],
        creationflags=CREATE_NO_WINDOW,
        timeout=30,
        text=True,
        stderr=subprocess.PIPE,
    )
    data = json.loads(out)
    return _enrich_specs(data)


class SystemSpecsCache:
    """Thread-safe cached hardware specification store with background warmup."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._specs: dict | None = None
        self._error: str | None = None
        self._loading = False

    def warmup_async(self) -> None:
        t = threading.Thread(target=self.get_specs, kwargs={"refresh": False}, daemon=True)
        t.start()

    def get_specs(self, refresh: bool = False) -> dict:
        with self._lock:
            if not refresh and self._specs is not None:
                result = dict(self._specs)
                result["uptime_seconds"] = get_uptime_seconds()
                return result
            if self._loading:
                # Avoid spawning duplicate PowerShell scans concurrently.
                pass

        with self._lock:
            self._loading = True
        try:
            data = collect_system_specs()
            with self._lock:
                self._specs = data
                self._error = None
                result = dict(self._specs)
                result["uptime_seconds"] = get_uptime_seconds()
                return result
        except Exception as exc:
            with self._lock:
                self._error = str(exc)
                if self._specs is not None:
                    result = dict(self._specs)
                    result["uptime_seconds"] = get_uptime_seconds()
                    result["warning"] = self._error
                    return result
                return {
                    "error": self._error,
                    "uptime_seconds": get_uptime_seconds(),
                }
        finally:
            with self._lock:
                self._loading = False
