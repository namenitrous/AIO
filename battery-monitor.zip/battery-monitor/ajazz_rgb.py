"""AJAZZ AK820 Pro RGB lighting controller for Windows (USB-C wired & 2.4G dongle).

Uses pure Python stdlib (`ctypes` + Win32 SetupAPI/HID) with zero external
dependencies. Supports both official device links:
  - USB-C wired (`VID 0x0C45`, `PID 0x8009` / `0x800A`, usage page `0xFF13`):
    64-byte feature report transactions (`0x04 0x18`, `0x04 0x13`, data, `0x04 0x02`, `0x04 0xF0`).
  - 2.4 GHz wireless dongle (`VID 0x0C45`, `PID 0xFDFD`, `MI_03`, usage page `0xFF60`):
    33-byte HID output reports (`WriteFile`) with `[0x00, 0x05, 0x10, 0x00, ...]` + checksum byte.
"""

from __future__ import annotations

import base64
from datetime import datetime
import json
import os
from pathlib import Path
import sqlite3
import threading
import time
from typing import Callable

from win32_hid import (
    clamp,
    enumerate_hid_interfaces,
    format_hex_color,
    get_feature_report,
    open_hid_handle,
    parse_hex_color,
    set_feature_report,
    write_and_read_report,
    write_and_read_sequence,
    write_output_report,
)

VID_SONIX = 0x0C45
WIRED_PIDS = (0x8009, 0x800A)
DONGLE_PID = 0xFDFD

USAGE_PAGE_WIRED_CTRL = 0xFF13
USAGE_PAGE_WIRED_SCREEN = 0xFF68
USAGE_PAGE_DONGLE_CTRL = 0xFF60

MAX_BRIGHTNESS = 5
MAX_SPEED = 5

SLEEP_LEVELS: tuple[dict, ...] = (
    {"id": 0, "label": "Never"},
    {"id": 1, "label": "1 min"},
    {"id": 2, "label": "5 min"},
    {"id": 3, "label": "30 min"},
)

TFT_WIDTH = 128
TFT_HEIGHT = 128
TFT_FRAME_BYTES = TFT_WIDTH * TFT_HEIGHT * 2
TFT_MAX_FRAMES = 140
TFT_BLOCK_SIZE = 4096

LIGHTING_MODES: tuple[dict, ...] = (
    {"id": 1, "key": "static", "label": "Static", "color": True, "speed": False, "dir": "none"},
    {"id": 2, "key": "single_on", "label": "Single On", "color": True, "speed": True, "dir": "none"},
    {"id": 3, "key": "single_off", "label": "Single Off", "color": True, "speed": True, "dir": "none"},
    {"id": 4, "key": "glittering", "label": "Glittering", "color": True, "speed": True, "dir": "none"},
    {"id": 5, "key": "falling", "label": "Falling", "color": True, "speed": True, "dir": "none"},
    {"id": 6, "key": "colourful", "label": "Colourful", "color": False, "speed": True, "dir": "none"},
    {"id": 7, "key": "breath", "label": "Breath", "color": True, "speed": True, "dir": "none"},
    {"id": 8, "key": "spectrum", "label": "Spectrum", "color": False, "speed": True, "dir": "none"},
    {"id": 9, "key": "outward", "label": "Outward", "color": True, "speed": True, "dir": "none"},
    {"id": 10, "key": "scrolling", "label": "Scrolling", "color": True, "speed": True, "dir": "ud"},
    {"id": 11, "key": "rolling", "label": "Rolling", "color": True, "speed": True, "dir": "lr"},
    {"id": 12, "key": "rotating", "label": "Rotating", "color": True, "speed": True, "dir": "lr"},
    {"id": 13, "key": "explode", "label": "Explode", "color": True, "speed": True, "dir": "none"},
    {"id": 14, "key": "launch", "label": "Launch", "color": True, "speed": True, "dir": "none"},
    {"id": 15, "key": "ripples", "label": "Ripples", "color": True, "speed": True, "dir": "none"},
    {"id": 16, "key": "flowing", "label": "Flowing", "color": True, "speed": True, "dir": "lr"},
    {"id": 17, "key": "pulsating", "label": "Pulsating", "color": True, "speed": True, "dir": "none"},
    {"id": 18, "key": "tilt", "label": "Tilt", "color": True, "speed": True, "dir": "lr"},
    {"id": 19, "key": "shuttle", "label": "Shuttle", "color": True, "speed": True, "dir": "none"},
    {"id": 0, "key": "off", "label": "LED Off", "color": False, "speed": False, "dir": "none"},
)

VALID_MODE_IDS = {m["id"] for m in LIGHTING_MODES}

DIRECTIONS: tuple[dict, ...] = (
    {"id": 0, "key": "left", "label": "Left"},
    {"id": 1, "key": "down", "label": "Down"},
    {"id": 2, "key": "up", "label": "Up"},
    {"id": 3, "key": "right", "label": "Right"},
)

COLOR_PALETTE: tuple[dict, ...] = (
    {"name": "White", "hex": "#ffffff"},
    {"name": "Red", "hex": "#ff0000"},
    {"name": "Orange", "hex": "#ff6a00"},
    {"name": "Yellow", "hex": "#ffd400"},
    {"name": "Green", "hex": "#00e640"},
    {"name": "Cyan", "hex": "#00e5ff"},
    {"name": "Blue", "hex": "#1a73e8"},
    {"name": "Purple", "hex": "#8b3dff"},
)

def _default_state_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "BatteryMonitor" / "ajazz_rgb.json"


def _default_vendor_db_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "AJAZZ AK820Pro Files" / "db" / "AJAZZ AK820Pro_datav1.db"


def _control_packet64(cmd: int, byte2: int = 0, byte8: int = 0, byte9: int = 0) -> bytes:
    pkt = bytearray(64)
    pkt[0] = 0x04
    pkt[1] = cmd & 0xFF
    pkt[2] = byte2 & 0xFF
    pkt[8] = byte8 & 0xFF
    pkt[9] = byte9 & 0xFF
    return bytes(pkt)


def build_wired_lighting_sequence(
    mode: int,
    r: int,
    g: int,
    b: int,
    rainbow: bool,
    brightness: int,
    speed: int,
    direction: int,
) -> list[bytes]:
    """Build the 5x64-byte feature-report sequence for USB-C wired AK820 Pro."""
    mode = int(mode)
    if mode not in VALID_MODE_IDS:
        raise ValueError(f"Invalid lighting mode: {mode}")

    data = bytearray(64)
    data[0] = mode
    if mode != 0:
        data[1] = clamp(r, 0, 255)
        data[2] = clamp(g, 0, 255)
        data[3] = clamp(b, 0, 255)
        data[8] = 1 if rainbow else 0
        data[9] = clamp(brightness, 0, MAX_BRIGHTNESS)
        data[10] = clamp(speed, 0, MAX_SPEED)
        data[11] = clamp(direction, 0, 3)
    data[14] = 0xAA
    data[15] = 0x55

    return [
        _control_packet64(0x18),
        _control_packet64(0x13, byte8=0x01),
        bytes(data),
        _control_packet64(0x02),
        _control_packet64(0xF0),
    ]


def build_dongle_lighting_packet(
    mode: int,
    r: int,
    g: int,
    b: int,
    rainbow: bool,
    brightness: int,
    speed: int,
    direction: int,
) -> bytes:
    """Build the 33-byte HID output report for the 2.4 GHz dongle (PID 0xFDFD, MI_03)."""
    mode = int(mode)
    if mode not in VALID_MODE_IDS:
        raise ValueError(f"Invalid lighting mode: {mode}")

    pkt = bytearray(33)
    pkt[0] = 0x00  # Report ID
    pkt[1] = 0x05
    pkt[2] = 0x10
    pkt[3] = 0x00
    pkt[4] = mode
    if mode != 0:
        pkt[5] = clamp(r, 0, 255)
        pkt[6] = clamp(g, 0, 255)
        pkt[7] = clamp(b, 0, 255)
        pkt[12] = 1 if rainbow else 0
        pkt[13] = clamp(brightness, 0, MAX_BRIGHTNESS)
        pkt[14] = clamp(speed, 0, MAX_SPEED)
        pkt[15] = clamp(direction, 0, 3)
    pkt[18] = 0xAA
    pkt[19] = 0x55
    pkt[32] = sum(pkt[1:32]) & 0xFF
    return bytes(pkt)


def build_rf_frame(order: int, data: bytes, chunk_idx: int = 0) -> bytes:
    """Build a 33-byte 2.4G receiver frame (`[0x00, order, len, chunk, <=28B, sum]`)."""
    chunk = data[:28]
    pkt = bytearray(33)
    pkt[0] = 0x00
    pkt[1] = order & 0xFF
    pkt[2] = len(chunk) & 0xFF
    pkt[3] = chunk_idx & 0xFF
    pkt[4 : 4 + len(chunk)] = chunk
    pkt[32] = sum(pkt[1:32]) & 0xFF
    return bytes(pkt)


def build_rf_battery_query() -> bytes:
    """Build 2.4G keyboard battery query packet (`order = 0x20`)."""
    return build_rf_frame(0x20, b"\x00")


def parse_rf_battery_reply(raw: bytes | None) -> dict | None:
    """Parse 2.4G keyboard battery reply (`[0x00?, 0x20, 0x01, 0x00, percent]`)."""
    if not raw:
        return None
    if len(raw) >= 5 and raw[0] == 0x00 and raw[1] == 0x20 and raw[2] == 0x01 and raw[3] == 0x00:
        pct = raw[4]
    elif len(raw) >= 4 and raw[0] == 0x20 and raw[1] == 0x01 and raw[2] == 0x00:
        pct = raw[3]
    else:
        return None
    if not (1 <= pct <= 100):
        return None
    return {"percent": int(pct), "status": "ok"}


def _clock_data64(dt: datetime) -> bytearray:
    data = bytearray(64)
    data[1] = 0x01
    data[2] = 0x5A
    data[3] = clamp(dt.year - 2000, 0, 99)
    data[4] = dt.month
    data[5] = dt.day
    data[6] = dt.hour
    data[7] = dt.minute
    data[8] = dt.second
    data[10] = 0x04
    data[62] = 0xAA
    data[63] = 0x55
    return data


def build_wired_clock_sequence(dt: datetime | None = None) -> list[bytes]:
    """Build 4x64-byte feature-report clock sync sequence for USB-C AK820 Pro."""
    now = dt or datetime.now()
    return [
        _control_packet64(0x18),
        _control_packet64(0x28, byte8=0x01),
        bytes(_clock_data64(now)),
        _control_packet64(0x02),
    ]


def build_dongle_clock_packet(dt: datetime | None = None) -> bytes:
    """Build 33-byte 2.4G receiver RTC clock sync packet (`order = 0x0C`)."""
    now = dt or datetime.now()
    short = bytearray(_clock_data64(now)[:14]) + bytearray([0xAA, 0x55])
    # Receiver uses Sunday = 0 weekday at byte 10 of rf_short (Python Monday=0 -> (wd+1)%7)
    short[10] = (now.weekday() + 1) % 7
    return build_rf_frame(0x0C, bytes(short))


def _sleep_data64(
    sleep_level: int,
    response_level: int = 2,
    fn_toggle: bool = False,
    block_win: bool = False,
    block_alt_f4: bool = False,
    block_alt_tab: bool = False,
) -> bytearray:
    data = bytearray(64)
    data[1] = 0x01
    data[2] = 1 if block_win else 0
    data[3] = 1 if block_alt_f4 else 0
    data[4] = 1 if block_alt_tab else 0
    data[5] = 1 if fn_toggle else 0
    data[6] = clamp(sleep_level, 0, 3)
    data[8] = clamp(response_level, 1, 5)
    data[62] = 0xAA
    data[63] = 0x55
    return data


def build_wired_sleep_sequence(
    sleep_level: int,
    response_level: int = 2,
    fn_toggle: bool = False,
    block_win: bool = False,
    block_alt_f4: bool = False,
    block_alt_tab: bool = False,
) -> list[bytes]:
    """Build USB-C system settings sequence (`0x17`: sleep, debounce, Fn toggle, key locks)."""
    return [
        _control_packet64(0x18),
        _control_packet64(0x17, byte2=0x01, byte8=0x01),
        bytes(_sleep_data64(sleep_level, response_level, fn_toggle, block_win, block_alt_f4, block_alt_tab)),
        _control_packet64(0x02),
    ]


def build_dongle_sleep_packet(
    sleep_level: int,
    response_level: int = 2,
    fn_toggle: bool = False,
    block_win: bool = False,
    block_alt_f4: bool = False,
    block_alt_tab: bool = False,
) -> bytes:
    """Build 2.4G receiver system settings packet (`order = 0x07`)."""
    short = (
        bytes(_sleep_data64(sleep_level, response_level, fn_toggle, block_win, block_alt_f4, block_alt_tab)[:14])
        + b"\xAA\x55"
    )
    return build_rf_frame(0x07, short)


def build_tft_screen_blocks(
    frames_rgb565: list[bytes],
    delays_ms: list[int] | None = None,
) -> list[bytes]:
    """Pack 128x128 RGB565-LE frame(s) into 4096-byte TFT screen upload blocks."""
    if not frames_rgb565 or len(frames_rgb565) > TFT_MAX_FRAMES:
        raise ValueError(f"Frame count must be between 1 and {TFT_MAX_FRAMES}")
    for idx, frame in enumerate(frames_rgb565):
        if len(frame) != TFT_FRAME_BYTES:
            raise ValueError(
                f"Frame {idx} must be {TFT_FRAME_BYTES} bytes (128x128 RGB565), got {len(frame)}"
            )
    header = bytearray([0xFF] * 256)
    header[0] = len(frames_rgb565)
    for idx in range(len(frames_rgb565)):
        d_ms = delays_ms[idx] if (delays_ms and idx < len(delays_ms)) else 100
        header[1 + idx] = clamp(round(int(d_ms) / 2), 1, 255)

    blob = bytearray(header)
    for frame in frames_rgb565:
        blob.extend(frame)
    rem = len(blob) % TFT_BLOCK_SIZE
    if rem:
        blob.extend(b"\xFF" * (TFT_BLOCK_SIZE - rem))

    return [bytes(blob[i : i + TFT_BLOCK_SIZE]) for i in range(0, len(blob), TFT_BLOCK_SIZE)]


def enumerate_sonix_hid_interfaces() -> list[dict]:
    """Return present HID interfaces belonging to Vendor ID 0x0C45."""
    return enumerate_hid_interfaces(VID_SONIX)


def detect_ajazz_device() -> dict | None:
    """Detect connected AJAZZ AK820 Pro (wired USB-C preferred over 2.4G dongle)."""
    interfaces = enumerate_sonix_hid_interfaces()

    screen_iface = next(
        (
            d
            for d in interfaces
            if d["vid"] == VID_SONIX
            and d["pid"] in WIRED_PIDS
            and d["usage_page"] == USAGE_PAGE_WIRED_SCREEN
        ),
        None,
    )

    for dev in interfaces:
        if (
            dev["vid"] == VID_SONIX
            and dev["pid"] in WIRED_PIDS
            and dev["usage_page"] == USAGE_PAGE_WIRED_CTRL
            and dev["feat_len"] in (64, 65)
        ):
            return {
                **dev,
                "link": "usb",
                "label": "USB-C Wired",
                "screen_path": screen_iface["path"] if screen_iface else None,
                "screen_out_len": screen_iface["out_len"] if screen_iface else 0,
            }

    for dev in interfaces:
        if (
            dev["vid"] == VID_SONIX
            and dev["pid"] == DONGLE_PID
            and dev["usage_page"] == USAGE_PAGE_DONGLE_CTRL
            and dev["out_len"] == 33
        ):
            return {
                **dev,
                "link": "2.4g",
                "label": "2.4G Dongle",
                "screen_path": None,
                "screen_out_len": 0,
            }

    return None


def read_keyboard_battery(device: dict) -> dict:
    """Read keyboard wireless battery via 2.4G RF `0x20` query (returns status dict)."""
    if device.get("link") != "2.4g":
        return {"percent": None, "status": "wired_usb"}
    query = build_rf_battery_query()
    for _ in range(2):
        reply = write_and_read_report(device["path"], query, read_size=33, timeout_ms=100)
        parsed = parse_rf_battery_reply(reply)
        if parsed is not None:
            return parsed
        time.sleep(0.02)
    return {"percent": None, "status": "idle_or_sleeping"}


def _send_wired_feature_seq(handle: int, hid, seq: list[bytes], feat_len: int, context: str) -> None:
    for idx, report64 in enumerate(seq):
        time.sleep(0.035)
        payload = (b"\x00" + report64) if feat_len == 65 else report64
        set_feature_report(handle, hid, payload, context=f"{context} step {idx + 1}")
        time.sleep(0.035)
        if idx < len(seq) - 1:
            get_feature_report(handle, hid, payload[0], size=len(payload), context=context)
            time.sleep(0.035)


def send_lighting_to_hardware(device: dict, settings: dict) -> None:
    """Transmit lighting and system parameters to AK820 Pro HID."""
    r, g, b = parse_hex_color(settings["color"])
    mode = int(settings["mode"])
    rainbow = bool(settings["rainbow"])
    brightness = int(settings["brightness"])
    speed = int(settings["speed"])
    direction = int(settings["direction"])
    sys_kwargs = dict(
        sleep_level=int(settings.get("sleep_level", 2)),
        response_level=int(settings.get("response_level", 2)),
        fn_toggle=bool(settings.get("fn_toggle", False)),
        block_win=bool(settings.get("block_win", False)),
        block_alt_f4=bool(settings.get("block_alt_f4", False)),
        block_alt_tab=bool(settings.get("block_alt_tab", False)),
    )

    with open_hid_handle(device["path"], label="AJAZZ Keyboard HID") as (handle, hid, kernel32):
        if device["link"] == "2.4g":
            pkt = build_dongle_lighting_packet(mode, r, g, b, rainbow, brightness, speed, direction)
            write_output_report(handle, kernel32, pkt, context="AJAZZ Keyboard 2.4G")
            time.sleep(0.025)
            sleep_pkt = build_dongle_sleep_packet(**sys_kwargs)
            write_output_report(handle, kernel32, sleep_pkt, context="AJAZZ Keyboard System 2.4G")
            time.sleep(0.02)
            return

        # USB-C Wired: 5-step feature report transaction + system settings
        feat_len = device.get("feat_len") or 65
        seq = build_wired_lighting_sequence(mode, r, g, b, rainbow, brightness, speed, direction)
        _send_wired_feature_seq(handle, hid, seq, feat_len, "AJAZZ Keyboard Lighting USB")
        sleep_seq = build_wired_sleep_sequence(**sys_kwargs)
        _send_wired_feature_seq(handle, hid, sleep_seq, feat_len, "AJAZZ Keyboard System USB")


def send_clock_sync_to_hardware(device: dict, dt: datetime | None = None) -> None:
    """Sync the keyboard's TFT screen RTC clock over USB-C or 2.4G receiver."""
    with open_hid_handle(device["path"], label="AJAZZ Keyboard Clock HID") as (handle, hid, kernel32):
        if device["link"] == "2.4g":
            pkt = build_dongle_clock_packet(dt)
            write_output_report(handle, kernel32, pkt, context="AJAZZ Clock 2.4G")
            time.sleep(0.03)
            return
        feat_len = device.get("feat_len") or 65
        seq = build_wired_clock_sequence(dt)
        _send_wired_feature_seq(handle, hid, seq, feat_len, "AJAZZ Clock USB")


def send_tft_blocks_to_hardware(device: dict, blocks: list[bytes]) -> None:
    """Upload pre-packed 4096B TFT screen blocks over USB-C (`UP=0xFF68`) awaiting `01 5A 02` acks."""
    screen_path = device.get("screen_path")
    if device.get("link") != "usb" or not screen_path:
        raise ValueError(
            "Upload gambar layar TFT hanya tersedia lewat kabel USB-C (pembatasan hardware 2.4G dongle)."
        )
    feat_len = device.get("feat_len") or 65
    out_len = int(device.get("screen_out_len") or 4097)
    n_blocks = len(blocks)

    with open_hid_handle(device["path"], label="AJAZZ Keyboard Ctrl") as (ctrl_h, hid, _):
        _send_wired_feature_seq(
            ctrl_h,
            hid,
            [
                _control_packet64(0x18),
                _control_packet64(0x72, byte2=0x01, byte8=n_blocks & 0xFF, byte9=(n_blocks >> 8) & 0xFF),
            ],
            feat_len,
            "AJAZZ TFT Start",
        )
        payloads = [((b"\x00" + blk) if out_len >= 4097 else blk) for blk in blocks]
        write_and_read_sequence(screen_path, payloads, read_size=65, timeout_ms=3000, context="AJAZZ TFT")
        _send_wired_feature_seq(ctrl_h, hid, [_control_packet64(0x02)], feat_len, "AJAZZ TFT Commit")
        time.sleep(0.1)


def _read_vendor_lcd_info(db_path: Path) -> dict:
    """Read saved TFT screen theme/frame metadata and preview path from vendor DB."""
    info = {
        "panel": '0.85" Color TFT (RGB565)',
        "resolution": f"{TFT_WIDTH} x {TFT_HEIGHT}",
        "max_frames": TFT_MAX_FRAMES,
        "saved_theme": None,
        "saved_frames": 0,
        "frame_delay_ms": 50,
        "preview_path": None,
        "firmware_version": None,
        "sleep_level_db": None,
    }
    if not db_path.is_file():
        return info
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            layer = con.execute(
                "SELECT led_id, name, frame_size, file_dir, first_file "
                "FROM t_ledlayer_data ORDER BY led_id DESC LIMIT 1"
            ).fetchone()
            if layer:
                led_id, name, frame_size, file_dir, first_file = layer
                info["saved_theme"] = str(name)
                info["saved_frames"] = int(frame_size or 0)
                avg_row = con.execute(
                    "SELECT AVG(delay_time) FROM t_ledframe_data WHERE led_id = ?",
                    (led_id,),
                ).fetchone()
                if avg_row and avg_row[0]:
                    info["frame_delay_ms"] = int(round(avg_row[0]))
                led_root = db_path.parent.parent / "led" / "AJAZZ AK820Pro"
                candidate = (led_root / str(file_dir) / str(first_file)).resolve()
                if str(candidate).startswith(str(led_root.resolve())) and candidate.is_file():
                    info["preview_path"] = str(candidate)

            cfg_rows = con.execute("SELECT key, value FROM t_config_data").fetchall()
            cfg = {str(k): str(v) for k, v in cfg_rows}
            if cfg.get("version"):
                info["firmware_version"] = cfg["version"]
            if cfg.get("sleep_time") and cfg["sleep_time"].isdigit():
                info["sleep_level_db"] = clamp(int(cfg["sleep_time"]), 0, 3)
        finally:
            con.close()
    except Exception:
        pass
    return info


def _read_vendor_db_defaults(db_path: Path) -> dict | None:
    if not db_path.is_file():
        return None
    try:
        con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
        try:
            row = con.execute(
                "SELECT mode, brightness, speed, direction, colorful, color_value "
                "FROM t_light_data WHERE status = 1 ORDER BY light_id DESC LIMIT 1"
            ).fetchone()
        finally:
            con.close()
        if not row:
            return None
        mode, brightness, speed, direction, colorful, color_val = row
        color_val = int(color_val or 255)
        r = color_val & 0xFF
        g = (color_val >> 8) & 0xFF
        b = (color_val >> 16) & 0xFF
        return {
            "mode": int(mode) if int(mode) in VALID_MODE_IDS else 1,
            "color": format_hex_color(r, g, b),
            "rainbow": bool(colorful),
            "brightness": clamp(int(brightness), 0, MAX_BRIGHTNESS),
            "speed": clamp(int(speed), 0, MAX_SPEED),
            "direction": clamp(int(direction), 0, 3),
        }
    except Exception:
        return None


class AjazzRgbController:
    """Thread-safe state manager and hardware dispatcher for AJAZZ AK820 Pro."""

    def __init__(
        self,
        state_path: Path | None = None,
        vendor_db_path: Path | None = None,
        detect_fn: Callable[[], dict | None] = detect_ajazz_device,
        send_fn: Callable[[dict, dict], None] = send_lighting_to_hardware,
        battery_fn: Callable[[dict], dict] = read_keyboard_battery,
        clock_fn: Callable[[dict], None] = send_clock_sync_to_hardware,
        screen_fn: Callable[[dict, list[bytes]], None] = send_tft_blocks_to_hardware,
    ) -> None:
        self._lock = threading.Lock()
        self._state_path = Path(state_path) if state_path else _default_state_path()
        self._vendor_db_path = Path(vendor_db_path) if vendor_db_path else _default_vendor_db_path()
        self._detect_fn = detect_fn
        self._send_fn = send_fn
        self._battery_fn = battery_fn
        self._clock_fn = clock_fn
        self._screen_fn = screen_fn
        self._lcd_meta = _read_vendor_lcd_info(self._vendor_db_path)
        self._settings = self._load_initial_settings()
        self._last_battery: dict = {"percent": None, "status": "idle_or_sleeping"}
        self._last_battery_ts: float = 0.0

    def _default_base_settings(self) -> dict:
        sleep_db = self._lcd_meta.get("sleep_level_db")
        return {
            "mode": 1,
            "color": "#ff0000",
            "rainbow": False,
            "brightness": 5,
            "speed": 3,
            "direction": 0,
            "sleep_level": sleep_db if sleep_db is not None else 2,
            "response_level": 2,
            "fn_toggle": False,
            "block_win": False,
            "block_alt_f4": False,
            "block_alt_tab": False,
            "last_clock_sync": None,
            "updated_at": None,
        }

    def _load_initial_settings(self) -> dict:
        base = self._default_base_settings()
        if self._state_path.is_file():
            try:
                data = json.loads(self._state_path.read_text(encoding="utf-8"))
                return self._validate_settings(data, base=base)
            except Exception:
                pass
        vendor_defaults = _read_vendor_db_defaults(self._vendor_db_path)
        if vendor_defaults:
            return {**base, **vendor_defaults, "updated_at": None}
        return base

    def _save_settings(self) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            self._state_path.write_text(json.dumps(self._settings, indent=2), encoding="utf-8")
        except OSError:
            pass

    @staticmethod
    def _validate_settings(payload: dict, base: dict) -> dict:
        merged = dict(base)
        if "mode" in payload:
            try:
                mode = int(payload["mode"])
            except (TypeError, ValueError) as exc:
                raise ValueError("Mode must be an integer (0..19)") from exc
            if mode not in VALID_MODE_IDS:
                raise ValueError(f"Unsupported lighting mode: {mode}")
            merged["mode"] = mode

        if "color" in payload:
            r, g, b = parse_hex_color(str(payload["color"]))
            merged["color"] = format_hex_color(r, g, b)

        if "rainbow" in payload:
            merged["rainbow"] = bool(payload["rainbow"])

        for key, lo, hi in (
            ("brightness", 0, MAX_BRIGHTNESS),
            ("speed", 0, MAX_SPEED),
            ("direction", 0, 3),
            ("sleep_level", 0, 3),
            ("response_level", 1, 5),
        ):
            if key in payload:
                try:
                    val = int(payload[key])
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"{key} must be an integer") from exc
                merged[key] = clamp(val, lo, hi)

        for key in ("fn_toggle", "block_win", "block_alt_f4", "block_alt_tab"):
            if key in payload:
                merged[key] = bool(payload[key])

        if "last_clock_sync" in payload:
            merged["last_clock_sync"] = payload["last_clock_sync"]
        if "updated_at" in payload:
            merged["updated_at"] = payload["updated_at"]
        return merged

    def get_state(self, force_battery: bool = False) -> dict:
        device = self._detect_fn()
        battery = {"percent": None, "status": "disconnected"}
        if device is not None:
            if device.get("link") == "usb":
                battery = {"percent": None, "status": "wired_usb"}
            else:
                now = time.time()
                with self._lock:
                    cached = self._last_battery
                    age = now - self._last_battery_ts
                if force_battery or self._last_battery_ts == 0.0 or age > 12.0 or (
                    cached.get("percent") is None and age > 2.0
                ):
                    fresh = self._battery_fn(device)
                    with self._lock:
                        if fresh.get("percent") is not None or self._last_battery.get("percent") is None:
                            self._last_battery = fresh
                        self._last_battery_ts = now
                        battery = dict(self._last_battery)
                else:
                    battery = dict(cached)

        with self._lock:
            settings = dict(self._settings)

        device_summary = None
        if device:
            device_summary = {
                "link": device["link"],
                "label": device["label"],
                "vid": f"{device['vid']:04X}",
                "pid": f"{device['pid']:04X}",
                "has_screen_upload": bool(device.get("link") == "usb" and device.get("screen_path")),
            }

        lcd_summary = {
            "panel": self._lcd_meta["panel"],
            "resolution": self._lcd_meta["resolution"],
            "max_frames": self._lcd_meta["max_frames"],
            "saved_theme": self._lcd_meta["saved_theme"],
            "saved_frames": self._lcd_meta["saved_frames"],
            "frame_delay_ms": self._lcd_meta["frame_delay_ms"],
            "firmware_version": self._lcd_meta["firmware_version"],
            "has_preview": bool(self._lcd_meta["preview_path"]),
            "clock_sync_supported": device is not None,
            "image_upload_supported": bool(device_summary and device_summary["has_screen_upload"]),
            "last_clock_sync": settings.get("last_clock_sync"),
        }

        return {
            "connected": device is not None,
            "device": device_summary,
            "battery": battery,
            "lcd": lcd_summary,
            "settings": settings,
            "modes": list(LIGHTING_MODES),
            "directions": list(DIRECTIONS),
            "sleep_levels": list(SLEEP_LEVELS),
            "palette": list(COLOR_PALETTE),
        }

    def apply_lighting(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        with self._lock:
            next_settings = self._validate_settings(payload, base=self._settings)
            device = self._detect_fn()
            if device is None:
                raise LookupError(
                    "AJAZZ AK820 Pro not detected. Connect via USB-C cable or 2.4G dongle."
                )
            self._send_fn(device, next_settings)
            next_settings["updated_at"] = time.time()
            self._settings = next_settings
            self._save_settings()
        return self.get_state(force_battery=False)

    def sync_clock(self) -> dict:
        with self._lock:
            device = self._detect_fn()
            if device is None:
                raise LookupError(
                    "AJAZZ AK820 Pro not detected. Connect via USB-C cable or 2.4G dongle."
                )
            self._clock_fn(device)
            now_ts = time.time()
            self._settings["last_clock_sync"] = now_ts
            self._settings["updated_at"] = now_ts
            self._save_settings()
        return self.get_state(force_battery=False)

    def upload_lcd_image(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        raw_b64 = payload.get("rgb565_b64")
        frames_b64 = payload.get("frames_b64")
        if frames_b64 is None and raw_b64 is not None:
            frames_b64 = [raw_b64]
        if not isinstance(frames_b64, list) or not frames_b64:
            raise ValueError("Missing rgb565_b64 or frames_b64 image payload")

        frames: list[bytes] = []
        for item in frames_b64:
            try:
                decoded = base64.b64decode(str(item), validate=True)
            except Exception as exc:
                raise ValueError("Invalid base64 RGB565 frame payload") from exc
            frames.append(decoded)

        delays = payload.get("delays_ms")
        blocks = build_tft_screen_blocks(frames, delays_ms=delays if isinstance(delays, list) else None)

        with self._lock:
            device = self._detect_fn()
            if device is None:
                raise LookupError(
                    "AJAZZ AK820 Pro not detected. Connect via USB-C cable or 2.4G dongle."
                )
            if device.get("link") != "usb" or not device.get("screen_path"):
                raise ValueError(
                    "LCD image upload requires a direct USB-C cable connection (2.4G dongle only supports clock sync)."
                )
            self._screen_fn(device, blocks)
        return self.get_state(force_battery=False)

    def get_lcd_preview_png(self) -> bytes | None:
        preview = self._lcd_meta.get("preview_path")
        if not preview:
            return None
        p = Path(preview)
        if not p.is_file():
            return None
        try:
            return p.read_bytes()
        except OSError:
            return None
