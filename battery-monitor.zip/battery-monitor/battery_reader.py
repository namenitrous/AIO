"""Windows battery telemetry reader using native Win32 IOCTL and power APIs."""

from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import asdict, dataclass
import struct
import time
import winreg

DIGCF_PRESENT = 0x02
DIGCF_DEVICEINTERFACE = 0x10

GENERIC_READ = 0x80000000
GENERIC_WRITE = 0x40000000
FILE_SHARE_READ = 0x01
FILE_SHARE_WRITE = 0x02
OPEN_EXISTING = 0x03
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

IOCTL_BATTERY_QUERY_TAG = 0x294040
IOCTL_BATTERY_QUERY_INFORMATION = 0x294044
IOCTL_BATTERY_QUERY_STATUS = 0x29404C

BATTERY_INFO_LEVEL = 0
BATTERY_ESTIMATED_TIME_LEVEL = 3
BATTERY_DEVICE_NAME_LEVEL = 4
BATTERY_MANUFACTURE_NAME_LEVEL = 6
BATTERY_SERIAL_NUMBER_LEVEL = 8

BATTERY_POWER_ON_LINE = 0x00000001
BATTERY_DISCHARGING = 0x00000002
BATTERY_CHARGING = 0x00000004
BATTERY_CRITICAL = 0x00000008

BATTERY_UNKNOWN_CAPACITY = 0xFFFFFFFF
BATTERY_UNKNOWN_VOLTAGE = 0xFFFFFFFF
BATTERY_UNKNOWN_TIME = 0xFFFFFFFF
BATTERY_UNKNOWN_RATE = -2147483648  # 0x80000000 as signed 32-bit int


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]


GUID_DEVCLASS_BATTERY = GUID(
    0x72631E54,
    0x78A4,
    0x11D0,
    (ctypes.c_ubyte * 8)(0xBC, 0xF7, 0x00, 0xAA, 0x00, 0xB7, 0xB3, 0x2A),
)


class SP_DEVICE_INTERFACE_DATA(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("InterfaceClassGuid", GUID),
        ("Flags", wintypes.DWORD),
        ("Reserved", ctypes.POINTER(ctypes.c_ulong)),
    ]


class BATTERY_QUERY_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BatteryTag", wintypes.ULONG),
        ("InformationLevel", ctypes.c_int),
        ("AtRate", wintypes.LONG),
    ]


class BATTERY_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("Capabilities", wintypes.ULONG),
        ("Technology", ctypes.c_ubyte),
        ("Reserved", ctypes.c_ubyte * 3),
        ("Chemistry", ctypes.c_char * 4),
        ("DesignedCapacity", wintypes.ULONG),
        ("FullChargedCapacity", wintypes.ULONG),
        ("DefaultAlert1", wintypes.ULONG),
        ("DefaultAlert2", wintypes.ULONG),
        ("CriticalBias", wintypes.ULONG),
        ("CycleCount", wintypes.ULONG),
    ]


class BATTERY_WAIT_STATUS(ctypes.Structure):
    _fields_ = [
        ("BatteryTag", wintypes.ULONG),
        ("Timeout", wintypes.ULONG),
        ("PowerState", wintypes.ULONG),
        ("LowCapacity", wintypes.ULONG),
        ("HighCapacity", wintypes.ULONG),
    ]


class BATTERY_STATUS(ctypes.Structure):
    _fields_ = [
        ("PowerState", wintypes.ULONG),
        ("Capacity", wintypes.ULONG),
        ("Voltage", wintypes.ULONG),
        ("Rate", wintypes.LONG),
    ]


class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [
        ("ACLineStatus", ctypes.c_ubyte),
        ("BatteryFlag", ctypes.c_ubyte),
        ("BatteryLifePercent", ctypes.c_ubyte),
        ("SystemStatusFlag", ctypes.c_ubyte),
        ("BatteryLifeTime", wintypes.DWORD),
        ("BatteryFullLifeTime", wintypes.DWORD),
    ]


def _load_win32_apis():
    setupapi = ctypes.WinDLL("setupapi", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    setupapi.SetupDiGetClassDevsW.restype = ctypes.c_void_p
    setupapi.SetupDiGetClassDevsW.argtypes = [
        ctypes.POINTER(GUID),
        wintypes.LPCWSTR,
        wintypes.HWND,
        wintypes.DWORD,
    ]
    setupapi.SetupDiEnumDeviceInterfaces.restype = wintypes.BOOL
    setupapi.SetupDiEnumDeviceInterfaces.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(GUID),
        wintypes.DWORD,
        ctypes.POINTER(SP_DEVICE_INTERFACE_DATA),
    ]
    setupapi.SetupDiGetDeviceInterfaceDetailW.restype = wintypes.BOOL
    setupapi.SetupDiGetDeviceInterfaceDetailW.argtypes = [
        ctypes.c_void_p,
        ctypes.POINTER(SP_DEVICE_INTERFACE_DATA),
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.c_void_p,
    ]
    setupapi.SetupDiDestroyDeviceInfoList.argtypes = [ctypes.c_void_p]

    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR,
        wintypes.DWORD,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.DWORD,
        wintypes.DWORD,
        wintypes.HANDLE,
    ]
    kernel32.DeviceIoControl.restype = wintypes.BOOL
    kernel32.DeviceIoControl.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
        ctypes.c_void_p,
    ]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.GetSystemPowerStatus.restype = wintypes.BOOL
    kernel32.GetSystemPowerStatus.argtypes = [ctypes.POINTER(SYSTEM_POWER_STATUS)]
    return setupapi, kernel32


_SETUPAPI, _KERNEL32 = _load_win32_apis()


@dataclass
class BatteryTelemetry:
    """Normalized snapshot of battery electrical and health telemetry."""

    timestamp: float
    device_model: str
    battery_present: bool
    battery_name: str
    manufacturer: str
    serial_number: str
    chemistry: str
    percentage: int | None
    ac_online: bool
    charging: bool
    discharging: bool
    critical: bool
    battery_saver: bool
    status_label: str
    voltage_mv: int | None
    voltage_v: float | None
    rate_mw: int | None
    power_w: float | None
    current_a: float | None
    remaining_mwh: int | None
    full_charge_mwh: int | None
    design_mwh: int | None
    health_percent: float | None
    cycle_count: int | None
    estimated_seconds: int | None


def get_system_model() -> str:
    """Read manufacturer and product model from Windows BIOS registry."""
    try:
        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\BIOS"
        ) as key:
            mfg, _ = winreg.QueryValueEx(key, "SystemManufacturer")
            product, _ = winreg.QueryValueEx(key, "SystemProductName")
            combined = f"{str(mfg).strip()} {str(product).strip()}".strip()
            return combined or "Windows PC"
    except OSError:
        return "Windows PC"


def compute_current_amps(rate_mw: int | None, voltage_mv: int | None) -> float | None:
    """Compute signed battery current in Amperes from power (mW) and voltage (mV)."""
    if rate_mw is None or voltage_mv is None or voltage_mv <= 0:
        return None
    return round(rate_mw / voltage_mv, 3)


def compute_health_percent(
    full_charge_mwh: int | None, design_mwh: int | None
) -> float | None:
    """Compute battery wear health percentage relative to design capacity."""
    if not full_charge_mwh or not design_mwh or design_mwh <= 0:
        return None
    return round(min(100.0, (full_charge_mwh / design_mwh) * 100.0), 1)


def derive_status_label(
    battery_present: bool, ac_online: bool, charging: bool, discharging: bool, critical: bool
) -> str:
    """Return a clean human-readable status label matching Stock Android style."""
    if not battery_present:
        return "No battery detected"
    if critical:
        return "Critically low"
    if charging:
        return "Charging"
    if discharging:
        return "On battery"
    if ac_online:
        return "Plugged in, idle"
    return "Standby"


def _query_info_string(handle: int, tag: int, level: int) -> str:
    bqi = BATTERY_QUERY_INFORMATION(tag, level, 0)
    buf = ctypes.create_unicode_buffer(256)
    bytes_ret = wintypes.DWORD(0)
    ok = _KERNEL32.DeviceIoControl(
        handle,
        IOCTL_BATTERY_QUERY_INFORMATION,
        ctypes.byref(bqi),
        ctypes.sizeof(bqi),
        buf,
        ctypes.sizeof(buf),
        ctypes.byref(bytes_ret),
        None,
    )
    return buf.value.strip() if ok else ""


def _read_first_acpi_battery() -> dict | None:
    hdev = _SETUPAPI.SetupDiGetClassDevsW(
        ctypes.byref(GUID_DEVCLASS_BATTERY),
        None,
        None,
        DIGCF_PRESENT | DIGCF_DEVICEINTERFACE,
    )
    if not hdev or hdev == INVALID_HANDLE_VALUE:
        return None

    try:
        did = SP_DEVICE_INTERFACE_DATA()
        did.cbSize = ctypes.sizeof(SP_DEVICE_INTERFACE_DATA)
        idx = 0
        cb_size = 8 if ctypes.sizeof(ctypes.c_void_p) == 8 else 6

        while _SETUPAPI.SetupDiEnumDeviceInterfaces(
            hdev, None, ctypes.byref(GUID_DEVCLASS_BATTERY), idx, ctypes.byref(did)
        ):
            idx += 1
            req_size = wintypes.DWORD(0)
            _SETUPAPI.SetupDiGetDeviceInterfaceDetailW(
                hdev, ctypes.byref(did), None, 0, ctypes.byref(req_size), None
            )
            if req_size.value <= 4:
                continue

            buf = ctypes.create_string_buffer(req_size.value)
            struct.pack_into("I", buf, 0, cb_size)
            if not _SETUPAPI.SetupDiGetDeviceInterfaceDetailW(
                hdev,
                ctypes.byref(did),
                buf,
                req_size,
                ctypes.byref(req_size),
                None,
            ):
                continue

            dev_path = ctypes.wstring_at(ctypes.addressof(buf) + 4)
            hbat = _KERNEL32.CreateFileW(
                dev_path,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                None,
                OPEN_EXISTING,
                0,
                None,
            )
            if not hbat or hbat == INVALID_HANDLE_VALUE:
                continue

            try:
                wait = wintypes.DWORD(0)
                tag = wintypes.ULONG(0)
                bytes_ret = wintypes.DWORD(0)
                if not _KERNEL32.DeviceIoControl(
                    hbat,
                    IOCTL_BATTERY_QUERY_TAG,
                    ctypes.byref(wait),
                    ctypes.sizeof(wait),
                    ctypes.byref(tag),
                    ctypes.sizeof(tag),
                    ctypes.byref(bytes_ret),
                    None,
                ):
                    continue

                bqi_info = BATTERY_QUERY_INFORMATION(tag.value, BATTERY_INFO_LEVEL, 0)
                bi = BATTERY_INFORMATION()
                info_ok = _KERNEL32.DeviceIoControl(
                    hbat,
                    IOCTL_BATTERY_QUERY_INFORMATION,
                    ctypes.byref(bqi_info),
                    ctypes.sizeof(bqi_info),
                    ctypes.byref(bi),
                    ctypes.sizeof(bi),
                    ctypes.byref(bytes_ret),
                    None,
                )

                bws = BATTERY_WAIT_STATUS(tag.value, 0, 0, 0, 0)
                bs = BATTERY_STATUS()
                status_ok = _KERNEL32.DeviceIoControl(
                    hbat,
                    IOCTL_BATTERY_QUERY_STATUS,
                    ctypes.byref(bws),
                    ctypes.sizeof(bws),
                    ctypes.byref(bs),
                    ctypes.sizeof(bs),
                    ctypes.byref(bytes_ret),
                    None,
                )
                if not status_ok:
                    continue

                est_time = wintypes.ULONG(BATTERY_UNKNOWN_TIME)
                bqi_est = BATTERY_QUERY_INFORMATION(
                    tag.value, BATTERY_ESTIMATED_TIME_LEVEL, 0
                )
                est_ok = _KERNEL32.DeviceIoControl(
                    hbat,
                    IOCTL_BATTERY_QUERY_INFORMATION,
                    ctypes.byref(bqi_est),
                    ctypes.sizeof(bqi_est),
                    ctypes.byref(est_time),
                    ctypes.sizeof(est_time),
                    ctypes.byref(bytes_ret),
                    None,
                )

                return {
                    "name": _query_info_string(hbat, tag.value, BATTERY_DEVICE_NAME_LEVEL),
                    "manufacturer": _query_info_string(
                        hbat, tag.value, BATTERY_MANUFACTURE_NAME_LEVEL
                    ),
                    "serial": _query_info_string(
                        hbat, tag.value, BATTERY_SERIAL_NUMBER_LEVEL
                    ),
                    "chemistry": bi.Chemistry.decode("ascii", errors="ignore").strip()
                    if info_ok
                    else "",
                    "design_mwh": None
                    if (not info_ok or bi.DesignedCapacity == BATTERY_UNKNOWN_CAPACITY)
                    else int(bi.DesignedCapacity),
                    "full_mwh": None
                    if (not info_ok or bi.FullChargedCapacity == BATTERY_UNKNOWN_CAPACITY)
                    else int(bi.FullChargedCapacity),
                    "cycle_count": int(bi.CycleCount) if info_ok else None,
                    "power_state": int(bs.PowerState),
                    "remaining_mwh": None
                    if bs.Capacity == BATTERY_UNKNOWN_CAPACITY
                    else int(bs.Capacity),
                    "voltage_mv": None
                    if bs.Voltage == BATTERY_UNKNOWN_VOLTAGE
                    else int(bs.Voltage),
                    "rate_mw": None if bs.Rate == BATTERY_UNKNOWN_RATE else int(bs.Rate),
                    "estimated_seconds": None
                    if (not est_ok or est_time.value == BATTERY_UNKNOWN_TIME)
                    else int(est_time.value),
                }
            finally:
                _KERNEL32.CloseHandle(hbat)
    finally:
        _SETUPAPI.SetupDiDestroyDeviceInfoList(hdev)

    return None


def read_battery_telemetry(device_model: str | None = None) -> BatteryTelemetry:
    """Collect a complete battery telemetry snapshot."""
    sps = SYSTEM_POWER_STATUS()
    _KERNEL32.GetSystemPowerStatus(ctypes.byref(sps))

    acpi = _read_first_acpi_battery()
    model = device_model or get_system_model()
    now = time.time()

    os_pct = None if sps.BatteryLifePercent == 255 else int(sps.BatteryLifePercent)
    os_life_sec = None if sps.BatteryLifeTime == BATTERY_UNKNOWN_TIME else int(sps.BatteryLifeTime)
    battery_saver = bool(sps.SystemStatusFlag & 0x01)

    if acpi is None:
        ac_online = sps.ACLineStatus == 1
        charging = bool(sps.BatteryFlag & 0x08)
        present = (sps.BatteryFlag & 128) == 0
        discharging = present and not ac_online and not charging
        critical = bool(sps.BatteryFlag & 0x04)
        return BatteryTelemetry(
            timestamp=now,
            device_model=model,
            battery_present=present,
            battery_name="Unknown",
            manufacturer="",
            serial_number="",
            chemistry="",
            percentage=os_pct,
            ac_online=ac_online,
            charging=charging,
            discharging=discharging,
            critical=critical,
            battery_saver=battery_saver,
            status_label=derive_status_label(
                present, ac_online, charging, discharging, critical
            ),
            voltage_mv=None,
            voltage_v=None,
            rate_mw=None,
            power_w=None,
            current_a=None,
            remaining_mwh=None,
            full_charge_mwh=None,
            design_mwh=None,
            health_percent=None,
            cycle_count=None,
            estimated_seconds=os_life_sec,
        )

    ps = acpi["power_state"]
    ac_online = bool(ps & BATTERY_POWER_ON_LINE) or (sps.ACLineStatus == 1)
    charging = bool(ps & BATTERY_CHARGING)
    discharging = bool(ps & BATTERY_DISCHARGING)
    critical = bool(ps & BATTERY_CRITICAL)

    voltage_mv = acpi["voltage_mv"]
    voltage_v = round(voltage_mv / 1000.0, 3) if voltage_mv is not None else None
    rate_mw = acpi["rate_mw"]

    # Normalize rate sign consistently with charging/discharging state.
    if rate_mw is not None:
        if discharging and rate_mw > 0:
            rate_mw = -rate_mw
        elif charging and rate_mw < 0:
            rate_mw = abs(rate_mw)

    power_w = round(rate_mw / 1000.0, 2) if rate_mw is not None else None
    current_a = compute_current_amps(rate_mw, voltage_mv)

    remaining_mwh = acpi["remaining_mwh"]
    full_mwh = acpi["full_mwh"]
    design_mwh = acpi["design_mwh"]

    pct = os_pct
    if pct is None and remaining_mwh is not None and full_mwh:
        pct = min(100, round((remaining_mwh / full_mwh) * 100))

    est_seconds = acpi["estimated_seconds"] if acpi["estimated_seconds"] is not None else os_life_sec

    return BatteryTelemetry(
        timestamp=now,
        device_model=model,
        battery_present=True,
        battery_name=acpi["name"] or "Primary Battery",
        manufacturer=acpi["manufacturer"],
        serial_number=acpi["serial"],
        chemistry=acpi["chemistry"],
        percentage=pct,
        ac_online=ac_online,
        charging=charging,
        discharging=discharging,
        critical=critical,
        battery_saver=battery_saver,
        status_label=derive_status_label(True, ac_online, charging, discharging, critical),
        voltage_mv=voltage_mv,
        voltage_v=voltage_v,
        rate_mw=rate_mw,
        power_w=power_w,
        current_a=current_a,
        remaining_mwh=remaining_mwh,
        full_charge_mwh=full_mwh,
        design_mwh=design_mwh,
        health_percent=compute_health_percent(full_mwh, design_mwh),
        cycle_count=acpi["cycle_count"],
        estimated_seconds=est_seconds,
    )


def telemetry_to_dict(sample: BatteryTelemetry) -> dict:
    """Convert BatteryTelemetry dataclass to a JSON-serializable dict."""
    return asdict(sample)
