"""Generate Battery & Power Monitor .ico and create Windows shortcuts."""

from __future__ import annotations

import math
from pathlib import Path
import struct
import subprocess
import sys
import zlib

APP_NAME = "Battery & Power Monitor"
ROOT_DIR = Path(__file__).resolve().parent
ICON_PATH = ROOT_DIR / "static" / "app.ico"
SERVER_PATH = ROOT_DIR / "server.py"


def _png_chunk(tag: bytes, data: bytes) -> bytes:
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def _encode_png(width: int, height: int, rgba: bytearray) -> bytes:
    raw = bytearray()
    stride = width * 4
    for y in range(height):
        raw.append(0)
        start = y * stride
        raw.extend(rgba[start : start + stride])
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    idat = zlib.compress(bytes(raw), level=9)
    return b"\x89PNG\r\n\x1a\n" + _png_chunk(b"IHDR", ihdr) + _png_chunk(b"IDAT", idat) + _png_chunk(b"IEND", b"")


def _point_in_poly(x: float, y: float, poly: list[tuple[float, float]]) -> bool:
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-12) + xi):
            inside = not inside
        j = i
    return inside


def _render_icon_png(size: int) -> bytes:
    rgba = bytearray(size * size * 4)
    # Material blue rounded square (#1a73e8 -> #0d47a1 gradient) with white lightning bolt
    margin = size * 0.07
    radius = size * 0.22
    inner_left = margin + radius
    inner_right = size - 1 - margin - radius
    inner_top = margin + radius
    inner_bot = size - 1 - margin - radius

    bolt = [
        (0.54 * size, 0.17 * size),
        (0.28 * size, 0.54 * size),
        (0.49 * size, 0.54 * size),
        (0.44 * size, 0.83 * size),
        (0.72 * size, 0.45 * size),
        (0.51 * size, 0.45 * size),
    ]

    for y in range(size):
        t = y / max(1, size - 1)
        bg_r = int(26 + (13 - 26) * t)
        bg_g = int(115 + (71 - 115) * t)
        bg_b = int(232 + (161 - 232) * t)
        for x in range(size):
            cx = min(max(x, inner_left), inner_right)
            cy = min(max(y, inner_top), inner_bot)
            dist = math.hypot(x - cx, y - cy)
            alpha = 0
            if dist <= radius - 0.5:
                alpha = 255
            elif dist < radius + 0.5:
                alpha = int(max(0.0, min(1.0, (radius + 0.5 - dist))) * 255)
            if alpha == 0:
                continue

            # Subtle 2x2 supersampling on bolt polygon for clean edges
            hits = 0
            for sy in (0.25, 0.75):
                for sx in (0.25, 0.75):
                    if _point_in_poly(x + sx - 0.5, y + sy - 0.5, bolt):
                        hits += 1
            mix = hits / 4.0
            r = int(bg_r * (1.0 - mix) + 255 * mix)
            g = int(bg_g * (1.0 - mix) + 255 * mix)
            b = int(bg_b * (1.0 - mix) + 255 * mix)

            idx = (y * size + x) * 4
            rgba[idx] = r
            rgba[idx + 1] = g
            rgba[idx + 2] = b
            rgba[idx + 3] = alpha

    return _encode_png(size, size, rgba)


def build_ico(ico_path: Path = ICON_PATH) -> Path:
    sizes = [16, 32, 48, 256]
    pngs = [_render_icon_png(s) for s in sizes]
    header = struct.pack("<HHH", 0, 1, len(sizes))
    offset = 6 + 16 * len(sizes)
    entries = bytearray()
    for sz, data in zip(sizes, pngs):
        w = 0 if sz >= 256 else sz
        h = 0 if sz >= 256 else sz
        entries.extend(struct.pack("<BBBBHHII", w, h, 0, 0, 1, 32, len(data), offset))
        offset += len(data)
    ico_path.parent.mkdir(parents=True, exist_ok=True)
    ico_path.write_bytes(header + bytes(entries) + b"".join(pngs))
    return ico_path


def find_pythonw() -> str:
    cur = Path(sys.executable)
    pw = cur.with_name("pythonw.exe")
    if pw.is_file():
        return str(pw)
    return str(cur)


def create_windows_shortcuts() -> dict:
    ico = build_ico()
    target = find_pythonw()
    ps_script = f"""
$wsh = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')
$paths = @(
  (Join-Path $desktop '{APP_NAME}.lnk'),
  (Join-Path $programs '{APP_NAME}.lnk')
)
foreach ($p in $paths) {{
  $s = $wsh.CreateShortcut($p)
  $s.TargetPath = '{target}'
  $s.Arguments = '"{SERVER_PATH}"'
  $s.WorkingDirectory = '{ROOT_DIR}'
  $s.IconLocation = '{ico},0'
  $s.Description = '{APP_NAME}'
  $s.Save()
}}

$shell = New-Object -ComObject Shell.Application
$folder = $shell.Namespace($desktop)
$item = $folder.ParseName('{APP_NAME}.lnk')
$verbs = @($item.Verbs() | ForEach-Object {{ ($_.Name -replace '&','') }})
$pinned = $false
foreach ($v in $item.Verbs()) {{
  $vn = ($v.Name -replace '&','').Trim()
  if ($vn -match 'Pin to taskbar|Sematkan ke bilah tugas') {{
    $v.DoIt()
    $pinned = $true
    break
  }}
}}
[PSCustomObject]@{{
  desktop_shortcut = $paths[0]
  start_menu_shortcut = $paths[1]
  icon = '{ico}'
  target = '{target}'
  taskbar_pinned = $pinned
  verbs = $verbs
}} | ConvertTo-Json -Depth 3
"""
    out = subprocess.check_output(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
        text=True,
    )
    import json

    return json.loads(out)


if __name__ == "__main__":
    import json

    print(json.dumps(create_windows_shortcuts(), indent=2))
