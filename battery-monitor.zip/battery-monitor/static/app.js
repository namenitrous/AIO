(() => {
  const { getLang, t, translateDom } = window.BM_I18N;

  const ICONS = {
    charging: `<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M13 2 4.5 13.5H11L10 22l8.5-11.5H12L13 2z"/></svg>`,
    plugged: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a6 6 0 0 1-12 0V8Z"/></svg>`,
    battery: `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4"/></svg>`,
  };

  const METRIC_META = {
    voltage_v: { label: "Voltage", unit: "V", decimals: 3, minSpan: 0.4 },
    current_a: { label: "Current", unit: "A", decimals: 2, minSpan: 0.5, signed: true },
    power_w: { label: "Power", unit: "W", decimals: 1, minSpan: 5.0, signed: true },
    cpu_power_w: { label: "CPU Power", unit: "W", decimals: 1, minSpan: 10.0, nonNegative: true },
    gpu_power_w: { label: "GPU Power", unit: "W", decimals: 1, minSpan: 10.0, nonNegative: true },
  };

  const state = {
    tab: "overview",
    metric: "voltage_v",
    windowSec: 60,
    intervalMs: 1000,
    paused: false,
    history: [],
    latest: null,
    stateStats: null,
    activeState: "idle",
    events: [],
    chargeGuard: null,
    prevLimitTriggered: false,
    timerId: null,
    specs: null,
    specsLoading: false,
    ajazz: null,
    ajazzDebounce: null,
    ajazzDevice: "ak820",
    ajazzPendingLcdB64: null,
    ajazzPendingLcdName: "",
    ajazzLoadedImg: null,
    ajazzMouse: null,
    ajazzMouseDebounce: null,
    electricity: null,
    lang: getLang(),
  };

  const $ = (id) => document.getElementById(id);

  function fmtNum(val, decimals, signed = false) {
    if (val === null || val === undefined || Number.isNaN(val)) return "--";
    const sign = signed && val > 0 ? "+" : "";
    return `${sign}${val.toFixed(decimals)}`;
  }

  function fmtInt(val) {
    if (val === null || val === undefined) return "--";
    return Number(val).toLocaleString("en-US");
  }

  function fmtDuration(seconds, suffix = "") {
    if (seconds === null || seconds === undefined || seconds <= 0) return "";
    const mins = Math.round(seconds / 60);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    const core = h > 0 ? `${h}h ${m}m` : `${m}m`;
    return suffix ? `${core} ${suffix}` : core;
  }

  function fmtElapsed(seconds) {
    if (!seconds || seconds <= 0) return "0s";
    const s = Math.round(seconds);
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    const remS = s % 60;
    if (m < 60) return `${m}m ${remS}s`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
  }

  function fmtTime(tsSec) {
    const d = new Date(tsSec * 1000);
    return d.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("bm_theme", theme);
    const dark = theme === "dark";
    $("icon-moon").classList.toggle("hidden", dark);
    $("icon-sun").classList.toggle("hidden", !dark);
    renderChart();
  }

  function applyLang(lang) {
    state.lang = lang === "en" ? "en" : "id";
    localStorage.setItem("bm_lang", state.lang);
    const btn = $("btn-lang");
    if (btn) btn.textContent = state.lang.toUpperCase();
    translateDom(state.lang);
    $("live-label").textContent = t(state.paused ? "paused" : "live", null, state.lang);
    if (state.latest) renderLatest(state.latest, state.stateStats);
    if (state.chargeGuard && state.latest) renderChargeGuard(state.latest, state.chargeGuard);
    if (state.stateStats) renderStateStats(state.stateStats, state.activeState);
    if (state.electricity) renderElectricity(state.electricity);
    if (state.specs) renderCpuGpuSpecs(state.specs);
  }

  function initTheme() {
    const saved = localStorage.getItem("bm_theme");
    if (saved === "dark" || saved === "light") {
      applyTheme(saved);
    } else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      applyTheme("dark");
    } else {
      applyTheme("light");
    }
  }

  function renderLatest(d, stateStats) {
    if (!d) return;

    const batName = d.battery_name || "Battery";
    $("device-subtitle").textContent = `${d.device_model} · ${batName}`;

    const pct = d.percentage !== null && d.percentage !== undefined ? d.percentage : null;
    $("battery-pct").textContent = pct !== null ? `${pct}%` : "--%";

    const barFill = $("battery-bar-fill");
    const barTrack = $("battery-progressbar");
    const widthPct = pct !== null ? Math.max(0, Math.min(100, pct)) : 0;
    barFill.style.width = `${widthPct}%`;
    barTrack.setAttribute("aria-valuenow", String(widthPct));

    barFill.classList.remove("charging", "low", "critical");
    if (d.critical) barFill.classList.add("critical");
    else if (d.charging) barFill.classList.add("charging");
    else if (pct !== null && pct <= 20) barFill.classList.add("low");

    const statusIcon = $("status-icon");
    statusIcon.classList.remove("charging", "critical");
    if (d.charging) {
      statusIcon.innerHTML = ICONS.charging;
      statusIcon.classList.add("charging");
    } else if (d.ac_online) {
      statusIcon.innerHTML = ICONS.plugged;
    } else {
      statusIcon.innerHTML = ICONS.battery;
      if (d.critical) statusIcon.classList.add("critical");
    }

    let eta = "";
    if (d.charging && d.time_to_full_sec) {
      eta = fmtDuration(d.time_to_full_sec, "to full");
    } else if (d.discharging) {
      eta = fmtDuration(d.estimated_seconds || d.calc_runtime_sec, "left");
    }
    $("status-text").textContent = eta ? `${d.status_label} · ${eta}` : d.status_label;
    $("saver-badge").classList.toggle("hidden", !d.battery_saver);

    $("val-voltage").textContent = d.voltage_v !== null ? `${d.voltage_v.toFixed(2)} V` : "--";
    $("sub-voltage").textContent = d.voltage_mv !== null ? `${fmtInt(d.voltage_mv)} mV` : "Unavailable";

    $("val-current").textContent = d.current_a !== null ? `${fmtNum(d.current_a, 2, true)} A` : "--";
    if (d.current_a === null) {
      $("sub-current").textContent = t("unavailable");
    } else if (d.charging || d.current_a > 0.005) {
      $("sub-current").textContent = t("charging_cur");
    } else if (d.discharging || d.current_a < -0.005) {
      $("sub-current").textContent = t("discharge_draw");
    } else {
      $("sub-current").textContent = t("idle");
    }

    $("val-power").textContent = d.power_w !== null ? `${fmtNum(d.power_w, 1, true)} W` : "--";
    if (d.rate_mw === null) {
      $("sub-power").textContent = "Unavailable";
    } else if (d.charging || d.rate_mw > 0) {
      $("sub-power").textContent = `Charging · +${fmtInt(d.rate_mw)} mW`;
    } else if (d.discharging || d.rate_mw < 0) {
      $("sub-power").textContent = `Discharge · ${fmtInt(d.rate_mw)} mW`;
    } else {
      $("sub-power").textContent = "AC Bypass · 0 mW";
    }

    $("val-crate").textContent = d.c_rate !== null ? `${fmtNum(d.c_rate, 2, true)} C` : "--";
    $("sub-crate").textContent =
      d.pct_per_hour !== null ? `${fmtNum(d.pct_per_hour, 1, true)} %/hr` : "Unavailable";

    const cpu = d.cpu || {};
    const gpu = d.gpu || {};

    const heroCpuPct = cpu.cpu_percent !== null && cpu.cpu_percent !== undefined ? `${cpu.cpu_percent.toFixed(0)}%` : "--";
    const heroCpuGhz = cpu.cpu_current_mhz ? `${(cpu.cpu_current_mhz / 1000).toFixed(2)} GHz` : "--";
    const heroCpuW = cpu.cpu_power_w !== null && cpu.cpu_power_w !== undefined ? `${cpu.cpu_power_w.toFixed(1)} W` : "";
    $("hero-cpu").textContent = [heroCpuW, heroCpuPct, heroCpuGhz].filter(Boolean).join(" · ");

    const cpuTemp = cpu.thermal_c !== null && cpu.thermal_c !== undefined ? `${cpu.thermal_c.toFixed(1)} C` : "--";
    const gpuTempHero = gpu.available && gpu.enabled && gpu.temp_c !== null && gpu.temp_c !== undefined ? `${gpu.temp_c} C` : "";
    $("hero-thermal").textContent = gpuTempHero && cpuTemp !== "--" ? `${cpuTemp} · ${gpuTempHero}` : cpuTemp;

    if (!gpu.available) {
      $("hero-gpu").textContent = "N/A";
    } else if (!gpu.enabled) {
      $("hero-gpu").textContent = t("paused");
    } else {
      const gw = gpu.power_w !== null && gpu.power_w !== undefined ? `${gpu.power_w.toFixed(1)} W` : "--";
      const gu = gpu.util_percent !== null && gpu.util_percent !== undefined ? `${gpu.util_percent}%` : "";
      const gt = gpu.temp_c !== null && gpu.temp_c !== undefined ? `${gpu.temp_c} C` : "";
      $("hero-gpu").textContent = [gw, gu, gt].filter(Boolean).join(" · ");
    }

    renderPerformanceMode(d);

    // Tab 2: System Power & CPU/GPU
    $("val-power-plan").textContent = d.power_plan || "--";
    $("val-power-mode").textContent = d.power_mode || "Standard";
    const ov = d.overlay_mode || {};
    if (ov.cpu_max_ac !== null && ov.cpu_max_ac !== undefined) {
      const tag = ov.cpu_max_ac < 100 ? "Turbo off" : "Boost on";
      $("val-cpu-cap").textContent = `${ov.cpu_max_ac}% / ${ov.cpu_max_dc ?? ov.cpu_max_ac}% (${tag})`;
    } else {
      $("val-cpu-cap").textContent = "--";
    }
    $("val-ac-status").textContent = d.ac_online ? t("connected") : t("disconnected");
    $("val-saver-status").textContent = d.battery_saver ? t("on") : t("off_state");

    const cpuW = cpu.cpu_power_w !== null && cpu.cpu_power_w !== undefined ? Number(cpu.cpu_power_w) : null;
    const gpuW = gpu.available && gpu.enabled && gpu.power_w !== null && gpu.power_w !== undefined ? Number(gpu.power_w) : null;
    const totalBadge = $("cg-total-badge");
    if (cpuW !== null || gpuW !== null) {
      const sumW = (cpuW ?? 0) + (gpuW ?? 0);
      totalBadge.textContent = `Total ${sumW.toFixed(1)} W`;
      totalBadge.className = "spec-badge ok";
    } else {
      totalBadge.textContent = "-- W";
      totalBadge.className = "spec-badge muted";
    }

    $("val-cpu-power").textContent = cpuW !== null ? `${cpuW.toFixed(1)} W` : "--";
    $("cpu-power-fill").style.width = cpuW !== null ? `${Math.min(100, Math.max(0, (cpuW / 65) * 100))}%` : "0%";

    const cpuPct = cpu.cpu_percent !== null && cpu.cpu_percent !== undefined ? `${cpu.cpu_percent.toFixed(1)}%` : "--";
    const cpuPerf = cpu.cpu_perf_percent !== null && cpu.cpu_perf_percent !== undefined ? `${cpu.cpu_perf_percent.toFixed(0)}% · ` : "";
    const cpuClk =
      cpu.cpu_current_mhz && cpu.cpu_max_mhz
        ? `${fmtInt(cpu.cpu_current_mhz)} MHz (${cpuPerf}Base ${fmtInt(cpu.cpu_max_mhz)})`
        : "--";
    $("val-cpu").textContent = `${cpuPct} · ${cpuClk}`;
    $("val-thermal").textContent = cpu.thermal_c !== null && cpu.thermal_c !== undefined ? `${cpu.thermal_c.toFixed(1)} °C` : "--";

    const toggleGpu = $("toggle-gpu");
    toggleGpu.disabled = !gpu.available;
    if (document.activeElement !== toggleGpu) {
      toggleGpu.checked = Boolean(gpu.enabled);
    }

    $("label-gpu-name").textContent = gpu.name || t("gpu_power_draw");
    const gpuFill = $("gpu-power-fill");
    const dgpuBadge = $("cg-dgpu-badge");
    const specsGpus = (state.specs && state.specs.gpus) || [];
    const matchedDgpu = specsGpus.find((g) => gpu.name && g.name && g.name.toLowerCase().includes(gpu.name.split(" ")[0].toLowerCase())) || specsGpus[0];
    const vramPart = matchedDgpu && matchedDgpu.vram_gb ? `${matchedDgpu.vram_gb} GB` : "";

    if (!gpu.available) {
      $("val-gpu-power").textContent = "Not detected";
      $("val-gpu-temp").textContent = "--";
      $("val-gpu-clock").textContent = "--";
      dgpuBadge.textContent = vramPart || "N/A";
      gpuFill.style.width = "0%";
    } else if (!gpu.enabled) {
      $("val-gpu-power").textContent = "Sensor paused";
      $("val-gpu-temp").textContent = t("paused");
      $("val-gpu-clock").textContent = t("paused");
      dgpuBadge.textContent = vramPart || t("paused");
      gpuFill.style.width = "0%";
    } else {
      const gp = gpu.power_w !== null && gpu.power_w !== undefined ? `${gpu.power_w.toFixed(1)} W` : "--";
      const gl = gpu.power_limit_w !== null && gpu.power_limit_w !== undefined ? ` / ${gpu.power_limit_w.toFixed(0)} W` : "";
      $("val-gpu-power").textContent = `${gp}${gl}`;
      const ratio = gpu.power_w && gpu.power_limit_w ? Math.min(100, (gpu.power_w / gpu.power_limit_w) * 100) : 0;
      gpuFill.style.width = `${ratio}%`;

      const gt = gpu.temp_c !== null && gpu.temp_c !== undefined ? `${gpu.temp_c} °C` : "--";
      const gu = gpu.util_percent !== null && gpu.util_percent !== undefined ? `${gpu.util_percent}%` : "--";
      $("val-gpu-temp").textContent = `${gt} · ${gu} load`;

      const gc = gpu.clock_mhz !== null && gpu.clock_mhz !== undefined ? `${fmtInt(gpu.clock_mhz)} MHz` : "--";
      const gs = gpu.pstate || "--";
      $("val-gpu-clock").textContent = `${gc} · ${gs}`;
      dgpuBadge.textContent = [vramPart, gpu.pstate].filter(Boolean).join(" · ") || "--";
    }

    // Tab 2: Energy & Runtime Analytics
    const chargeStats = stateStats ? stateStats.charge : null;
    const disStats = stateStats ? stateStats.discharge : null;
    const eInMwh = chargeStats ? chargeStats.energy_mwh : 0;
    const eOutMwh = disStats ? disStats.energy_mwh : 0;
    const netMwh = eInMwh + eOutMwh;

    $("val-energy-in").textContent = `+${(eInMwh / 1000).toFixed(2)} Wh (${fmtInt(Math.round(eInMwh))} mWh)`;
    $("val-energy-out").textContent = `${(eOutMwh / 1000).toFixed(2)} Wh (${fmtInt(Math.round(eOutMwh))} mWh)`;
    $("val-energy-net").textContent = `${netMwh >= 0 ? "+" : ""}${(netMwh / 1000).toFixed(2)} Wh`;

    $("val-pct-rate").textContent =
      d.pct_per_hour !== null ? `${fmtNum(d.pct_per_hour, 1, true)} %/hr` : "--";

    const pkCCharge = chargeStats && chargeStats.peak_c_rate !== null ? `${fmtNum(chargeStats.peak_c_rate, 2, true)} C` : "--";
    const pkCDis = disStats && disStats.peak_c_rate !== null ? `${fmtNum(disStats.peak_c_rate, 2, true)} C` : "--";
    $("val-peak-crate").textContent = `${pkCCharge} / ${pkCDis}`;

    $("val-time-full").textContent = d.time_to_full_sec ? fmtDuration(d.time_to_full_sec) : "--";

    let avgRuntime = "--";
    if (d.remaining_mwh && disStats && disStats.avg_power_w && disStats.avg_power_w < -0.1) {
      const avgSec = (d.remaining_mwh / Math.abs(disStats.avg_power_w * 1000)) * 3600;
      avgRuntime = fmtDuration(avgSec);
    }
    const liveRuntime = d.calc_runtime_sec
      ? fmtDuration(d.calc_runtime_sec)
      : d.estimated_seconds
        ? fmtDuration(d.estimated_seconds)
        : "--";
    $("val-runtime-est").textContent = `${liveRuntime} / ${avgRuntime}`;

    if (d.discharging && d.power_w !== null && d.power_w < -0.1) {
      const totalDraw = Math.abs(d.power_w);
      const parts = [];
      if (cpuW !== null) parts.push(`CPU ${cpuW.toFixed(1)} W`);
      if (gpuW !== null) parts.push(`GPU ${gpuW.toFixed(1)} W`);
      if (parts.length) {
        const rest = Math.max(0, totalDraw - (cpuW ?? 0) - (gpuW ?? 0));
        parts.push(`Other ${rest.toFixed(1)} W`);
        $("val-power-split").textContent = parts.join(" · ");
      } else {
        $("val-power-split").textContent = `Total ${totalDraw.toFixed(1)} W`;
      }
    } else {
      const parts = [];
      if (cpuW !== null) parts.push(`CPU ${cpuW.toFixed(1)} W`);
      if (gpuW !== null) parts.push(`GPU ${gpuW.toFixed(1)} W`);
      $("val-power-split").textContent = parts.length ? parts.join(" · ") : (d.ac_online ? "On AC power" : "--");
    }

    // Tab 3: Health & Hardware
    const health = d.health_percent;
    $("val-health").textContent = health !== null ? `${health.toFixed(1)}%` : "--";
    const healthFill = $("health-fill");
    healthFill.style.width = health !== null ? `${Math.min(100, Math.max(0, health))}%` : "0%";
    healthFill.classList.remove("good", "moderate", "poor");
    if (health !== null) {
      if (health >= 80) healthFill.classList.add("good");
      else if (health >= 60) healthFill.classList.add("moderate");
      else healthFill.classList.add("poor");
    }

    $("val-wear-lost").textContent =
      d.wear_mwh !== null && d.wear_percent !== null
        ? `${fmtInt(d.wear_mwh)} mWh (${d.wear_percent.toFixed(1)}%)`
        : "--";

    $("val-remaining").textContent =
      d.remaining_mwh !== null
        ? `${fmtInt(d.remaining_mwh)} mWh (${(d.remaining_mwh / 1000).toFixed(2)} Wh)`
        : "--";
    $("val-full").textContent =
      d.full_charge_mwh !== null
        ? `${fmtInt(d.full_charge_mwh)} mWh (${(d.full_charge_mwh / 1000).toFixed(2)} Wh)`
        : "--";
    $("val-design").textContent =
      d.design_mwh !== null
        ? `${fmtInt(d.design_mwh)} mWh (${(d.design_mwh / 1000).toFixed(2)} Wh)`
        : "--";
    $("val-cycles").textContent = d.cycle_count !== null ? `${fmtInt(d.cycle_count)} cycles` : "--";

    const hwParts = [d.battery_name, d.manufacturer, d.chemistry].filter(Boolean);
    $("val-hardware").textContent = hwParts.length ? hwParts.join(" · ") : "--";
    $("val-serial").textContent = d.serial_number || "--";
  }

  function renderPerformanceMode(d) {
    const profileKey = d.performance_profile || "balanced";
    const overlay = d.overlay_mode || {};
    document.querySelectorAll(".perf-btn").forEach((btn) => {
      const active = btn.dataset.mode === profileKey;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-checked", active ? "true" : "false");
    });

    const actual = overlay.actual_label || d.power_mode || "Balanced";
    const effective = overlay.effective_label || actual;
    const capText =
      overlay.cpu_max_ac !== null && overlay.cpu_max_ac !== undefined
        ? overlay.cpu_max_ac < 100
          ? ` · Turbo off (${overlay.cpu_max_ac}%)`
          : " · Boost on"
        : "";
    $("perf-mode-caption").textContent =
      effective !== actual
        ? `${actual} (Effective: ${effective})${capText}`
        : `${actual}${capText}`;
  }

  function renderChargeGuard(d, guard) {
    if (!guard) return;
    const toggle = $("toggle-charge-80");
    if (document.activeElement !== toggle) {
      toggle.checked = Boolean(guard.enabled);
    }

    const badge = $("guard-80-badge");
    const statusEl = $("guard-80-status");
    const noteEl = $("guard-80-note");
    const banner = $("limit-80-banner");

    badge.classList.remove("armed", "reached");

    if (!guard.enabled) {
      badge.textContent = t("off");
      statusEl.textContent = t("guard_off_sub");
      banner.classList.add("hidden");
    } else if (guard.triggered) {
      badge.textContent = t("guard_reached");
      badge.classList.add("reached");
      statusEl.textContent = t("guard_reached_sub", { pct: d.percentage ?? 80 });
      banner.classList.toggle("hidden", Boolean(guard.dismissed));
    } else if (d.ac_online && !d.charging && d.percentage !== null && d.percentage >= 80) {
      badge.textContent = t("idle");
      badge.classList.add("armed");
      statusEl.textContent = t("guard_idle_sub", { pct: d.percentage });
      banner.classList.add("hidden");
    } else {
      badge.textContent = t("guard_armed");
      badge.classList.add("armed");
      statusEl.textContent = t("guard_armed_sub");
      banner.classList.add("hidden");
    }

    if (guard.hardware_note) {
      noteEl.textContent = guard.hardware_note;
    }

    if (guard.triggered && !state.prevLimitTriggered) {
      if ("Notification" in window && Notification.permission === "granted") {
        try {
          new Notification("Battery & Power Monitor", {
            body: `Battery reached ${d.percentage ?? 80}% — unplug AC adapter to reduce wear.`,
          });
        } catch (_) {}
      }
    }
    state.prevLimitTriggered = Boolean(guard.triggered);
  }

  function renderStateStats(stateStats, activeState) {
    if (!stateStats) return;
    const labels = {
      charge: "Waiting for charge",
      idle: "Waiting for idle",
      discharge: "Waiting for discharge",
    };

    ["charge", "idle", "discharge"].forEach((key) => {
      const s = stateStats[key];
      const row = $(`state-row-${key}`);
      const activePill = $(`state-active-${key}`);
      const subEl = $(`state-sub-${key}`);
      const valEl = $(`state-val-${key}`);
      const metaEl = $(`state-meta-${key}`);
      if (!row || !s) return;

      const isActive = activeState === key;
      row.classList.toggle("is-active", isActive);
      activePill.classList.toggle("hidden", !isActive);

      if (!s.samples) {
        subEl.textContent = labels[key];
        valEl.textContent = "--";
        metaEl.textContent = "--";
        return;
      }

      const energyWh = s.energy_wh !== null && s.energy_wh !== undefined ? `${fmtNum(s.energy_wh, 2, true)} Wh` : "";
      subEl.textContent = energyWh && key !== "idle" ? `${fmtElapsed(s.duration_sec)} · ${energyWh}` : `${fmtElapsed(s.duration_sec)} recorded`;

      const pShow = s.last_power_w !== null ? `${fmtNum(s.last_power_w, 1, true)} W` : "--";
      valEl.textContent = pShow;

      if (key === "idle") {
        const avgV = s.avg_voltage_v !== null && s.avg_voltage_v !== undefined ? `Avg ${s.avg_voltage_v.toFixed(2)} V` : "";
        const avgG = s.avg_gpu_w !== null && s.avg_gpu_w !== undefined ? `GPU ${s.avg_gpu_w.toFixed(1)} W` : "";
        const cur = s.avg_current_a !== null ? `${fmtNum(s.avg_current_a, 2, true)} A` : "";
        metaEl.textContent = [avgV, avgG || cur].filter(Boolean).join(" · ") || "--";
      } else {
        const avg = s.avg_power_w !== null ? `Avg ${fmtNum(s.avg_power_w, 1, true)} W` : "";
        const peak = s.peak_power_w !== null ? `Peak ${fmtNum(s.peak_power_w, 1, true)} W` : "";
        const cur = s.last_current_a !== null ? `${fmtNum(s.last_current_a, 2, true)} A` : "";
        metaEl.textContent = [avg, peak, cur].filter(Boolean).join(" · ") || "--";
      }
    });
  }

  function renderEvents(events) {
    const container = $("events-list");
    if (!events || events.length === 0) {
      container.innerHTML = `<p class="empty-note">No state transitions recorded yet.</p>`;
      return;
    }
    container.innerHTML = events
      .slice(0, 30)
      .map((ev) => {
        const pct = ev.percentage !== null && ev.percentage !== undefined ? `${ev.percentage}%` : "--";
        const pw = ev.power_w !== null && ev.power_w !== undefined ? `${fmtNum(ev.power_w, 1, true)} W` : "--";
        const vv = ev.voltage_v !== null && ev.voltage_v !== undefined ? `${ev.voltage_v.toFixed(2)} V` : "--";
        return `
          <div class="event-row">
            <div>
              <div class="event-detail">${ev.detail}</div>
              <div class="state-sub">${fmtTime(ev.t)}</div>
            </div>
            <div class="event-meta">${pct} · ${pw}<br>${vv}</div>
          </div>
        `;
      })
      .join("");
  }

  function renderChart() {
    const svg = $("telemetry-chart");
    const meta = METRIC_META[state.metric];
    const points = state.history.filter(
      (p) => p[state.metric] !== null && p[state.metric] !== undefined
    );

    if (points.length === 0) {
      svg._coords = [];
      $("chart-tooltip").classList.add("hidden");
      const msg =
        state.metric === "gpu_power_w"
          ? "No GPU power samples yet"
          : state.metric === "cpu_power_w"
            ? "No CPU power samples yet"
            : "Waiting for samples...";
      svg.innerHTML = `<text x="210" y="90" text-anchor="middle" fill="var(--text-secondary)" font-size="12">${msg}</text>`;
      $("stat-min").textContent = "--";
      $("stat-avg").textContent = "--";
      $("stat-max").textContent = "--";
      return;
    }

    const vals = points.map((p) => p[state.metric]);
    const minVal = Math.min(...vals);
    const maxVal = Math.max(...vals);
    const avgVal = vals.reduce((a, b) => a + b, 0) / vals.length;

    $("stat-min").textContent = `${fmtNum(minVal, meta.decimals, meta.signed)} ${meta.unit}`;
    $("stat-avg").textContent = `${fmtNum(avgVal, meta.decimals, meta.signed)} ${meta.unit}`;
    $("stat-max").textContent = `${fmtNum(maxVal, meta.decimals, meta.signed)} ${meta.unit}`;

    const W = 420;
    const H = 170;
    const padL = 44;
    const padR = 10;
    const padT = 12;
    const padB = 22;
    const plotW = W - padL - padR;
    const plotH = H - padT - padB;

    let yMin = minVal;
    let yMax = maxVal;
    const span = yMax - yMin;
    if (span < meta.minSpan) {
      const mid = (yMin + yMax) / 2;
      yMin = mid - meta.minSpan / 2;
      yMax = mid + meta.minSpan / 2;
    } else {
      const pad = span * 0.12;
      yMin -= pad;
      yMax += pad;
    }

    if ((state.metric === "voltage_v" || meta.nonNegative) && yMin < 0) {
      yMin = 0;
    }

    const mapX = (i) =>
      points.length === 1 ? padL + plotW / 2 : padL + (i / (points.length - 1)) * plotW;
    const mapY = (v) => padT + (1 - (v - yMin) / (yMax - yMin || 1)) * plotH;

    const coords = points.map((p, i) => [mapX(i), mapY(p[state.metric]), p]);
    const linePath = coords
      .map((c, idx) => `${idx === 0 ? "M" : "L"}${c[0].toFixed(1)},${c[1].toFixed(1)}`)
      .join(" ");
    const areaPath = `${linePath} L${coords[coords.length - 1][0].toFixed(1)},${(
      padT + plotH
    ).toFixed(1)} L${coords[0][0].toFixed(1)},${(padT + plotH).toFixed(1)} Z`;

    const ticks = [yMax, (yMax + yMin) / 2, yMin];
    const gridSvg = ticks
      .map((t) => {
        const y = mapY(t).toFixed(1);
        return `
          <line x1="${padL}" y1="${y}" x2="${W - padR}" y2="${y}" stroke="var(--chart-grid)" stroke-width="1" stroke-dasharray="3 3"/>
          <text x="${padL - 6}" y="${Number(y) + 3.5}" text-anchor="end" fill="var(--text-secondary)" font-size="10.5">${t.toFixed(
            meta.decimals > 2 ? 2 : 1
          )}</text>
        `;
      })
      .join("");

    let zeroLine = "";
    if (meta.signed && yMin < 0 && yMax > 0) {
      const zy = mapY(0).toFixed(1);
      zeroLine = `<line x1="${padL}" y1="${zy}" x2="${W - padR}" y2="${zy}" stroke="var(--border)" stroke-width="1.2"/>`;
    }

    const firstTime = fmtTime(points[0].t);
    const lastTime = fmtTime(points[points.length - 1].t);
    const lastCoord = coords[coords.length - 1];

    svg.innerHTML = `
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--primary)" stop-opacity="0.22"/>
          <stop offset="100%" stop-color="var(--primary)" stop-opacity="0.01"/>
        </linearGradient>
      </defs>
      ${gridSvg}
      ${zeroLine}
      <path d="${areaPath}" fill="url(#areaGrad)"/>
      <path d="${linePath}" fill="none" stroke="var(--primary)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      <circle cx="${lastCoord[0].toFixed(1)}" cy="${lastCoord[1].toFixed(1)}" r="3.5" fill="var(--primary)"/>
      <text x="${padL}" y="${H - 4}" text-anchor="start" fill="var(--text-secondary)" font-size="10.5">${firstTime}</text>
      <text x="${W - padR}" y="${H - 4}" text-anchor="end" fill="var(--text-secondary)" font-size="10.5">${lastTime}</text>
      <line id="hover-line" class="hidden" x1="0" y1="${padT}" x2="0" y2="${padT + plotH}" stroke="var(--text-secondary)" stroke-width="1" stroke-dasharray="2 2"/>
      <circle id="hover-dot" class="hidden" cx="0" cy="0" r="4" fill="var(--surface)" stroke="var(--primary)" stroke-width="2"/>
    `;

    svg._coords = coords;
  }

  function setupChartHover() {
    const svg = $("telemetry-chart");
    const tooltip = $("chart-tooltip");

    svg.addEventListener("mousemove", (e) => {
      const coords = svg._coords;
      if (!coords || coords.length === 0) return;

      const rect = svg.getBoundingClientRect();
      const relX = ((e.clientX - rect.left) / rect.width) * 420;

      let best = coords[0];
      let bestDist = Math.abs(relX - best[0]);
      for (let i = 1; i < coords.length; i++) {
        const d = Math.abs(relX - coords[i][0]);
        if (d < bestDist) {
          best = coords[i];
          bestDist = d;
        }
      }

      const meta = METRIC_META[state.metric];
      const val = best[2][state.metric];
      tooltip.textContent = `${fmtNum(val, meta.decimals, meta.signed)} ${meta.unit} · ${fmtTime(best[2].t)}`;
      tooltip.classList.remove("hidden");

      const hLine = svg.querySelector("#hover-line");
      const hDot = svg.querySelector("#hover-dot");
      if (hLine && hDot) {
        hLine.setAttribute("x1", best[0].toFixed(1));
        hLine.setAttribute("x2", best[0].toFixed(1));
        hLine.classList.remove("hidden");
        hDot.setAttribute("cx", best[0].toFixed(1));
        hDot.setAttribute("cy", best[1].toFixed(1));
        hDot.classList.remove("hidden");
      }
    });

    svg.addEventListener("mouseleave", () => {
      tooltip.classList.add("hidden");
      const hLine = svg.querySelector("#hover-line");
      const hDot = svg.querySelector("#hover-dot");
      if (hLine) hLine.classList.add("hidden");
      if (hDot) hDot.classList.add("hidden");
    });
  }

  async function fetchTelemetry() {
    try {
      const res = await fetch(`/api/telemetry?limit=${state.windowSec}`, { cache: "no-store" });
      if (!res.ok) return;
      const payload = await res.json();
      state.latest = payload.latest;
      state.history = payload.history || [];
      state.stateStats = payload.state_stats || null;
      state.activeState = payload.active_state || "idle";
      state.events = payload.events || [];
      state.chargeGuard = payload.charge_guard || null;
      state.electricity = payload.electricity || null;
      renderLatest(state.latest, state.stateStats);
      renderChargeGuard(state.latest, state.chargeGuard);
      renderStateStats(state.stateStats, state.activeState);
      renderEvents(state.events);
      renderElectricity(state.electricity);
      renderChart();
    } catch (_) {
      // Ignore transient poll errors while shutting down.
    }
  }

  function restartPolling() {
    if (state.timerId) {
      clearInterval(state.timerId);
      state.timerId = null;
    }
    if (!state.paused) {
      fetchTelemetry();
      state.timerId = setInterval(fetchTelemetry, state.intervalMs);
    }
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function fmtUptime(seconds) {
    if (seconds == null || !Number.isFinite(seconds) || seconds < 0) return "--";
    const total = Math.floor(seconds);
    const days = Math.floor(total / 86400);
    const hrs = Math.floor((total % 86400) / 3600);
    const mins = Math.floor((total % 3600) / 60);
    if (days > 0) return `${days}d ${hrs}h ${mins}m`;
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins}m ${total % 60}s`;
  }

  function fmtCacheKb(kb) {
    if (!kb || kb <= 0) return "--";
    return kb >= 1024 ? `${(kb / 1024).toFixed(1)} MB` : `${kb} KB`;
  }

  function renderSubList(containerId, items, renderItem, emptyText) {
    const el = $(containerId);
    if (!items || !items.length) {
      el.innerHTML = emptyText ? `<p class="empty-note">${escapeHtml(emptyText)}</p>` : "";
      return;
    }
    el.innerHTML = items.map(renderItem).join("");
  }

  function renderCpuGpuSpecs(specs) {
    if (!specs) return;
    const cpu = specs.cpu || {};
    if ($("cg-cpu-name")) {
      $("cg-cpu-name").textContent = cpu.name || "Processor (CPU)";
    }
    if ($("cg-cpu-arch")) {
      const parts = [];
      if (cpu.cores != null && cpu.threads != null) parts.push(`${cpu.cores}C / ${cpu.threads}T`);
      if (cpu.max_clock_mhz) parts.push(`${(cpu.max_clock_mhz / 1000).toFixed(2)} GHz`);
      $("cg-cpu-arch").textContent = parts.join(" · ") || "--";
    }
    if ($("cg-cpu-cache")) {
      $("cg-cpu-cache").textContent =
        cpu.l2_cache_kb || cpu.l3_cache_kb
          ? `L2 ${fmtCacheKb(cpu.l2_cache_kb)} / L3 ${fmtCacheKb(cpu.l3_cache_kb)}`
          : "--";
    }

    const outEl = $("cg-gpu-outputs");
    if (!outEl) return;
    const gpus = specs.gpus || [];
    const displays = specs.displays || [];
    if (!gpus.length && !displays.length) {
      outEl.innerHTML = `<p class="empty-note">${escapeHtml(specs.error || "No graphics outputs detected.")}</p>`;
      return;
    }

    const gpuCards = gpus.map((g, idx) => {
      const nameLower = String(g.name || "").toLowerCase();
      const isIgfx = nameLower.includes("intel") || nameLower.includes("uhd") || nameLower.includes("iris") || nameLower.includes("radeon(tm) graphics");
      const roleTag = isIgfx ? "iGPU" : idx === 0 ? "dGPU" : "GPU";
      const vramTag = g.vram_gb > 0 ? `${roleTag} · ${g.vram_gb} GB` : `${roleTag} · Shared`;
      const resText =
        g.width && g.height
          ? `${g.width} × ${g.height}${g.refresh_hz ? ` @ ${g.refresh_hz} Hz` : ""}`
          : "No active output";
      const drvText = g.driver_version ? `Driver ${g.driver_version}` : "";
      return `
        <div class="cg-output-item">
          <div class="spec-subhead">
            <span>${escapeHtml(g.name || "Graphics Adapter")}</span>
            <span class="spec-badge ${isIgfx ? "muted" : "ok"}">${escapeHtml(vramTag)}</span>
          </div>
          <div class="spec-submeta">${escapeHtml([resText, drvText].filter(Boolean).join(" · "))}</div>
        </div>
      `;
    });

    const dispCards = displays.map((d) => `
      <div class="cg-output-item">
        <div class="spec-subhead">
          <span>${escapeHtml(d.name || "Display Panel")}</span>
          <span class="spec-badge muted">${escapeHtml(d.manufacturer || "Monitor")}</span>
        </div>
      </div>
    `);

    outEl.innerHTML = [...gpuCards, ...dispCards].join("");
  }

  function renderSpecs(specs) {
    if (!specs) return;
    renderCpuGpuSpecs(specs);
    $("spec-uptime").textContent = fmtUptime(specs.uptime_seconds);

    if (specs.error && !specs.system) {
      $("spec-model").textContent = "Unavailable";
      renderSubList("spec-gpus", [], () => "", specs.error);
      renderSubList("spec-disks", [], () => "", specs.error);
      renderSubList("spec-network", [], () => "", specs.error);
      return;
    }

    const sys = specs.system || {};
    const cpu = specs.cpu || {};
    const ram = specs.ram || {};

    const modelText = [sys.manufacturer, sys.model].filter(Boolean).join(" ").trim();
    $("spec-model").textContent = modelText || "--";
    $("spec-board").textContent = sys.baseboard || "--";
    $("spec-bios").textContent = sys.bios_version || "--";
    $("spec-os").textContent = sys.os_name || "--";

    $("spec-cpu-name").textContent = cpu.name || "--";
    $("spec-cpu-cores").textContent =
      cpu.cores != null && cpu.threads != null ? `${cpu.cores} cores / ${cpu.threads} threads` : "--";
    $("spec-cpu-clock").textContent =
      cpu.max_clock_mhz ? `${(cpu.max_clock_mhz / 1000).toFixed(2)} GHz (${cpu.max_clock_mhz} MHz)` : "--";
    $("spec-cpu-cache").textContent =
      cpu.l2_cache_kb || cpu.l3_cache_kb
        ? `L2 ${fmtCacheKb(cpu.l2_cache_kb)} / L3 ${fmtCacheKb(cpu.l3_cache_kb)}`
        : "--";

    const installed = ram.total_installed_gb != null ? `${ram.total_installed_gb} GB` : "--";
    const usable = ram.total_usable_gb != null ? `${ram.total_usable_gb} GB usable` : "--";
    $("spec-ram-total").textContent = `${installed} (${usable})`;
    $("spec-ram-speed").textContent =
      [ram.running_mhz ? `${ram.running_mhz} MHz` : "", ram.memory_type].filter(Boolean).join(" ") || "--";

    renderSubList(
      "spec-ram-modules",
      ram.modules || [],
      (m) => {
        const speedText =
          m.configured_mhz && m.rated_mhz && m.configured_mhz !== m.rated_mhz
            ? `${m.configured_mhz} MHz (rated ${m.rated_mhz} MHz)`
            : `${m.configured_mhz || m.rated_mhz || "--"} MHz`;
        return `
          <div class="spec-subitem">
            <div class="spec-subhead">
              <span>${escapeHtml(m.slot || "DIMM")}</span>
              <span class="spec-badge">${escapeHtml(m.capacity_gb != null ? `${m.capacity_gb} GB` : "--")}</span>
            </div>
            <div class="spec-submeta">${escapeHtml(
              [m.manufacturer, m.part_number, m.memory_type, speedText].filter(Boolean).join(" · ")
            )}</div>
          </div>
        `;
      },
      "No DIMM details detected."
    );

    renderSubList(
      "spec-gpus",
      specs.gpus || [],
      (g) => {
        const vramBadge = g.vram_gb > 0 ? `${g.vram_gb} GB VRAM` : "Shared";
        const mode = g.width && g.height ? `${g.width}x${g.height}${g.refresh_hz ? ` @ ${g.refresh_hz} Hz` : ""}` : "";
        return `
          <div class="spec-subitem">
            <div class="spec-subhead">
              <span>${escapeHtml(g.name || "Graphics Adapter")}</span>
              <span class="spec-badge ${g.vram_gb > 0 ? "" : "muted"}">${escapeHtml(vramBadge)}</span>
            </div>
            <div class="spec-submeta">${escapeHtml(
              [mode, g.driver_version ? `Driver ${g.driver_version}` : ""].filter(Boolean).join(" · ") || "Active GPU"
            )}</div>
          </div>
        `;
      },
      "No graphics adapters detected."
    );

    renderSubList(
      "spec-displays",
      specs.displays || [],
      (d) => `
        <div class="spec-subitem">
          <div class="spec-subhead">
            <span>${escapeHtml(d.name || "Display Panel")}</span>
            <span class="spec-badge muted">${escapeHtml(d.manufacturer || "Monitor")}</span>
          </div>
        </div>
      `,
      ""
    );

    renderSubList(
      "spec-volumes",
      specs.volumes || [],
      (v) => {
        const pct = v.size_gb > 0 ? Math.min(100, Math.round((v.used_gb / v.size_gb) * 100)) : 0;
        const title = [v.drive, v.label].filter(Boolean).join(" ");
        return `
          <div class="spec-subitem">
            <div class="spec-subhead">
              <span>${escapeHtml(title || "Volume")}</span>
              <span class="spec-badge ok">${escapeHtml(v.filesystem || "FS")}</span>
            </div>
            <div class="spec-submeta">${escapeHtml(
              `${v.used_gb} GB used / ${v.size_gb} GB total · ${v.free_gb} GB free (${pct}%)`
            )}</div>
            <div class="disk-bar-track"><div class="disk-bar-fill" style="width:${pct}%"></div></div>
          </div>
        `;
      },
      ""
    );

    renderSubList(
      "spec-disks",
      specs.disks || [],
      (d) => {
        const style = d.PartitionStyle || "Unknown";
        const styleCls = style === "RAW" ? "raw" : "muted";
        return `
          <div class="spec-subitem">
            <div class="spec-subhead">
              <span>${escapeHtml(d.FriendlyName || "Physical Disk")}</span>
              <span class="spec-badges">
                <span class="spec-badge ${styleCls}">${escapeHtml(style)}</span>
                <span class="spec-badge">${escapeHtml(d.SizeGB != null ? `${d.SizeGB} GB` : "--")}</span>
              </span>
            </div>
            <div class="spec-submeta">${escapeHtml(
              [d.MediaType, d.BusType, d.OperationalStatus].filter(Boolean).join(" · ")
            )}</div>
          </div>
        `;
      },
      "No physical disks detected."
    );

    renderSubList(
      "spec-network",
      specs.network || [],
      (n) => {
        const isUp = String(n.status || "").toLowerCase() === "up";
        return `
          <div class="spec-subitem">
            <div class="spec-subhead">
              <span>${escapeHtml(n.name || "Adapter")}</span>
              <span class="spec-badge ${isUp ? "ok" : "muted"}">${escapeHtml(n.status || "--")}</span>
            </div>
            <div class="spec-submeta">${escapeHtml(
              [n.description, n.link_speed].filter(Boolean).join(" · ")
            )}</div>
          </div>
        `;
      },
      "No network adapters detected."
    );
  }

  function formatSpecsText(specs) {
    if (!specs || !specs.system) return "";
    const s = specs.system;
    const c = specs.cpu || {};
    const r = specs.ram || {};
    const lines = [
      `Model: ${[s.manufacturer, s.model].filter(Boolean).join(" ")}`,
      `Motherboard: ${s.baseboard || "--"} | BIOS: ${s.bios_version || "--"}`,
      `OS: ${s.os_name || "--"}`,
      `CPU: ${c.name || "--"} (${c.cores || "?"}c/${c.threads || "?"}t)`,
      `RAM: ${r.total_installed_gb || "?"} GB (${r.total_usable_gb || "?"} GB usable) @ ${r.running_mhz || "?"} MHz ${r.memory_type || ""}`.trim(),
    ];
    (specs.gpus || []).forEach((g) => {
      lines.push(`GPU: ${g.name}${g.vram_gb ? ` (${g.vram_gb} GB)` : ""}`);
    });
    (specs.disks || []).forEach((d) => {
      lines.push(`Disk: ${d.FriendlyName} - ${d.SizeGB} GB (${d.MediaType}/${d.BusType}, ${d.PartitionStyle})`);
    });
    return lines.join("\n");
  }

  async function fetchSpecs(refresh = false) {
    if (state.specsLoading) return;
    state.specsLoading = true;
    const refreshBtn = $("btn-refresh-specs");
    if (refreshBtn && refresh) {
      refreshBtn.disabled = true;
      refreshBtn.textContent = "Refreshing...";
    }
    try {
      const url = refresh ? "/api/specs?refresh=1" : "/api/specs";
      const res = await fetch(url, { cache: "no-store" });
      if (!res.ok) return;
      state.specs = await res.json();
      renderSpecs(state.specs);
    } catch (_) {
      // Keep existing rendered specs if request fails.
    } finally {
      state.specsLoading = false;
      if (refreshBtn) {
        refreshBtn.disabled = false;
        refreshBtn.textContent = "Refresh";
      }
    }
  }

  const AJAZZ_DIR_NAMES = ["Left", "Down", "Up", "Right"];
  const AJAZZ_SLEEP_NAMES = ["Never", "1 min", "5 min", "30 min"];

  function setAjazzStatus(text, isError = false) {
    const el = $("ajazz-apply-status");
    el.textContent = text;
    el.classList.toggle("error", isError);
  }

  function setLcdStatus(text, isError = false) {
    const el = $("ajazz-lcd-status");
    el.textContent = text;
    el.classList.toggle("error", isError);
  }

  function renderAjazzOverview() {
    $("ajazz-sum-ak820").classList.toggle("active", state.ajazzDevice === "ak820");
    $("ajazz-sum-aj159").classList.toggle("active", state.ajazzDevice === "aj159");

    const kb = state.ajazz;
    if (kb) {
      const linkBadge = $("ak820-sum-link");
      if (kb.connected && kb.device) {
        linkBadge.textContent = kb.device.link === "usb" ? "USB-C" : "2.4G";
        linkBadge.className = "spec-badge ok";
      } else {
        linkBadge.textContent = "Offline";
        linkBadge.className = "spec-badge muted";
      }

      const batt = kb.battery || {};
      const battVal = $("ak820-sum-batt");
      const battFill = $("ak820-sum-batt-fill");
      if (!kb.connected) {
        battVal.textContent = "--%";
        battFill.style.width = "0%";
      } else if (typeof batt.percent === "number") {
        const pct = Math.max(0, Math.min(100, Number(batt.percent)));
        battVal.textContent = `${pct}%`;
        battFill.style.width = `${pct}%`;
      } else if (batt.status === "wired_usb") {
        battVal.textContent = "USB-C";
        battFill.style.width = "100%";
      } else {
        battVal.textContent = "--% · Idle";
        battFill.style.width = "0%";
      }

      const s = kb.settings || {};
      const modes = kb.modes || [];
      const activeMode = modes.find((m) => Number(m.id) === Number(s.mode));
      const modeName = activeMode ? activeMode.label : "Custom";
      const hex = String(s.color || "#ff0000").toUpperCase();
      $("ak820-sum-rgb").textContent =
        Number(s.mode) === 0 ? "RGB: Off" : `RGB: ${modeName} · ${s.rainbow ? "Rainbow" : hex}`;
      const lcd = kb.lcd || {};
      $("ak820-sum-lcd").textContent = lcd.saved_frames
        ? `LCD: ${lcd.resolution || "128x128"} · ${lcd.saved_frames}f`
        : `LCD: ${lcd.panel || "0.85\" TFT"} (${lcd.resolution || "128x128"})`;
    }

    const ms = state.ajazzMouse;
    if (ms) {
      const linkBadge = $("aj159-sum-link");
      if (ms.connected && ms.device) {
        linkBadge.textContent = ms.device.link === "usb" ? "USB-C" : "2.4G 8K";
        linkBadge.className = "spec-badge ok";
      } else {
        linkBadge.textContent = "Offline";
        linkBadge.className = "spec-badge muted";
      }

      const battVal = $("aj159-sum-batt");
      const battFill = $("aj159-sum-batt-fill");
      if (!ms.connected) {
        battVal.textContent = "--%";
        battFill.style.width = "0%";
      } else if (ms.device && ms.device.link === "usb") {
        battVal.textContent = "USB-C";
        battFill.style.width = "100%";
      } else if (ms.battery && typeof ms.battery.percent === "number") {
        const pct = Math.max(0, Math.min(100, Number(ms.battery.percent)));
        battVal.textContent = `${pct}%`;
        battFill.style.width = `${pct}%`;
      } else {
        battVal.textContent = "--% · Idle";
        battFill.style.width = "0%";
      }

      const s = ms.settings || {};
      const stages = Array.isArray(s.dpi_stages) ? s.dpi_stages : [];
      const activeIdx = Math.max(0, Math.min(Number(s.active_dpi_stage || 0), Math.max(0, stages.length - 1)));
      const dpi = stages[activeIdx] ? stages[activeIdx].dpi : 1200;
      const lodLabels = ["1 mm", "2 mm", "3 mm"];
      $("aj159-sum-dpi").textContent = `${dpi} DPI · S${activeIdx + 1} · ${s.poll_rate_hz || 1000} Hz`;
      $("aj159-sum-tune").textContent = `LOD: ${lodLabels[Number(s.lod ?? 0)] || "1 mm"} · Sync ${
        s.motion_sync ? "On" : "Off"
      }`;
    }
  }

  function switchAjazzDevice(devKey) {
    state.ajazzDevice = devKey === "aj159" ? "aj159" : "ak820";
    $("ajazz-panel-ak820").classList.toggle("hidden", state.ajazzDevice !== "ak820");
    $("ajazz-panel-aj159").classList.toggle("hidden", state.ajazzDevice !== "aj159");
    renderAjazzOverview();
    if (state.ajazzDevice === "aj159") {
      fetchAjazzMouseState(false);
    } else {
      fetchAjazzState(false);
    }
  }

  function drawCustomCardToCanvas(topText, mainText, accentHex) {
    const canvas = $("ajazz-lcd-canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const now = new Date();
    const fallbackMain = now.toTimeString().slice(0, 5);
    const title = (topText || "AK820 PRO").trim().slice(0, 14);
    const body = (mainText || fallbackMain).trim().slice(0, 10);
    const accent = accentHex || "#1a73e8";

    ctx.fillStyle = "#0b1220";
    ctx.fillRect(0, 0, 128, 128);
    ctx.strokeStyle = accent;
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, 120, 120);
    ctx.fillStyle = "#8ab4f8";
    ctx.font = "bold 12px Segoe UI, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(title, 64, 34);
    ctx.fillStyle = "#ffffff";
    ctx.font = body.length > 6 ? "bold 18px Segoe UI, sans-serif" : "bold 28px Segoe UI, sans-serif";
    ctx.fillText(body, 64, 72);
    ctx.fillStyle = "#9aa0a6";
    ctx.font = "11px Segoe UI, sans-serif";
    ctx.fillText("128 x 128 TFT", 64, 104);
    return encodeCanvasToRgb565Base64(canvas);
  }

  function renderAjazzLcd(data) {
    const lcd = data.lcd || {};
    const imgEl = $("ajazz-lcd-preview");
    const canvasEl = $("ajazz-lcd-canvas");

    if (state.ajazzPendingLcdB64) {
      imgEl.classList.add("hidden");
      canvasEl.classList.remove("hidden");
    } else if (lcd.has_preview) {
      if (!imgEl.dataset.loaded) {
        imgEl.src = "/api/ajazz/lcd-preview";
        imgEl.dataset.loaded = "1";
      }
      imgEl.classList.remove("hidden");
      canvasEl.classList.add("hidden");
    } else {
      drawCustomCardToCanvas($("ajazz-lcd-text-top").value, $("ajazz-lcd-text-main").value, data.settings?.color);
      imgEl.classList.add("hidden");
      canvasEl.classList.remove("hidden");
    }

    $("ajazz-lcd-badge").textContent = `${lcd.resolution || "128x128"}`;
    const themeParts = [];
    if (lcd.saved_theme) themeParts.push(`Theme ${lcd.saved_theme}`);
    if (lcd.saved_frames) themeParts.push(`${lcd.saved_frames}f · ${lcd.frame_delay_ms || 50}ms`);
    $("ajazz-lcd-theme").textContent = themeParts.length ? themeParts.join(" · ") : "128x128 RGB565";

    $("ajazz-lcd-transport").textContent = lcd.image_upload_supported
      ? "USB-C · Clock & image ready"
      : "2.4G · Clock sync only (Image: USB-C)";

    const syncLabel = lcd.last_clock_sync
      ? `Synced · ${new Date(lcd.last_clock_sync).toLocaleTimeString()}`
      : "Clock: Not synced";
    $("ajazz-lcd-clock-sync").textContent = syncLabel;
    $("btn-ajazz-sync-clock").disabled = !data.connected;
  }

  function renderAjazz(data) {
    if (!data) return;
    const badge = $("ajazz-conn-badge");
    const detail = $("ajazz-conn-detail");
    const fw = data.lcd && data.lcd.firmware_version ? ` · FW ${data.lcd.firmware_version}` : "";
    if (data.connected && data.device) {
      badge.textContent = `${data.device.label}`;
      badge.className = "spec-badge ok";
      detail.textContent = `${data.device.vid}:${data.device.pid}${fw}`;
    } else {
      badge.textContent = "Offline";
      badge.className = "spec-badge muted";
      detail.textContent = "USB-C or 2.4G dongle";
    }

    const batt = data.battery || {};
    const kbBattPct = $("ajazz-kb-battery-pct");
    const kbBattMeta = $("ajazz-kb-battery-meta");
    const kbBattFill = $("ajazz-kb-battery-fill");
    if (!data.connected) {
      kbBattPct.textContent = "--%";
      kbBattMeta.textContent = "Offline";
      kbBattFill.style.width = "0%";
    } else if (batt.status === "wired_usb") {
      kbBattPct.textContent = "USB-C";
      kbBattMeta.textContent = "Wired power";
      kbBattFill.style.width = "100%";
    } else if (typeof batt.percent === "number") {
      const pct = Math.max(0, Math.min(100, Number(batt.percent)));
      kbBattPct.textContent = `${pct}%`;
      kbBattMeta.textContent = "2.4G wireless";
      kbBattFill.style.width = `${pct}%`;
    } else {
      kbBattPct.textContent = "--%";
      kbBattMeta.textContent = "Idle · tap key";
      kbBattFill.style.width = "0%";
    }

    renderAjazzLcd(data);

    const s = data.settings || {};
    const hex = String(s.color || "#ff0000").toLowerCase();
    $("ajazz-color-picker").value = hex;
    $("ajazz-color-hex").textContent = hex.toUpperCase();
    $("toggle-ajazz-rainbow").checked = Boolean(s.rainbow);

    $("ajazz-brightness-val").textContent = `${s.brightness ?? 5} / 5`;
    $("ajazz-speed-val").textContent = `${s.speed ?? 3} / 5`;
    $("ajazz-direction-val").textContent = AJAZZ_DIR_NAMES[Number(s.direction ?? 0)] || "Left";
    $("ajazz-sleep-val").textContent = AJAZZ_SLEEP_NAMES[Number(s.sleep_level ?? 2)] || "5 min";
    $("ajazz-resp-val").textContent = `${s.response_level ?? 2}`;

    $("toggle-ajazz-fn-toggle").checked = Boolean(s.fn_toggle);
    $("toggle-ajazz-block-win").checked = Boolean(s.block_win);
    $("toggle-ajazz-block-alttab").checked = Boolean(s.block_alt_tab);
    $("toggle-ajazz-block-altf4").checked = Boolean(s.block_alt_f4);

    document.querySelectorAll(".ajazz-step-btn").forEach((btn) => {
      const field = btn.dataset.field;
      const val = Number(btn.dataset.val);
      btn.classList.toggle("active", Number(s[field]) === val);
    });

    const modes = data.modes || [];
    const modeSelect = $("ajazz-mode-select");
    if (!modeSelect.options.length && modes.length) {
      modeSelect.innerHTML = modes
        .map((m) => `<option value="${m.id}">${escapeHtml(m.label)}</option>`)
        .join("");
    }
    modeSelect.value = String(s.mode ?? 1);

    const activeMode = modes.find((m) => Number(m.id) === Number(s.mode));
    $("ajazz-preview-label").textContent = activeMode ? activeMode.label : `Mode ${s.mode ?? "--"}`;

    renderAjazzOverview();
  }

  function setMouseStatus(text, isError = false) {
    const el = $("mouse-apply-status");
    el.textContent = text;
    el.classList.toggle("error", isError);
  }

  function renderAjazzMouse(data) {
    if (!data) return;
    const badge = $("mouse-conn-badge");
    const detail = $("mouse-conn-detail");
    const maxHz = data.device ? Number(data.device.max_hz || 8000) : 8000;
    const isUsb = data.device && data.device.link === "usb";

    if (data.connected && data.device) {
      badge.textContent = `${data.device.label}`;
      badge.className = "spec-badge ok";
      detail.textContent = `${data.device.vid}:${data.device.pid} · ${maxHz} Hz`;
    } else {
      badge.textContent = "Offline";
      badge.className = "spec-badge muted";
      detail.textContent = "2.4G 8K dongle or USB-C";
    }

    const battPctEl = $("mouse-battery-pct");
    const battMetaEl = $("mouse-battery-meta");
    const battFillEl = $("mouse-battery-fill");
    if (!data.connected) {
      battPctEl.textContent = "--%";
      battMetaEl.textContent = "Offline";
      battFillEl.style.width = "0%";
    } else if (isUsb) {
      battPctEl.textContent = "USB";
      battMetaEl.textContent = "Wired USB";
      battFillEl.style.width = "100%";
    } else if (data.battery && typeof data.battery.percent === "number") {
      const pct = Math.max(0, Math.min(100, Number(data.battery.percent)));
      battPctEl.textContent = `${pct}%`;
      battMetaEl.textContent = "2.4G wireless";
      battFillEl.style.width = `${pct}%`;
    } else {
      battPctEl.textContent = "--%";
      battMetaEl.textContent = "Idle";
      battFillEl.style.width = "0%";
    }

    const s = data.settings || {};
    const activePoll = Number(s.poll_rate_hz || 1000);
    $("mouse-poll-badge").textContent = `${activePoll} Hz`;

    const pollGrid = $("mouse-poll-grid");
    const rates = data.poll_rates || [125, 250, 500, 1000, 2000, 4000, 8000];
    if (!pollGrid.childElementCount) {
      pollGrid.innerHTML = rates
        .map((hz) => `<button class="mouse-poll-btn" type="button" data-hz="${hz}">${hz} Hz</button>`)
        .join("");
      pollGrid.querySelectorAll(".mouse-poll-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          applyAjazzMouseSettings({ poll_rate_hz: Number(btn.dataset.hz) });
        });
      });
    }
    pollGrid.querySelectorAll(".mouse-poll-btn").forEach((btn) => {
      const hz = Number(btn.dataset.hz);
      btn.classList.toggle("active", hz === activePoll);
      btn.disabled = data.connected && hz > maxHz;
    });

    const stageCount = Number(s.stage_count || 6);
    const activeStage = Math.min(Number(s.active_dpi_stage || 0), stageCount - 1);
    const stages = Array.isArray(s.dpi_stages) ? s.dpi_stages : [];
    const curStageObj = stages[activeStage] || { dpi: 1200, color: "#00e640" };

    $("mouse-dpi-badge").textContent = `S${activeStage + 1} · ${curStageObj.dpi} DPI`;
    $("mouse-editor-label").textContent = `Stage ${activeStage + 1}`;
    $("mouse-dpi-input").value = curStageObj.dpi;
    $("mouse-dpi-slider").value = Math.min(26000, Number(curStageObj.dpi || 1200));
    const stageColor = String(curStageObj.color || "#00e640").toLowerCase();
    $("mouse-stage-color").value = stageColor;
    $("mouse-stage-color-hex").textContent = stageColor.toUpperCase();

    document.querySelectorAll(".mouse-count-btn").forEach((btn) => {
      btn.classList.toggle("active", Number(btn.dataset.count) === stageCount);
    });

    const dpiList = $("mouse-dpi-list");
    dpiList.innerHTML = stages
      .slice(0, 8)
      .map((st, idx) => {
        const disabledCls = idx >= stageCount ? " disabled" : "";
        const activeCls = idx === activeStage ? " active" : "";
        return `
          <button class="mouse-dpi-card${activeCls}${disabledCls}" type="button" data-stage="${idx}">
            <div class="mouse-dpi-card-top">
              <span>Stage ${idx + 1}</span>
              <span class="mouse-dpi-dot" style="background:${escapeHtml(st.color || "#00e640")}"></span>
            </div>
            <div class="mouse-dpi-val">${escapeHtml(String(st.dpi))}</div>
          </button>
        `;
      })
      .join("");
    dpiList.querySelectorAll(".mouse-dpi-card").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = Number(btn.dataset.stage);
        const cur = (state.ajazzMouse && state.ajazzMouse.settings) || {};
        const nextCount = idx >= Number(cur.stage_count || 6) ? idx + 1 : cur.stage_count;
        applyAjazzMouseSettings({ active_dpi_stage: idx, stage_count: nextCount });
      });
    });

    const lodVal = Number(s.lod ?? 0);
    const lodLabels = ["1 mm", "2 mm", "3 mm"];
    $("mouse-lod-val").textContent = lodLabels[lodVal] || "1 mm";
    document.querySelectorAll(".mouse-lod-btn").forEach((btn) => {
      btn.classList.toggle("active", Number(btn.dataset.lod) === lodVal);
    });

    $("toggle-mouse-motion-sync").checked = Boolean(s.motion_sync);
    $("toggle-mouse-angle-snap").checked = Boolean(s.angle_snap);
    $("toggle-mouse-power-save").checked = Boolean(s.power_save);
    $("toggle-mouse-charging-led").checked = Boolean(s.charging_led);
    $("mouse-debounce-select").value = String(s.debounce_ms ?? 1);
    $("mouse-sleep-select").value = String(s.sleep_idle_s ?? 60);

    const hiHex = String(s.battery_led_high || "#00e640").toLowerCase();
    const loHex = String(s.battery_led_low || "#ff2a2a").toLowerCase();
    $("mouse-batt-high-color").value = hiHex;
    $("mouse-batt-high-hex").textContent = hiHex.toUpperCase();
    $("mouse-batt-low-color").value = loHex;
    $("mouse-batt-low-hex").textContent = loHex.toUpperCase();
    renderAjazzOverview();
  }

  async function fetchAjazzMouseState(refreshBattery = false) {
    try {
      const q = refreshBattery ? "?refresh=1" : "";
      const res = await fetch(`/api/ajazz-mouse${q}`, { cache: "no-store" });
      if (!res.ok) return;
      state.ajazzMouse = await res.json();
      renderAjazzMouse(state.ajazzMouse);
    } catch (_) {}
  }

  function applyAjazzMouseSettings(patch = {}, debounceMs = 0) {
    const current = (state.ajazzMouse && state.ajazzMouse.settings) || {};
    const nextSettings = {
      ...current,
      ...patch,
      dpi_stages: patch.dpi_stages || (current.dpi_stages ? current.dpi_stages.map((d) => ({ ...d })) : []),
    };
    if (state.ajazzMouse) {
      state.ajazzMouse = { ...state.ajazzMouse, settings: nextSettings };
      renderAjazzMouse(state.ajazzMouse);
    }

    if (state.ajazzMouseDebounce) {
      clearTimeout(state.ajazzMouseDebounce);
      state.ajazzMouseDebounce = null;
    }

    const sendNow = async () => {
      setMouseStatus("Applying to AJ159 Pro...");
      try {
        const res = await fetch("/api/ajazz-mouse/settings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(nextSettings),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          setMouseStatus(data.error || "Failed to update mouse", true);
          return;
        }
        state.ajazzMouse = data;
        renderAjazzMouse(state.ajazzMouse);
        const st = data.settings;
        const activeSt = (st.dpi_stages || [])[st.active_dpi_stage] || {};
        setMouseStatus(`Applied · ${st.poll_rate_hz} Hz · ${activeSt.dpi || "--"} DPI`);
      } catch (_) {
        setMouseStatus("Connection error while updating mouse", true);
      }
    };

    if (debounceMs > 0) {
      state.ajazzMouseDebounce = setTimeout(sendNow, debounceMs);
    } else {
      sendNow();
    }
  }

  function updateActiveMouseStage(stagePatch, debounceMs = 0) {
    const s = (state.ajazzMouse && state.ajazzMouse.settings) || {};
    const stages = Array.isArray(s.dpi_stages) ? s.dpi_stages.map((d) => ({ ...d })) : [];
    const idx = Math.max(0, Math.min(Number(s.active_dpi_stage || 0), Math.max(0, stages.length - 1)));
    if (!stages[idx]) return;
    stages[idx] = { ...stages[idx], ...stagePatch };
    applyAjazzMouseSettings({ dpi_stages: stages }, debounceMs);
  }

  async function fetchAjazzState(refreshBattery = false) {
    try {
      const q = refreshBattery ? "?refresh=1" : "";
      const res = await fetch(`/api/ajazz${q}`, { cache: "no-store" });
      if (!res.ok) return;
      state.ajazz = await res.json();
      renderAjazz(state.ajazz);
    } catch (_) {}
  }

  function encodeCanvasToRgb565Base64(canvas) {
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    const rgba = ctx.getImageData(0, 0, 128, 128).data;
    const out = new Uint8Array(128 * 128 * 2);
    let j = 0;
    for (let i = 0; i < rgba.length; i += 4) {
      const v = ((rgba[i] & 0xf8) << 8) | ((rgba[i + 1] & 0xfc) << 3) | (rgba[i + 2] >> 3);
      out[j++] = v & 0xff;
      out[j++] = (v >> 8) & 0xff;
    }
    let bin = "";
    for (let k = 0; k < out.length; k += 4096) {
      bin += String.fromCharCode(...out.subarray(k, k + 4096));
    }
    return btoa(bin);
  }

  function renderLoadedImageToCanvas() {
    const img = state.ajazzLoadedImg;
    if (!img) return;
    const canvas = $("ajazz-lcd-canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const fit = $("ajazz-lcd-fit").value || "crop";
    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, 128, 128);
    if (fit === "stretch") {
      ctx.drawImage(img, 0, 0, 128, 128);
    } else {
      const scale = fit === "contain" ? Math.min(128 / img.width, 128 / img.height) : Math.max(128 / img.width, 128 / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      ctx.drawImage(img, (128 - w) / 2, (128 - h) / 2, w, h);
    }
    state.ajazzPendingLcdB64 = encodeCanvasToRgb565Base64(canvas);
    setLcdStatus(`Ready: ${state.ajazzPendingLcdName}`);
    if (state.ajazz) renderAjazzLcd(state.ajazz);
  }

  function loadLcdImageFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        state.ajazzLoadedImg = img;
        state.ajazzPendingLcdName = file.name;
        renderLoadedImageToCanvas();
      };
      img.src = String(reader.result || "");
    };
    reader.readAsDataURL(file);
  }

  async function syncAjazzClock() {
    setAjazzStatus("Syncing...");
    try {
      const res = await fetch("/api/ajazz/clock", { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        const msg = data.error || "Sync failed";
        setAjazzStatus(msg, true);
        setLcdStatus(msg, true);
        return;
      }
      state.ajazz = data;
      renderAjazz(state.ajazz);
      setLcdStatus("Clock synced");
      setAjazzStatus("Clock synced");
    } catch (_) {
      setAjazzStatus("Connection error", true);
    }
  }

  async function uploadAjazzScreen() {
    if (!state.ajazzPendingLcdB64) {
      const top = $("ajazz-lcd-text-top").value;
      const main = $("ajazz-lcd-text-main").value;
      state.ajazzPendingLcdB64 = drawCustomCardToCanvas(top, main, state.ajazz?.settings?.color);
      state.ajazzPendingLcdName = "Card";
      if (state.ajazz) renderAjazzLcd(state.ajazz);
    }
    if (!state.ajazzPendingLcdB64) {
      setLcdStatus("Select image first", true);
      return;
    }
    const btn = $("btn-ajazz-upload-screen");
    btn.disabled = true;
    setLcdStatus("Uploading (USB-C)...");
    setAjazzStatus("Uploading...");
    try {
      const res = await fetch("/api/ajazz/screen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rgb565_b64: state.ajazzPendingLcdB64 }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.ok) {
        const msg = data.error || "Upload failed";
        setLcdStatus(msg, true);
        setAjazzStatus(msg, true);
        return;
      }
      state.ajazz = data;
      state.ajazzPendingLcdB64 = null;
      state.ajazzLoadedImg = null;
      setLcdStatus(`Uploaded: ${state.ajazzPendingLcdName}`);
      renderAjazz(state.ajazz);
      setAjazzStatus("LCD updated");
    } catch (_) {
      setLcdStatus("Connection error", true);
      setAjazzStatus("Connection error", true);
    } finally {
      btn.disabled = false;
    }
  }

  function applyAjazzLighting(patch = {}, debounceMs = 0) {
    const current = (state.ajazz && state.ajazz.settings) || {
      mode: 1,
      color: "#ff0000",
      rainbow: false,
      brightness: 5,
      speed: 3,
      direction: 0,
    };
    const nextSettings = { ...current, ...patch };
    if (state.ajazz) {
      state.ajazz = { ...state.ajazz, settings: nextSettings };
      renderAjazz(state.ajazz);
    }

    if (state.ajazzDebounce) {
      clearTimeout(state.ajazzDebounce);
      state.ajazzDebounce = null;
    }

    const sendNow = async () => {
      setAjazzStatus("Sending to keyboard...");
      try {
        const res = await fetch("/api/ajazz/lighting", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(nextSettings),
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.ok) {
          setAjazzStatus(data.error || "Failed to update lighting", true);
          return;
        }
        state.ajazz = data;
        renderAjazz(state.ajazz);
        const modeObj = (data.modes || []).find((m) => m.id === data.settings.mode);
        const modeLabel = modeObj ? modeObj.label : `Mode ${data.settings.mode}`;
        const colorLabel =
          data.settings.mode === 0 ? "Off" : data.settings.rainbow ? "Rainbow" : data.settings.color.toUpperCase();
        setAjazzStatus(`Applied · ${modeLabel} (${colorLabel})`);
      } catch (_) {
        setAjazzStatus("Connection error while updating keyboard", true);
      }
    };

    if (debounceMs > 0) {
      state.ajazzDebounce = setTimeout(sendNow, debounceMs);
    } else {
      sendNow();
    }
  }

  function fmtIdr(amount) {
    if (amount === null || amount === undefined || Number.isNaN(amount)) return "--";
    const val = Math.max(0, Number(amount));
    if (val < 10) return `Rp ${val.toFixed(2).replace(".", ",")}`;
    if (val < 100) return `Rp ${val.toFixed(1).replace(".", ",")}`;
    return `Rp ${Math.round(val).toLocaleString("id-ID")}`;
  }

  function fmtBootStamp(tsSec) {
    if (!tsSec) return "--";
    const d = new Date(tsSec * 1000);
    const locale = state.lang === "id" ? "id-ID" : "en-US";
    const day = d.toLocaleDateString(locale, { day: "numeric", month: "short" });
    const hm = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
    return `${day} · ${hm}`;
  }

  function setElecSaveStatus(msg, isError = false) {
    const el = $("elec-save-status");
    if (!el) return;
    el.textContent = msg;
    el.style.color = isError ? "var(--danger)" : "var(--text-secondary)";
  }

  function renderElectricity(elec) {
    if (!elec) return;
    const lang = state.lang;
    const settings = elec.settings || {};
    const live = elec.live || null;
    const cur = elec.current_session || null;

    const presetSel = $("elec-preset-select");
    if (presetSel && elec.presets && presetSel.options.length === 0) {
      presetSel.innerHTML = elec.presets
        .map((p) => {
          const suffix = p.rate_idr !== null && p.rate_idr !== undefined ? ` (${fmtIdr(p.rate_idr)})` : "";
          return `<option value="${escapeHtml(p.key)}">${escapeHtml(p.label + suffix)}</option>`;
        })
        .join("");
    }
    if (presetSel && document.activeElement !== presetSel && settings.tariff_preset) {
      presetSel.value = settings.tariff_preset;
    }

    const tariffInp = $("elec-tariff-input");
    if (tariffInp && document.activeElement !== tariffInp && settings.tariff_idr_per_kwh !== undefined) {
      tariffInp.value = String(settings.tariff_idr_per_kwh);
    }
    const baseInp = $("elec-base-input");
    if (baseInp && document.activeElement !== baseInp && settings.base_overhead_w !== undefined) {
      baseInp.value = String(settings.base_overhead_w);
    }
    document.querySelectorAll(".elec-base-preset").forEach((btn) => {
      btn.classList.toggle("active", Math.abs(Number(btn.dataset.base) - Number(settings.base_overhead_w)) < 0.2);
    });
    const effInp = $("elec-eff-input");
    if (effInp && document.activeElement !== effInp && settings.adapter_efficiency_pct !== undefined) {
      effInp.value = String(settings.adapter_efficiency_pct);
    }
    const autoInp = $("toggle-autostart");
    if (autoInp && elec.autostart) {
      autoInp.disabled = !elec.autostart.supported;
      autoInp.checked = Boolean(elec.autostart.enabled);
    }

    const badge = $("elec-ac-badge");
    const wallLbl = $("elec-wall-label");
    if (live) {
      badge.textContent = t(live.ac_online ? "elec_ac_badge" : "elec_bat_badge", null, lang);
      badge.className = `spec-badge ${live.ac_online ? "ok" : "raw"}`;
      wallLbl.textContent = t(live.ac_online ? "elec_wall_power" : "elec_bat_draw", null, lang);
      $("elec-live-wall").textContent = live.ac_online ? `${live.wall_w.toFixed(1)} W` : `${live.system_w.toFixed(1)} W`;
      const perHr = t("elec_per_hour", null, lang);
      $("elec-live-rate").textContent = live.ac_online
        ? `${fmtIdr(live.hourly_cost_idr)} ${perHr}`
        : `≈ ${fmtIdr(live.equiv_hourly_cost_idr)} ${perHr}`;

      $("elec-chip-cpu").textContent = `${live.cpu_w.toFixed(1)}W${live.cpu_measured ? "" : "*"}`;
      $("elec-chip-gpu").textContent = live.gpu_measured ? `${live.gpu_w.toFixed(1)}W` : "--";
      $("elec-chip-base").textContent = `${live.base_w.toFixed(0)}W`;
      $("elec-chip-charge").textContent = live.charge_w > 0.1 ? `${live.charge_w.toFixed(1)}W` : "0W";
      $("elec-chip-loss").textContent = live.adapter_loss_w > 0.1 ? `${live.adapter_loss_w.toFixed(1)}W` : "0W";

      const denom = Math.max(0.1, live.ac_online ? live.wall_w : live.system_w);
      const pct = (w) => `${Math.max(0, Math.min(100, (w / denom) * 100)).toFixed(1)}%`;
      $("elec-bar-cpu").style.width = pct(live.cpu_w);
      $("elec-bar-gpu").style.width = pct(live.gpu_w);
      $("elec-bar-base").style.width = pct(live.base_w);
      $("elec-bar-charge").style.width = pct(live.charge_w);
      $("elec-bar-loss").style.width = pct(live.adapter_loss_w);
    } else {
      badge.textContent = "--";
      badge.className = "spec-badge muted";
      $("elec-live-wall").textContent = "--";
      $("elec-live-rate").textContent = "--";
      ["cpu", "gpu", "base", "charge", "loss"].forEach((k) => {
        $(`elec-bar-${k}`).style.width = "0%";
      });
    }

    if (cur) {
      const showEq = cur.wall_kwh <= 0.0001 && cur.equiv_battery_cost_idr > 0;
      $("elec-cur-cost").textContent = showEq ? `≈ ${fmtIdr(cur.equiv_battery_cost_idr)}` : fmtIdr(cur.cost_idr);
      $("elec-cur-kwh").textContent = showEq
        ? `${cur.system_kwh.toFixed(3)} kWh`
        : `${cur.wall_kwh.toFixed(3)} kWh · ${cur.avg_wall_w.toFixed(0)}W`;
      let metaLine = `${t("elec_boot", null, lang)} ${fmtBootStamp(cur.boot_at)} · ${t("elec_monitored", null, lang)} ${fmtUptime(cur.monitored_sec)} / ${t("elec_uptime", null, lang)} ${fmtUptime(cur.uptime_sec)}`;
      if (cur.est_full_cost_idr !== null && cur.est_full_cost_idr !== undefined) {
        metaLine += ` · ${t("elec_full_est", null, lang)}: ${fmtIdr(cur.est_full_cost_idr)}`;
      }
      $("elec-cur-session-meta").textContent = metaLine;
    } else {
      $("elec-cur-cost").textContent = "--";
      $("elec-cur-kwh").textContent = "--";
      $("elec-cur-session-meta").textContent = t("elec_wait", null, lang);
    }

    const sesUnit = t("elec_sessions_unit", null, lang);
    const renderPeriod = (prefix, b) => {
      if (!b) return;
      $(`elec-${prefix}-cost`).textContent = fmtIdr(b.cost_idr);
      $(`elec-${prefix}-meta`).textContent = `${b.wall_kwh.toFixed(3)} kWh · ${b.session_count} ${sesUnit}`;
    };
    renderPeriod("today", elec.today);
    renderPeriod("month", elec.this_month);
    renderPeriod("total", elec.all_time);

    const proj = elec.projection_30d || {};
    $("elec-proj-cost").textContent = proj.active_days ? fmtIdr(proj.est_30d_cost_idr) : "--";
    $("elec-proj-meta").textContent = proj.active_days
      ? t("elec_avg_day", { cost: fmtIdr(proj.avg_daily_cost_idr) }, lang)
      : "--";

    const daily = elec.daily_7d || [];
    const maxCost = Math.max(1, ...daily.map((d) => Number(d.cost_idr || 0)));
    const total7dCost = daily.reduce((acc, d) => acc + Number(d.cost_idr || 0), 0);
    $("elec-7d-total").textContent = t("elec_7d_total", { cost: fmtIdr(total7dCost) }, lang);
    $("elec-7d-chart").innerHTML = daily
      .map((d, idx) => {
        const c = Number(d.cost_idr || 0);
        const hPct = c > 0 ? Math.max(8, Math.round((c / maxCost) * 100)) : 2;
        const valLbl = c > 0 ? fmtIdr(c).replace("Rp ", "") : "0";
        const isToday = idx === daily.length - 1;
        return `
          <div class="elec-7d-col" title="${escapeHtml(d.date)}: ${escapeHtml(fmtIdr(c))} (${d.wall_kwh.toFixed(3)} kWh)">
            <span class="elec-7d-val">${escapeHtml(valLbl)}</span>
            <div class="elec-7d-bar-wrap">
              <div class="elec-7d-bar ${isToday ? "today" : ""}" style="height:${hPct}%"></div>
            </div>
            <span class="elec-7d-day">${escapeHtml(d.day_short)}</span>
          </div>
        `;
      })
      .join("");

    const listEl = $("elec-sessions-list");
    const sessions = elec.sessions || [];
    if (!sessions.length) {
      listEl.innerHTML = `<p class="empty-note">${escapeHtml(t("elec_no_sessions", null, lang))}</p>`;
      return;
    }
    listEl.innerHTML = sessions
      .slice(0, 40)
      .map((s) => {
        const curBadge = s.is_current ? ` <span class="spec-badge ok">${escapeHtml(t("active", null, lang))}</span>` : "";
        const useEq = s.wall_kwh <= 0.0001 && s.equiv_battery_cost_idr > 0;
        const costText = useEq ? `≈ ${fmtIdr(s.equiv_battery_cost_idr)}` : fmtIdr(s.cost_idr);
        const kwhText = useEq ? `${s.system_kwh.toFixed(3)} kWh bat` : `${s.wall_kwh.toFixed(3)} kWh`;
        const avgShow = s.avg_wall_w > 0 ? s.avg_wall_w : s.avg_system_w;
        const peakShow = s.peak_wall_w > 0 ? s.peak_wall_w : s.peak_system_w;
        return `
          <div class="event-row">
            <div>
              <div class="event-detail">${escapeHtml(fmtBootStamp(s.boot_at))}${curBadge}</div>
              <div class="state-sub">${escapeHtml(t("elec_uptime", null, lang))} ${escapeHtml(fmtUptime(s.uptime_sec))} · ${escapeHtml(t("elec_monitored", null, lang))} ${escapeHtml(fmtUptime(s.monitored_sec))} · Avg ${avgShow.toFixed(1)} W</div>
            </div>
            <div class="event-meta">
              <strong style="color:var(--text)">${escapeHtml(costText)}</strong><br>${escapeHtml(kwhText)} · Peak ${peakShow.toFixed(0)} W
            </div>
          </div>
        `;
      })
      .join("");
  }

  async function fetchElectricityReport() {
    try {
      const res = await fetch("/api/electricity", { cache: "no-store" });
      if (!res.ok) return;
      state.electricity = await res.json();
      renderElectricity(state.electricity);
    } catch (_) {}
  }

  async function saveElectricitySettings(overridePayload = null) {
    const payload = overridePayload || {
      tariff_preset: $("elec-preset-select").value,
      tariff_idr_per_kwh: Number($("elec-tariff-input").value),
      base_overhead_w: Number($("elec-base-input").value),
      adapter_efficiency_pct: Number($("elec-eff-input").value),
    };
    try {
      const res = await fetch("/api/electricity/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setElecSaveStatus(data.error || t("save_failed"), true);
        return;
      }
      state.electricity = data;
      renderElectricity(state.electricity);
      setElecSaveStatus(t("saved"));
      setTimeout(() => setElecSaveStatus(""), 1500);
    } catch (_) {
      setElecSaveStatus(t("conn_error"), true);
    }
  }

  function switchTab(tabName) {
    state.tab = tabName;
    document.querySelectorAll(".nav-tab").forEach((btn) => {
      const active = btn.dataset.tab === tabName;
      btn.classList.toggle("active", active);
      btn.setAttribute("aria-selected", active ? "true" : "false");
    });
    ["overview", "power", "listrik", "health", "specs", "ajazz"].forEach((name) => {
      $(`tab-${name}`).classList.toggle("hidden", name !== tabName);
    });
    if (tabName === "specs" && !state.specs) {
      fetchSpecs(false);
    } else if (tabName === "listrik") {
      fetchElectricityReport();
    } else if (tabName === "ajazz") {
      fetchAjazzState(false);
      fetchAjazzMouseState(false);
    }
  }

  function bindControls() {
    document.querySelectorAll(".nav-tab").forEach((btn) => {
      btn.addEventListener("click", () => switchTab(btn.dataset.tab));
    });

    document.querySelectorAll(".perf-btn").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const mode = btn.dataset.mode;
        const buttons = document.querySelectorAll(".perf-btn");
        buttons.forEach((b) => {
          b.disabled = true;
        });
        try {
          const res = await fetch("/api/performance-mode", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ mode }),
          });
          if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            $("perf-mode-caption").textContent = err.error || "Failed to switch mode";
          } else {
            await fetchTelemetry();
          }
        } catch (_) {
          $("perf-mode-caption").textContent = "Connection error";
        } finally {
          buttons.forEach((b) => {
            b.disabled = false;
          });
        }
      });
    });

    $("btn-lang").addEventListener("click", () => {
      applyLang(state.lang === "id" ? "en" : "id");
    });

    $("btn-theme").addEventListener("click", () => {
      const cur = document.documentElement.getAttribute("data-theme");
      applyTheme(cur === "dark" ? "light" : "dark");
    });

    $("btn-live").addEventListener("click", () => {
      state.paused = !state.paused;
      $("btn-live").classList.toggle("paused", state.paused);
      $("live-label").textContent = t(state.paused ? "paused" : "live");
      restartPolling();
    });

    $("btn-export").addEventListener("click", () => {
      const a = document.createElement("a");
      a.href = "/api/export.csv";
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();
    });

    $("btn-reset-stats").addEventListener("click", async () => {
      const btn = $("btn-reset-stats");
      try {
        const res = await fetch("/api/reset-stats", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ clear_events: false }),
        });
        if (res.ok) {
          btn.textContent = "Done";
          setTimeout(() => {
            btn.textContent = "Reset";
          }, 900);
          await fetchTelemetry();
        }
      } catch (_) {}
    });

    $("btn-clear-events").addEventListener("click", async () => {
      const btn = $("btn-clear-events");
      try {
        const res = await fetch("/api/clear-events", { method: "POST" });
        if (res.ok) {
          btn.textContent = "Cleared";
          setTimeout(() => {
            btn.textContent = "Clear";
          }, 900);
          await fetchTelemetry();
        }
      } catch (_) {}
    });

    $("toggle-gpu").addEventListener("change", async (e) => {
      try {
        await fetch("/api/gpu-polling", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ enabled: e.target.checked }),
        });
        await fetchTelemetry();
      } catch (_) {}
    });

    $("toggle-charge-80").addEventListener("change", async (e) => {
      const enabled = e.target.checked;
      if (enabled && "Notification" in window && Notification.permission === "default") {
        try {
          Notification.requestPermission();
        } catch (_) {}
      }
      try {
        await fetch("/api/charge-limit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ enabled }),
        });
        await fetchTelemetry();
      } catch (_) {}
    });

    $("btn-dismiss-80").addEventListener("click", async () => {
      try {
        await fetch("/api/charge-limit-dismiss", { method: "POST" });
        await fetchTelemetry();
      } catch (_) {}
    });

    document.querySelectorAll(".seg-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".seg-btn").forEach((b) => {
          b.classList.remove("active");
          b.setAttribute("aria-selected", "false");
        });
        btn.classList.add("active");
        btn.setAttribute("aria-selected", "true");
        state.metric = btn.dataset.metric;
        renderChart();
      });
    });

    document.querySelectorAll(".win-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".win-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        state.windowSec = Number(btn.dataset.window);
        fetchTelemetry();
      });
    });

    document.querySelectorAll(".rate-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".rate-btn").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        state.intervalMs = Number(btn.dataset.rate);
        restartPolling();
      });
    });

    $("btn-refresh-specs").addEventListener("click", () => {
      fetchSpecs(true);
    });

    $("btn-copy-specs").addEventListener("click", async () => {
      const btn = $("btn-copy-specs");
      const text = formatSpecsText(state.specs);
      if (!text || !navigator.clipboard) return;
      try {
        await navigator.clipboard.writeText(text);
        btn.textContent = "Copied";
        setTimeout(() => {
          btn.textContent = "Copy";
        }, 1200);
      } catch (_) {}
    });

    $("ajazz-refresh-all-btn").addEventListener("click", () => {
      fetchAjazzState(true);
      fetchAjazzMouseState(true);
    });

    document.querySelectorAll(".ajazz-summary-tile").forEach((tile) => {
      tile.addEventListener("click", () => switchAjazzDevice(tile.dataset.ajdev));
    });

    $("ajazz-refresh-btn").addEventListener("click", () => {
      fetchAjazzState(true);
    });

    $("btn-ajazz-sync-clock").addEventListener("click", () => {
      syncAjazzClock();
    });

    $("ajazz-lcd-file").addEventListener("change", (e) => {
      const file = e.target.files && e.target.files[0];
      if (file) loadLcdImageFile(file);
    });

    $("ajazz-lcd-fit").addEventListener("change", () => {
      if (state.ajazzLoadedImg) renderLoadedImageToCanvas();
    });

    $("btn-ajazz-make-card").addEventListener("click", () => {
      state.ajazzLoadedImg = null;
      const top = $("ajazz-lcd-text-top").value;
      const main = $("ajazz-lcd-text-main").value;
      state.ajazzPendingLcdB64 = drawCustomCardToCanvas(top, main, state.ajazz?.settings?.color);
      state.ajazzPendingLcdName = "Custom Card";
      setLcdStatus("Preview ready");
      if (state.ajazz) renderAjazzLcd(state.ajazz);
    });

    $("btn-ajazz-upload-screen").addEventListener("click", () => {
      uploadAjazzScreen();
    });

    $("ajazz-mode-select").addEventListener("change", (e) => {
      applyAjazzLighting({ mode: Number(e.target.value) });
    });

    $("btn-ajazz-sys-apply").addEventListener("click", () => {
      applyAjazzLighting({});
    });

    $("toggle-ajazz-fn-toggle").addEventListener("change", (e) => {
      applyAjazzLighting({ fn_toggle: e.target.checked });
    });

    $("toggle-ajazz-block-win").addEventListener("change", (e) => {
      applyAjazzLighting({ block_win: e.target.checked });
    });

    $("toggle-ajazz-block-alttab").addEventListener("change", (e) => {
      applyAjazzLighting({ block_alt_tab: e.target.checked });
    });

    $("toggle-ajazz-block-altf4").addEventListener("change", (e) => {
      applyAjazzLighting({ block_alt_f4: e.target.checked });
    });

    $("ajazz-color-picker").addEventListener("input", (e) => {
      const cur = (state.ajazz && state.ajazz.settings) || {};
      applyAjazzLighting(
        {
          color: e.target.value,
          rainbow: false,
          ...(cur.mode === 0 ? { mode: 1 } : {}),
        },
        180
      );
    });

    $("toggle-ajazz-rainbow").addEventListener("change", (e) => {
      const cur = (state.ajazz && state.ajazz.settings) || {};
      applyAjazzLighting({
        rainbow: e.target.checked,
        ...(cur.mode === 0 ? { mode: 1 } : {}),
      });
    });

    document.querySelectorAll(".ajazz-step-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const field = btn.dataset.field;
        const val = Number(btn.dataset.val);
        applyAjazzLighting({ [field]: val });
      });
    });

    $("btn-ajazz-off").addEventListener("click", () => {
      applyAjazzLighting({ mode: 0 });
    });

    $("btn-ajazz-apply").addEventListener("click", () => {
      applyAjazzLighting({});
    });

    $("mouse-refresh-btn").addEventListener("click", () => {
      fetchAjazzMouseState(true);
    });

    $("btn-mouse-apply").addEventListener("click", () => {
      applyAjazzMouseSettings({});
    });

    document.querySelectorAll(".mouse-count-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        applyAjazzMouseSettings({ stage_count: Number(btn.dataset.count) });
      });
    });

    $("mouse-dpi-slider").addEventListener("input", (e) => {
      const v = Number(e.target.value);
      $("mouse-dpi-input").value = v;
      const s = (state.ajazzMouse && state.ajazzMouse.settings) || {};
      const activeStage = Number(s.active_dpi_stage || 0);
      $("mouse-dpi-badge").textContent = `S${activeStage + 1} · ${v} DPI`;
      updateActiveMouseStage({ dpi: v }, 220);
    });

    $("mouse-dpi-input").addEventListener("input", (e) => {
      const v = Number(e.target.value);
      $("mouse-dpi-slider").value = Math.min(26000, v);
      const s = (state.ajazzMouse && state.ajazzMouse.settings) || {};
      const activeStage = Number(s.active_dpi_stage || 0);
      $("mouse-dpi-badge").textContent = `S${activeStage + 1} · ${v} DPI`;
    });

    $("mouse-dpi-input").addEventListener("change", (e) => {
      updateActiveMouseStage({ dpi: Number(e.target.value) });
    });

    document.querySelectorAll(".mouse-preset-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const v = Number(btn.dataset.dpi);
        $("mouse-dpi-input").value = v;
        $("mouse-dpi-slider").value = Math.min(26000, v);
        const s = (state.ajazzMouse && state.ajazzMouse.settings) || {};
        const activeStage = Number(s.active_dpi_stage || 0);
        $("mouse-dpi-badge").textContent = `S${activeStage + 1} · ${v} DPI`;
        updateActiveMouseStage({ dpi: v });
      });
    });

    $("mouse-stage-color").addEventListener("input", (e) => {
      updateActiveMouseStage({ color: e.target.value }, 200);
    });

    document.querySelectorAll(".mouse-lod-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        applyAjazzMouseSettings({ lod: Number(btn.dataset.lod) });
      });
    });

    $("toggle-mouse-motion-sync").addEventListener("change", (e) => {
      applyAjazzMouseSettings({ motion_sync: e.target.checked });
    });

    $("toggle-mouse-angle-snap").addEventListener("change", (e) => {
      applyAjazzMouseSettings({ angle_snap: e.target.checked });
    });

    $("toggle-mouse-power-save").addEventListener("change", (e) => {
      applyAjazzMouseSettings({ power_save: e.target.checked });
    });

    $("toggle-mouse-charging-led").addEventListener("change", (e) => {
      applyAjazzMouseSettings({ charging_led: e.target.checked });
    });

    $("mouse-debounce-select").addEventListener("change", (e) => {
      applyAjazzMouseSettings({ debounce_ms: Number(e.target.value) });
    });

    $("mouse-sleep-select").addEventListener("change", (e) => {
      const idleSec = Number(e.target.value);
      applyAjazzMouseSettings({ sleep_idle_s: idleSec, sleep_deep_s: Math.max(300, idleSec * 3) });
    });

    $("mouse-batt-high-color").addEventListener("input", (e) => {
      applyAjazzMouseSettings({ battery_led_high: e.target.value }, 200);
    });

    $("mouse-batt-low-color").addEventListener("input", (e) => {
      applyAjazzMouseSettings({ battery_led_low: e.target.value }, 200);
    });

    $("elec-preset-select").addEventListener("change", (e) => {
      const key = e.target.value;
      const preset = (state.electricity?.presets || []).find((p) => p.key === key);
      if (preset && preset.rate_idr !== null && preset.rate_idr !== undefined) {
        $("elec-tariff-input").value = String(preset.rate_idr);
        saveElectricitySettings({ tariff_preset: key });
      } else {
        saveElectricitySettings({
          tariff_preset: key,
          tariff_idr_per_kwh: Number($("elec-tariff-input").value),
        });
      }
    });

    $("btn-elec-save").addEventListener("click", () => {
      saveElectricitySettings();
    });

    $("toggle-autostart").addEventListener("change", async (e) => {
      const input = e.target;
      const enabled = input.checked;
      input.disabled = true;
      try {
        const res = await fetch("/api/autostart", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ enabled }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok !== false) {
          input.checked = Boolean(data.enabled);
          setElecSaveStatus(t("saved"));
          setTimeout(() => setElecSaveStatus(""), 1500);
        } else {
          input.checked = !enabled;
          setElecSaveStatus(data.error || t("save_failed"), true);
        }
      } catch (_) {
        input.checked = !enabled;
        setElecSaveStatus(t("conn_error"), true);
      } finally {
        input.disabled = false;
      }
    });

    document.querySelectorAll(".elec-base-preset").forEach((btn) => {
      btn.addEventListener("click", () => {
        const bw = Number(btn.dataset.base);
        $("elec-base-input").value = String(bw);
        saveElectricitySettings({ base_overhead_w: bw });
      });
    });

    $("btn-elec-csv").addEventListener("click", () => {
      const a = document.createElement("a");
      a.href = "/api/electricity/export.csv";
      a.download = "";
      document.body.appendChild(a);
      a.click();
      a.remove();
    });

    $("btn-elec-reset").addEventListener("click", async () => {
      const btn = $("btn-elec-reset");
      try {
        const res = await fetch("/api/electricity/reset", { method: "POST" });
        if (res.ok) {
          state.electricity = await res.json();
          renderElectricity(state.electricity);
          btn.textContent = t("done");
          setTimeout(() => {
            btn.textContent = t("reset");
          }, 900);
        }
      } catch (_) {}
    });
  }

  initTheme();
  applyLang(state.lang);
  bindControls();
  setupChartHover();
  restartPolling();
  fetchSpecs(false);
  fetchAjazzState(false);
  fetchAjazzMouseState(false);
  setInterval(() => {
    if (!state.paused && state.tab === "ajazz") {
      fetchAjazzState(true);
      fetchAjazzMouseState(true);
    }
  }, 6000);
})();
