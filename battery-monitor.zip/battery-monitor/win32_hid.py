"""Shared Windows SetupAPI/HID helpers and RGB utilities for pure-stdlib drivers."""

from __future__ import annotations

from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import os
import re
from typing import Iterator

_HEX_RE = re.compile(r"^#?([0-9a-fA-F]{6})$")

_INVALID_HANDLE = ctypes.c_void_p(-1).value
_DIGCF_PRESENT = 0x02
_DIGCF_DEVICEINTERFACE = 0x10
_FILE_SHARE_RW = 0x03
_OPEN_EXISTING = 0x03
_GENERIC_RW = 0xC0000000
_FILE_FLAG_OVERLAPPED = 0x40000000


class _OVERLAPPED(ctypes.Structure):
    _fields_ = [
        ("Internal", ctypes.c_void_p),
        ("InternalHigh", ctypes.c_void_p),
        ("Offset", wintypes.DWORD),
        ("OffsetHigh", wintypes.DWORD),
        ("hEvent", wintypes.HANDLE),
    ]


def clamp(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, int(value)))


def parse_hex_color(color: str) -> tuple[int, int, int]:
    """Parse '#RRGGBB' (or 'RRGGBB') into an (R, G, B) tuple."""
    if not isinstance(color, str):
        raise ValueError("Color must be a hex string like #FF0000")
    match = _HEX_RE.match(color.strip())
    if not match:
        raise ValueError(f"Invalid hex color: {color!r}")
    val = int(match.group(1), 16)
    return (val >> 16) & 0xFF, (val >> 8) & 0xFF, val & 0xFF


def format_hex_color(r: int, g: int, b: int) -> str:
    return f"#{clamp(r, 0, 255):02x}{clamp(g, 0, 255):02x}{clamp(b, 0, 255):02x}"


class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", wintypes.DWORD),
        ("Data2", wintypes.WORD),
        ("Data3", wintypes.WORD),
        ("Data4", ctypes.c_ubyte * 8),
    ]


class _SP_DEVICE_INTERFACE_DATA(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("InterfaceClassGuid", _GUID),
        ("Flags", wintypes.DWORD),
        ("Reserved", ctypes.c_void_p),
    ]


class _HIDD_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ("Size", wintypes.ULONG),
        ("VendorID", wintypes.USHORT),
        ("ProductID", wintypes.USHORT),
        ("VersionNumber", wintypes.USHORT),
    ]


class _HIDP_CAPS(ctypes.Structure):
    _fields_ = [
        ("Usage", wintypes.USHORT),
        ("UsagePage", wintypes.USHORT),
        ("InputReportByteLength", wintypes.USHORT),
        ("OutputReportByteLength", wintypes.USHORT),
        ("FeatureReportByteLength", wintypes.USHORT),
        ("Reserved", wintypes.USHORT * 17),
        ("NumberLinkCollectionNodes", wintypes.USHORT),
        ("NumberInputButtonCaps", wintypes.USHORT),
        ("NumberInputValueCaps", wintypes.USHORT),
        ("NumberInputDataIndices", wintypes.USHORT),
        ("NumberOutputButtonCaps", wintypes.USHORT),
        ("NumberOutputValueCaps", wintypes.USHORT),
        ("NumberOutputDataIndices", wintypes.USHORT),
        ("NumberFeatureButtonCaps", wintypes.USHORT),
        ("NumberFeatureValueCaps", wintypes.USHORT),
        ("NumberFeatureDataIndices", wintypes.USHORT),
    ]


def load_win32_hid():
    """Load Win32 SetupAPI, HID, and Kernel32 DLL bindings."""
    setupapi = ctypes.WinDLL("setupapi.dll", use_last_error=True)
    hid = ctypes.WinDLL("hid.dll", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32.dll", use_last_error=True)

    setupapi.SetupDiGetClassDevsW.restype = wintypes.HANDLE
    setupapi.SetupDiGetClassDevsW.argtypes = [
        ctypes.c_void_p, wintypes.LPCWSTR, wintypes.HWND, wintypes.DWORD,
    ]
    setupapi.SetupDiEnumDeviceInterfaces.restype = wintypes.BOOL
    setupapi.SetupDiEnumDeviceInterfaces.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p,
    ]
    setupapi.SetupDiGetDeviceInterfaceDetailW.restype = wintypes.BOOL
    setupapi.SetupDiGetDeviceInterfaceDetailW.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p,
    ]
    setupapi.SetupDiDestroyDeviceInfoList.restype = wintypes.BOOL
    setupapi.SetupDiDestroyDeviceInfoList.argtypes = [wintypes.HANDLE]

    kernel32.CreateFileW.restype = wintypes.HANDLE
    kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
        wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE,
    ]
    kernel32.WriteFile.restype = wintypes.BOOL
    kernel32.WriteFile.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p,
    ]
    kernel32.ReadFile.restype = wintypes.BOOL
    kernel32.ReadFile.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD), ctypes.c_void_p,
    ]
    kernel32.CreateEventW.restype = wintypes.HANDLE
    kernel32.CreateEventW.argtypes = [
        ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR,
    ]
    kernel32.ResetEvent.restype = wintypes.BOOL
    kernel32.ResetEvent.argtypes = [wintypes.HANDLE]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.CancelIoEx.restype = wintypes.BOOL
    kernel32.CancelIoEx.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    kernel32.GetOverlappedResult.restype = wintypes.BOOL
    kernel32.GetOverlappedResult.argtypes = [
        wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(wintypes.DWORD), wintypes.BOOL,
    ]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

    hid.HidD_GetHidGuid.argtypes = [ctypes.c_void_p]
    hid.HidD_GetAttributes.restype = wintypes.BOOL
    hid.HidD_GetAttributes.argtypes = [wintypes.HANDLE, ctypes.c_void_p]
    hid.HidD_GetPreparsedData.restype = wintypes.BOOL
    hid.HidD_GetPreparsedData.argtypes = [wintypes.HANDLE, ctypes.POINTER(ctypes.c_void_p)]
    hid.HidD_FreePreparsedData.restype = wintypes.BOOL
    hid.HidD_FreePreparsedData.argtypes = [ctypes.c_void_p]
    hid.HidP_GetCaps.restype = wintypes.LONG
    hid.HidP_GetCaps.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    hid.HidD_SetFeature.restype = wintypes.BOOL
    hid.HidD_SetFeature.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.ULONG]
    hid.HidD_GetFeature.restype = wintypes.BOOL
    hid.HidD_GetFeature.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.ULONG]

    return setupapi, hid, kernel32


def enumerate_hid_interfaces(vid_filter: int | None = None) -> list[dict]:
    """Return present Windows HID interfaces, optionally filtered by Vendor ID."""
    if os.name != "nt":
        return []
    setupapi, hid, kernel32 = load_win32_hid()
    hid_guid = _GUID()
    hid.HidD_GetHidGuid(ctypes.byref(hid_guid))
    dev_info = setupapi.SetupDiGetClassDevsW(
        ctypes.byref(hid_guid), None, None, _DIGCF_PRESENT | _DIGCF_DEVICEINTERFACE
    )
    if not dev_info or dev_info == _INVALID_HANDLE:
        return []

    vid_needle = f"vid_{vid_filter:04x}" if vid_filter is not None else None
    found: list[dict] = []
    iface_data = _SP_DEVICE_INTERFACE_DATA()
    iface_data.cbSize = ctypes.sizeof(_SP_DEVICE_INTERFACE_DATA)
    detail_cb_size = 8 if ctypes.sizeof(ctypes.c_void_p) == 8 else 6
    idx = 0
    try:
        while setupapi.SetupDiEnumDeviceInterfaces(
            dev_info, None, ctypes.byref(hid_guid), idx, ctypes.byref(iface_data)
        ):
            idx += 1
            req = wintypes.DWORD(0)
            setupapi.SetupDiGetDeviceInterfaceDetailW(
                dev_info, ctypes.byref(iface_data), None, 0, ctypes.byref(req), None
            )
            if not req.value:
                continue
            buf = ctypes.create_string_buffer(req.value)
            ctypes.cast(buf, ctypes.POINTER(wintypes.DWORD))[0] = detail_cb_size
            if not setupapi.SetupDiGetDeviceInterfaceDetailW(
                dev_info, ctypes.byref(iface_data), buf, req.value, None, None
            ):
                continue
            path = ctypes.wstring_at(ctypes.addressof(buf) + 4)
            if vid_needle and vid_needle not in path.lower():
                continue

            handle = kernel32.CreateFileW(path, 0, _FILE_SHARE_RW, None, _OPEN_EXISTING, 0, None)
            if not handle or handle == _INVALID_HANDLE:
                continue
            try:
                attr = _HIDD_ATTRIBUTES()
                attr.Size = ctypes.sizeof(_HIDD_ATTRIBUTES)
                if not hid.HidD_GetAttributes(handle, ctypes.byref(attr)):
                    continue
                if vid_filter is not None and int(attr.VendorID) != vid_filter:
                    continue
                pp = ctypes.c_void_p()
                caps = _HIDP_CAPS()
                if hid.HidD_GetPreparsedData(handle, ctypes.byref(pp)):
                    try:
                        hid.HidP_GetCaps(pp, ctypes.byref(caps))
                    finally:
                        hid.HidD_FreePreparsedData(pp)
                found.append(
                    {
                        "path": path,
                        "vid": int(attr.VendorID),
                        "pid": int(attr.ProductID),
                        "usage_page": int(caps.UsagePage),
                        "usage": int(caps.Usage),
                        "in_len": int(caps.InputReportByteLength),
                        "out_len": int(caps.OutputReportByteLength),
                        "feat_len": int(caps.FeatureReportByteLength),
                    }
                )
            finally:
                kernel32.CloseHandle(handle)
    finally:
        setupapi.SetupDiDestroyDeviceInfoList(dev_info)
    return found


@contextmanager
def open_hid_handle(path: str, label: str = "HID") -> Iterator[tuple]:
    """Open a read/write HID handle and yield `(handle, hid, kernel32)`."""
    _, hid, kernel32 = load_win32_hid()
    handle = kernel32.CreateFileW(path, _GENERIC_RW, _FILE_SHARE_RW, None, _OPEN_EXISTING, 0, None)
    if not handle or handle == _INVALID_HANDLE:
        err = ctypes.get_last_error()
        raise OSError(f"Failed to open {label} interface (Win32 error {err})")
    try:
        yield handle, hid, kernel32
    finally:
        kernel32.CloseHandle(handle)


def set_feature_report(handle: int, hid, payload: bytes, context: str = "HID") -> None:
    raw = (ctypes.c_ubyte * len(payload))(*payload)
    if not hid.HidD_SetFeature(handle, raw, len(payload)):
        err = ctypes.get_last_error()
        raise OSError(f"{context} HidD_SetFeature failed (Win32 error {err})")


def get_feature_report(handle: int, hid, report_id: int, size: int = 65, context: str = "HID") -> bytes:
    buf = (ctypes.c_ubyte * size)()
    buf[0] = report_id & 0xFF
    if not hid.HidD_GetFeature(handle, buf, size):
        err = ctypes.get_last_error()
        raise OSError(f"{context} HidD_GetFeature failed (Win32 error {err})")
    return bytes(buf)


def write_output_report(handle: int, kernel32, payload: bytes, context: str = "HID") -> None:
    raw = (ctypes.c_ubyte * len(payload))(*payload)
    written = wintypes.DWORD(0)
    if not kernel32.WriteFile(handle, raw, len(payload), ctypes.byref(written), None):
        err = ctypes.get_last_error()
        raise OSError(f"{context} WriteFile failed (Win32 error {err})")


def write_and_read_report(
    path: str,
    tx_payload: bytes,
    read_size: int = 33,
    timeout_ms: int = 200,
) -> bytes | None:
    """Write a HID output report and asynchronously await one input reply up to `timeout_ms`."""
    if os.name != "nt":
        return None
    _, _, kernel32 = load_win32_hid()
    handle = kernel32.CreateFileW(
        path, _GENERIC_RW, _FILE_SHARE_RW, None, _OPEN_EXISTING, _FILE_FLAG_OVERLAPPED, None
    )
    if not handle or handle == _INVALID_HANDLE:
        return None
    ev_r = kernel32.CreateEventW(None, True, False, None)
    ev_w = kernel32.CreateEventW(None, True, False, None)
    try:
        ov_r = _OVERLAPPED()
        ov_r.hEvent = ev_r
        rbuf = (ctypes.c_ubyte * read_size)()
        rbytes = wintypes.DWORD(0)
        kernel32.ReadFile(handle, rbuf, read_size, ctypes.byref(rbytes), ctypes.byref(ov_r))

        ov_w = _OVERLAPPED()
        ov_w.hEvent = ev_w
        wbuf = (ctypes.c_ubyte * len(tx_payload))(*tx_payload)
        wbytes = wintypes.DWORD(0)
        kernel32.WriteFile(handle, wbuf, len(tx_payload), ctypes.byref(wbytes), ctypes.byref(ov_w))
        kernel32.GetOverlappedResult(handle, ctypes.byref(ov_w), ctypes.byref(wbytes), True)

        if kernel32.WaitForSingleObject(ev_r, timeout_ms) == 0:
            kernel32.GetOverlappedResult(handle, ctypes.byref(ov_r), ctypes.byref(rbytes), False)
            return bytes(rbuf[: rbytes.value or read_size])
        kernel32.CancelIoEx(handle, ctypes.byref(ov_r))
        return None
    finally:
        if ev_w:
            kernel32.CloseHandle(ev_w)
        if ev_r:
            kernel32.CloseHandle(ev_r)
        kernel32.CloseHandle(handle)


def write_and_read_sequence(
    path: str,
    tx_payloads: list[bytes],
    read_size: int = 65,
    timeout_ms: int = 3000,
    context: str = "HID",
) -> list[bytes]:
    """Write sequential output reports on one overlapped handle, awaiting an input ACK per write."""
    if os.name != "nt":
        raise OSError("Win32 HID is only available on Windows")
    _, _, kernel32 = load_win32_hid()
    handle = kernel32.CreateFileW(
        path, _GENERIC_RW, _FILE_SHARE_RW, None, _OPEN_EXISTING, _FILE_FLAG_OVERLAPPED, None
    )
    if not handle or handle == _INVALID_HANDLE:
        err = ctypes.get_last_error()
        raise OSError(f"Failed to open {context} interface (Win32 error {err})")
    ev_r = kernel32.CreateEventW(None, True, False, None)
    ev_w = kernel32.CreateEventW(None, True, False, None)
    acks: list[bytes] = []
    try:
        for idx, tx_payload in enumerate(tx_payloads):
            kernel32.ResetEvent(ev_r)
            kernel32.ResetEvent(ev_w)
            ov_r = _OVERLAPPED()
            ov_r.hEvent = ev_r
            rbuf = (ctypes.c_ubyte * read_size)()
            rbytes = wintypes.DWORD(0)
            kernel32.ReadFile(handle, rbuf, read_size, ctypes.byref(rbytes), ctypes.byref(ov_r))

            ov_w = _OVERLAPPED()
            ov_w.hEvent = ev_w
            wbuf = (ctypes.c_ubyte * len(tx_payload))(*tx_payload)
            wbytes = wintypes.DWORD(0)
            if not kernel32.WriteFile(handle, wbuf, len(tx_payload), ctypes.byref(wbytes), ctypes.byref(ov_w)):
                err = ctypes.get_last_error()
                if err != 997:
                    kernel32.CancelIoEx(handle, ctypes.byref(ov_r))
                    raise OSError(f"{context} block {idx + 1} WriteFile failed (Win32 error {err})")
            kernel32.GetOverlappedResult(handle, ctypes.byref(ov_w), ctypes.byref(wbytes), True)

            if kernel32.WaitForSingleObject(ev_r, timeout_ms) != 0:
                kernel32.CancelIoEx(handle, ctypes.byref(ov_r))
                raise TimeoutError(
                    f"{context} timed out waiting for acknowledgement on block {idx + 1}/{len(tx_payloads)}"
                )
            kernel32.GetOverlappedResult(handle, ctypes.byref(ov_r), ctypes.byref(rbytes), False)
            acks.append(bytes(rbuf[: rbytes.value or read_size]))
        return acks
    finally:
        if ev_w:
            kernel32.CloseHandle(ev_w)
        if ev_r:
            kernel32.CloseHandle(ev_r)
        kernel32.CloseHandle(handle)
