# Battery & Power Monitor

Aplikasi monitoring baterai dan daya Windows secara real-time bergaya Google / Stock Android menggunakan Win32 API native tanpa dependensi eksternal.

## Cara Menjalankan

1. **Mode Jendela Aplikasi (Rekomendasi):**
   ```powershell
   python server.py
   ```
   Atau klik dua kali `launch.bat`. Aplikasi akan terbuka di jendela terpisah (Microsoft Edge app mode) dan otomatis berhenti saat jendela ditutup.

2. **Mode Browser Biasa:**
   ```powershell
   python server.py --browser
   ```

3. **Custom Port / Tanpa Membuka Jendela:**
   ```powershell
   python server.py --port 18765 --no-open
   ```

## Fitur Utama
* **Overview:** Persentase, status daya & estimasi waktu penuh/sisa, pengalih **Performance Mode** (`Quiet`, `Balanced`, `Performance`), **Charge Guard 80%** (peringatan & banner dengan suara opsional), tile **Voltage (V/mV)**, **Current (A)**, **Battery Power (W/mW)**, **C-Rate & %/hr**, pelacakan **Power by state** (`Charge`, `Idle`, `Discharge` dengan durasi, energi `Wh`, `Avg`, dan `Peak`), serta grafik real-time (`Voltage`, `Current`, `Power`, `GPU Power`).
* **Power:** Info **Windows Power Plan & Power Mode**, **CPU load & clock** (`GetSystemTimes` + `CallNtPowerInformation`), **NVIDIA GPU power draw/limit, suhu, load, clock & P-state** (`nvidia-smi` dengan toggle on/off), akumulasi energi sesi (`Wh`), dan kalkulasi estimasi pengisian/pemakaian.
* **Health:** Kesehatan baterai & kapasitas terpakai (`wear`), cycle count, serial & hardware, interval refresh (`1s`/`2s`/`5s`), serta **Power events log** yang tersimpan di `%LOCALAPPDATA%\BatteryMonitor\state_stats.json` dan ekspor CSV (`/api/export.csv`).
* **Specs:** Ringkasan spesifikasi laptop lengkap (`/api/specs`) meliputi **System & OS** (model, motherboard, versi BIOS, Windows build, uptime), **Processor** (model, core/thread, clock dasar, L2/L3 cache), **Memory (RAM)** (kapasitas terpasang/usable, speed, modul tiap slot DIMM), **Graphics & displays**, **Storage** (partisi/volume + physical disk), serta **Network adapters**, lengkap dengan tombol **Copy** dan **Refresh**.
* **AJAZZ (AK820 Pro & AJ159 Pro):** Ringkasan status kedua perangkat dalam kartu berdampingan (baterai, link, RGB/LCD, DPI/Polling Rate) serta kontrol terpisah yang ringkas:
  * **AK820 Pro Keyboard:** Pembacaan baterai nirkabel `2.4G`, informasi & pratinjau **TFT LCD Screen** (`0.85"` `128×128` RGB565) beserta **Sync Clock** (`2.4G` & `USB-C`) dan **Upload Image** via **USB-C** (`FF68`), kontrol warna & 20 mode RGB (`6` preset cepat + dropdown lengkap), `Rainbow`, `Brightness`/`Speed`/`Direction`, serta **Auto-Sleep** (`Never` / `1m` / `5m` / `30m`).
  * **AJ159 Pro Mouse:** Pembacaan baterai nirkabel real-time via dongle **2.4G 8K** (`3151:402D`), pengaturan **Polling Rate** (`125–8000 Hz`), **DPI Stages** (`1–8` stage + warna indikator tiap stage), **LOD** (`1/2/3 mm`), **Motion Sync**, **Angle Snapping**, **Power Save**, debounce time, sleep timer, dan warna **Battery LED**.
