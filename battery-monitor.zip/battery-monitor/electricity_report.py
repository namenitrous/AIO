"""Per-boot PC electricity consumption tracker and PLN Rupiah cost estimator."""

from __future__ import annotations

import csv
from datetime import datetime, timedelta
import io
import json
from pathlib import Path
import time

PLN_TARIFF_PRESETS = [
    {"key": "r1_450", "label": "R-1/TR 450 VA (Subsidi)", "rate_idr": 415.0},
    {"key": "r1_900_sub", "label": "R-1/TR 900 VA (Subsidi)", "rate_idr": 605.0},
    {"key": "r1_900", "label": "R-1/TR 900 VA (RTM)", "rate_idr": 1352.0},
    {"key": "r1_1300", "label": "R-1/TR 1.300 VA", "rate_idr": 1444.70},
    {"key": "r1_2200", "label": "R-1/TR 2.200 VA", "rate_idr": 1444.70},
    {"key": "r2_3500", "label": "R-2/TR 3.500-5.500 VA", "rate_idr": 1699.53},
    {"key": "r3_6600", "label": "R-3/TR 6.600+ VA", "rate_idr": 1699.53},
    {"key": "b2_b3", "label": "B-2/B-3 Bisnis", "rate_idr": 1444.70},
    {"key": "custom", "label": "Custom Tarif", "rate_idr": None},
]

_PRESET_MAP = {item["key"]: item["rate_idr"] for item in PLN_TARIFF_PRESETS}

DEFAULT_SETTINGS = {
    "tariff_preset": "r1_1300",
    "tariff_idr_per_kwh": 1444.70,
    "base_overhead_w": 12.0,
    "adapter_efficiency_pct": 88.0,
}

MAX_STORED_SESSIONS = 180


def default_report_path(stats_path: Path | None = None) -> Path | None:
    if stats_path is None:
        return None
    return Path(stats_path).parent / "electricity_report.json"


def validate_electricity_settings(payload: dict, current: dict | None = None) -> dict:
    """Validate and merge tariff and calibration settings."""
    merged = dict(DEFAULT_SETTINGS)
    if current:
        merged.update(current)

    if "tariff_preset" in payload:
        preset = str(payload["tariff_preset"]).strip()
        if preset not in _PRESET_MAP:
            raise ValueError(f"Unsupported tariff preset: {preset}")
        merged["tariff_preset"] = preset
        preset_rate = _PRESET_MAP[preset]
        if preset_rate is not None and "tariff_idr_per_kwh" not in payload:
            merged["tariff_idr_per_kwh"] = float(preset_rate)

    if "tariff_idr_per_kwh" in payload:
        try:
            rate = float(payload["tariff_idr_per_kwh"])
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid tariff_idr_per_kwh value") from exc
        if rate < 0 or rate > 50000:
            raise ValueError("Tariff must be between 0 and 50000 Rp/kWh")
        merged["tariff_idr_per_kwh"] = round(rate, 2)
        if "tariff_preset" not in payload:
            preset_rate = _PRESET_MAP.get(merged["tariff_preset"])
            if preset_rate is not None and abs(preset_rate - merged["tariff_idr_per_kwh"]) > 0.05:
                merged["tariff_preset"] = "custom"

    if "base_overhead_w" in payload:
        try:
            base_w = float(payload["base_overhead_w"])
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid base_overhead_w value") from exc
        if base_w < 0 or base_w > 150:
            raise ValueError("Base overhead must be between 0 and 150 W")
        merged["base_overhead_w"] = round(base_w, 1)

    if "adapter_efficiency_pct" in payload:
        try:
            eff = float(payload["adapter_efficiency_pct"])
        except (TypeError, ValueError) as exc:
            raise ValueError("Invalid adapter_efficiency_pct value") from exc
        if eff < 50 or eff > 100:
            raise ValueError("Adapter efficiency must be between 50% and 100%")
        merged["adapter_efficiency_pct"] = round(eff, 1)

    return merged


def compute_live_power_breakdown(snapshot: dict, settings: dict) -> dict:
    """Estimate live system DC load, AC wall draw (PLN), and hourly Rupiah burn rate."""
    cpu = snapshot.get("cpu") or {}
    gpu = snapshot.get("gpu") or {}

    cpu_raw = cpu.get("cpu_power_w")
    cpu_measured = cpu_raw is not None and float(cpu_raw) >= 0.0
    if cpu_measured:
        cpu_w = float(cpu_raw)
    else:
        cpu_pct = float(cpu.get("cpu_percent") or 0.0)
        cpu_w = 6.0 + 0.35 * max(0.0, min(100.0, cpu_pct))

    gpu_raw = gpu.get("power_w")
    gpu_measured = gpu_raw is not None and float(gpu_raw) >= 0.0
    gpu_w = max(0.0, float(gpu_raw)) if gpu_measured else 0.0

    base_w = float(settings.get("base_overhead_w", DEFAULT_SETTINGS["base_overhead_w"]))
    eff_pct = float(settings.get("adapter_efficiency_pct", DEFAULT_SETTINGS["adapter_efficiency_pct"]))
    eff = max(0.5, min(1.0, eff_pct / 100.0))
    tariff = float(settings.get("tariff_idr_per_kwh", DEFAULT_SETTINGS["tariff_idr_per_kwh"]))

    battery_present = bool(snapshot.get("battery_present", True))
    ac_online = bool(snapshot.get("ac_online", True)) if battery_present else True
    rate_mw = snapshot.get("rate_mw")

    charge_w = 0.0
    discharge_w = 0.0
    if rate_mw is not None:
        if ac_online and rate_mw > 0:
            charge_w = float(rate_mw) / 1000.0
        elif not ac_online and rate_mw < 0:
            discharge_w = abs(float(rate_mw)) / 1000.0

    if not ac_online and discharge_w > 0.1:
        system_w = discharge_w
        source = "battery_sensor"
    else:
        system_w = cpu_w + gpu_w + base_w
        source = "sensor" if cpu_measured else "estimated"

    wall_w = ((system_w + charge_w) / eff) if ac_online else 0.0
    adapter_loss_w = max(0.0, wall_w - (system_w + charge_w)) if ac_online else 0.0
    equiv_wall_w = system_w / eff
    hourly_cost_idr = (wall_w / 1000.0) * tariff
    equiv_hourly_cost_idr = (equiv_wall_w / 1000.0) * tariff

    return {
        "ac_online": ac_online,
        "source": source,
        "cpu_w": round(cpu_w, 2),
        "cpu_measured": cpu_measured,
        "gpu_w": round(gpu_w, 2),
        "gpu_measured": gpu_measured,
        "base_w": round(base_w, 1),
        "charge_w": round(charge_w, 2),
        "discharge_w": round(discharge_w, 2),
        "adapter_loss_w": round(adapter_loss_w, 2),
        "system_w": round(system_w, 2),
        "wall_w": round(wall_w, 2),
        "equiv_wall_w": round(equiv_wall_w, 2),
        "hourly_cost_idr": round(hourly_cost_idr, 2),
        "equiv_hourly_cost_idr": round(equiv_hourly_cost_idr, 2),
    }


def _date_month_from_ts(ts: float) -> tuple[str, str]:
    dt = datetime.fromtimestamp(ts)
    return dt.strftime("%Y-%m-%d"), dt.strftime("%Y-%m")


class ElectricityReportTracker:
    """Tracks per-boot PC energy consumption and estimates PLN electricity costs in IDR."""

    def __init__(self, report_path: Path | None = None) -> None:
        self._path = report_path
        self._settings = dict(DEFAULT_SETTINGS)
        self._sessions: list[dict] = []
        self._last_sample_ts: float | None = None
        self._last_saved = 0.0
        self._latest_live: dict | None = None
        self._last_snapshot: dict | None = None
        self._load()

    def _load(self) -> None:
        if not self._path or not self._path.is_file():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            if isinstance(raw.get("settings"), dict):
                self._settings = validate_electricity_settings(raw["settings"], DEFAULT_SETTINGS)
            loaded_sessions = raw.get("sessions", [])
            if isinstance(loaded_sessions, list):
                valid = []
                for item in loaded_sessions:
                    if isinstance(item, dict) and "id" in item and "boot_at" in item:
                        valid.append(self._normalize_session(item))
                self._sessions = valid[-MAX_STORED_SESSIONS:]
        except Exception:
            pass

    @staticmethod
    def _normalize_session(item: dict) -> dict:
        boot_at = float(item.get("boot_at") or time.time())
        date_str, month_str = _date_month_from_ts(boot_at)
        return {
            "id": str(item["id"]),
            "boot_at": round(boot_at, 1),
            "first_monitored_at": round(float(item.get("first_monitored_at") or boot_at), 1),
            "last_seen": round(float(item.get("last_seen") or boot_at), 1),
            "date": str(item.get("date") or date_str),
            "month": str(item.get("month") or month_str),
            "uptime_sec": int(item.get("uptime_sec") or 0),
            "monitored_sec": float(item.get("monitored_sec") or 0.0),
            "ac_sec": float(item.get("ac_sec") or 0.0),
            "battery_sec": float(item.get("battery_sec") or 0.0),
            "wall_energy_wh": float(item.get("wall_energy_wh") or 0.0),
            "system_energy_wh": float(item.get("system_energy_wh") or 0.0),
            "charge_energy_wh": float(item.get("charge_energy_wh") or 0.0),
            "battery_energy_wh": float(item.get("battery_energy_wh") or 0.0),
            "peak_wall_w": float(item.get("peak_wall_w") or 0.0),
            "peak_system_w": float(item.get("peak_system_w") or 0.0),
            "samples": int(item.get("samples") or 0),
        }

    def save(self, force: bool = False) -> None:
        if not self._path:
            return
        now = time.time()
        if not force and now - self._last_saved < 15.0:
            return
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "settings": self._settings,
                "sessions": self._sessions[-MAX_STORED_SESSIONS:],
            }
            tmp_path = self._path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(payload), encoding="utf-8")
            tmp_path.replace(self._path)
            self._last_saved = now
        except Exception:
            pass

    def _find_or_create_session(self, now: float, uptime_seconds: int) -> dict:
        uptime_i = max(0, int(uptime_seconds or 0))
        boot_at = now - uptime_i if uptime_i > 0 else now

        if self._sessions:
            latest = self._sessions[-1]
            same_boot = (
                abs(latest["boot_at"] - boot_at) <= 120.0
                and uptime_i + 30 >= latest.get("uptime_sec", 0)
            )
            if uptime_i == 0 and (now - latest["last_seen"]) <= 300.0:
                same_boot = True
            if same_boot:
                return latest

        date_str, month_str = _date_month_from_ts(boot_at)
        session = {
            "id": f"boot_{int(round(boot_at))}",
            "boot_at": round(boot_at, 1),
            "first_monitored_at": round(now, 1),
            "last_seen": round(now, 1),
            "date": date_str,
            "month": month_str,
            "uptime_sec": uptime_i,
            "monitored_sec": 0.0,
            "ac_sec": 0.0,
            "battery_sec": 0.0,
            "wall_energy_wh": 0.0,
            "system_energy_wh": 0.0,
            "charge_energy_wh": 0.0,
            "battery_energy_wh": 0.0,
            "peak_wall_w": 0.0,
            "peak_system_w": 0.0,
            "samples": 0,
        }
        self._sessions.append(session)
        if len(self._sessions) > MAX_STORED_SESSIONS:
            self._sessions = self._sessions[-MAX_STORED_SESSIONS:]
        self._last_sample_ts = None
        return session

    def record(self, snapshot: dict, uptime_seconds: int = 0) -> dict:
        now = float(snapshot.get("timestamp") or time.time())
        if self._last_sample_ts is not None:
            dt = max(0.0, min(5.0, now - self._last_sample_ts))
        else:
            dt = 1.0

        session = self._find_or_create_session(now, uptime_seconds)
        self._last_sample_ts = now

        live = compute_live_power_breakdown(snapshot, self._settings)
        session["samples"] += 1
        session["last_seen"] = round(now, 1)
        if uptime_seconds > 0:
            session["uptime_sec"] = max(session["uptime_sec"], int(uptime_seconds))
        session["monitored_sec"] += dt

        if live["ac_online"]:
            session["ac_sec"] += dt
        else:
            session["battery_sec"] += dt
            session["battery_energy_wh"] += (live["system_w"] * dt) / 3600.0

        session["wall_energy_wh"] += (live["wall_w"] * dt) / 3600.0
        session["system_energy_wh"] += (live["system_w"] * dt) / 3600.0
        session["charge_energy_wh"] += (live["charge_w"] * dt) / 3600.0
        session["peak_wall_w"] = max(session["peak_wall_w"], live["wall_w"])
        session["peak_system_w"] = max(session["peak_system_w"], live["system_w"])

        self._last_snapshot = snapshot
        self._latest_live = live
        self.save(force=False)
        return live

    def _format_session(self, s: dict, is_current: bool = False) -> dict:
        tariff = float(self._settings["tariff_idr_per_kwh"])
        eff = max(0.5, float(self._settings["adapter_efficiency_pct"]) / 100.0)
        wall_kwh = s["wall_energy_wh"] / 1000.0
        sys_kwh = s["system_energy_wh"] / 1000.0
        bat_kwh = s["battery_energy_wh"] / 1000.0

        cost_idr = wall_kwh * tariff
        equiv_bat_cost_idr = (bat_kwh / eff) * tariff

        monitored_sec = float(s["monitored_sec"])
        ac_sec = float(s["ac_sec"])
        avg_wall_w = (s["wall_energy_wh"] * 3600.0 / ac_sec) if ac_sec > 0.5 else 0.0
        avg_sys_w = (s["system_energy_wh"] * 3600.0 / monitored_sec) if monitored_sec > 0.5 else 0.0

        uptime_sec = int(s["uptime_sec"])
        if uptime_sec <= 0:
            uptime_sec = int(round(monitored_sec))

        coverage_pct = (
            min(100.0, round((monitored_sec / uptime_sec) * 100.0, 1))
            if uptime_sec > 0
            else 100.0
        )
        est_full_kwh: float | None = None
        est_full_cost_idr: float | None = None
        if monitored_sec >= 10.0 and uptime_sec > monitored_sec and coverage_pct < 98.0 and wall_kwh > 0:
            est_full_kwh = round(wall_kwh * (uptime_sec / monitored_sec), 4)
            est_full_cost_idr = round(est_full_kwh * tariff, 2)

        return {
            "id": s["id"],
            "is_current": is_current,
            "boot_at": s["boot_at"],
            "first_monitored_at": s["first_monitored_at"],
            "last_seen": s["last_seen"],
            "date": s["date"],
            "month": s["month"],
            "uptime_sec": uptime_sec,
            "monitored_sec": round(monitored_sec, 1),
            "ac_sec": round(ac_sec, 1),
            "battery_sec": round(s["battery_sec"], 1),
            "coverage_pct": coverage_pct,
            "wall_energy_wh": round(s["wall_energy_wh"], 2),
            "wall_kwh": round(wall_kwh, 4),
            "system_energy_wh": round(s["system_energy_wh"], 2),
            "system_kwh": round(sys_kwh, 4),
            "battery_kwh": round(bat_kwh, 4),
            "avg_wall_w": round(avg_wall_w, 1),
            "avg_system_w": round(avg_sys_w, 1),
            "peak_wall_w": round(s["peak_wall_w"], 1),
            "peak_system_w": round(s["peak_system_w"], 1),
            "cost_idr": round(cost_idr, 2),
            "equiv_battery_cost_idr": round(equiv_bat_cost_idr, 2),
            "est_full_kwh": est_full_kwh,
            "est_full_cost_idr": est_full_cost_idr,
            "samples": s["samples"],
        }

    def _aggregate_bucket(self, items: list[dict]) -> dict:
        tariff = float(self._settings["tariff_idr_per_kwh"])
        eff = max(0.5, float(self._settings["adapter_efficiency_pct"]) / 100.0)
        wall_wh = sum(x["wall_energy_wh"] for x in items)
        sys_wh = sum(x["system_energy_wh"] for x in items)
        bat_wh = sum(x["battery_energy_wh"] for x in items)
        monitored_sec = sum(x["monitored_sec"] for x in items)
        uptime_sec = sum(max(x["uptime_sec"], int(round(x["monitored_sec"]))) for x in items)
        wall_kwh = wall_wh / 1000.0
        cost_idr = wall_kwh * tariff
        equiv_bat_cost_idr = ((bat_wh / 1000.0) / eff) * tariff
        return {
            "session_count": len(items),
            "uptime_sec": uptime_sec,
            "monitored_sec": round(monitored_sec, 1),
            "wall_kwh": round(wall_kwh, 4),
            "system_kwh": round(sys_wh / 1000.0, 4),
            "cost_idr": round(cost_idr, 2),
            "equiv_battery_cost_idr": round(equiv_bat_cost_idr, 2),
        }

    def update_settings(self, payload: dict) -> dict:
        self._settings = validate_electricity_settings(payload, self._settings)
        if self._last_snapshot is not None:
            self._latest_live = compute_live_power_breakdown(self._last_snapshot, self._settings)
        self.save(force=True)
        return self.summary()

    def reset_history(self) -> dict:
        self._sessions.clear()
        self._last_sample_ts = None
        self.save(force=True)
        return self.summary()

    def summary(self, now: float | None = None) -> dict:
        ref_now = now if now is not None else time.time()
        ref_dt = datetime.fromtimestamp(ref_now)
        today_str = ref_dt.strftime("%Y-%m-%d")
        month_str = ref_dt.strftime("%Y-%m")

        formatted_desc: list[dict] = []
        total_len = len(self._sessions)
        for idx in range(total_len - 1, -1, -1):
            is_cur = idx == (total_len - 1)
            formatted_desc.append(self._format_session(self._sessions[idx], is_current=is_cur))

        current_session = formatted_desc[0] if formatted_desc else None
        today_items = [s for s in self._sessions if s["date"] == today_str]
        month_items = [s for s in self._sessions if s["month"] == month_str]
        all_bucket = self._aggregate_bucket(self._sessions)

        by_date: dict[str, list[dict]] = {}
        for s in self._sessions:
            by_date.setdefault(s["date"], []).append(s)

        daily_7d: list[dict] = []
        for offset in range(6, -1, -1):
            day_dt = ref_dt - timedelta(days=offset)
            d_key = day_dt.strftime("%Y-%m-%d")
            bucket = self._aggregate_bucket(by_date.get(d_key, []))
            daily_7d.append(
                {
                    "date": d_key,
                    "day_short": day_dt.strftime("%d/%m"),
                    "session_count": bucket["session_count"],
                    "wall_kwh": bucket["wall_kwh"],
                    "cost_idr": bucket["cost_idr"],
                    "uptime_sec": bucket["uptime_sec"],
                }
            )

        active_days = max(1, len(by_date)) if self._sessions else 0
        avg_daily_kwh = (all_bucket["wall_kwh"] / active_days) if active_days > 0 else 0.0
        avg_daily_cost = (all_bucket["cost_idr"] / active_days) if active_days > 0 else 0.0
        projection_30d = {
            "active_days": active_days,
            "avg_daily_kwh": round(avg_daily_kwh, 4),
            "avg_daily_cost_idr": round(avg_daily_cost, 2),
            "est_30d_kwh": round(avg_daily_kwh * 30.0, 3),
            "est_30d_cost_idr": round(avg_daily_cost * 30.0, 2),
        }

        return {
            "settings": dict(self._settings),
            "presets": PLN_TARIFF_PRESETS,
            "live": self._latest_live,
            "current_session": current_session,
            "today": self._aggregate_bucket(today_items),
            "this_month": self._aggregate_bucket(month_items),
            "all_time": all_bucket,
            "projection_30d": projection_30d,
            "daily_7d": daily_7d,
            "sessions": formatted_desc,
        }

    def export_csv(self) -> str:
        rep = self.summary()
        tariff = rep["settings"]["tariff_idr_per_kwh"]
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(
            [
                "session_id",
                "boot_time",
                "last_seen",
                "uptime_sec",
                "monitored_sec",
                "avg_wall_w",
                "peak_wall_w",
                "wall_kwh",
                "system_kwh",
                "cost_idr",
                "equiv_battery_cost_idr",
                "tariff_idr_per_kwh",
            ]
        )
        for s in rep["sessions"]:
            boot_iso = datetime.fromtimestamp(s["boot_at"]).isoformat(timespec="seconds")
            last_iso = datetime.fromtimestamp(s["last_seen"]).isoformat(timespec="seconds")
            writer.writerow(
                [
                    s["id"],
                    boot_iso,
                    last_iso,
                    s["uptime_sec"],
                    s["monitored_sec"],
                    s["avg_wall_w"],
                    s["peak_wall_w"],
                    s["wall_kwh"],
                    s["system_kwh"],
                    s["cost_idr"],
                    s["equiv_battery_cost_idr"],
                    tariff,
                ]
            )
        return buf.getvalue()
