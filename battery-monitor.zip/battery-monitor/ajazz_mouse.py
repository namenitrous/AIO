"""AJAZZ AJ159 Pro gaming mouse controller for Windows (2.4G 8K dongle & USB-C).

Uses pure Python stdlib (`ctypes` + Win32 SetupAPI/HID via `win32_hid`) with zero
third-party dependencies. Targets the AJ-series HID Feature Report protocol on
Usage Page `0xFFFF` / Usage `0x0002` (65-byte unnumbered Feature Reports on Windows,
Report ID `0x00` prefix + 64-byte payload ending with BIT7 checksum `sum(1..63) & 0x7F`):
  - Battery telemetry: `SET_FEATURE 0xF7` status poll -> settle -> `GET_FEATURE 0x05`.
  - Polling rate (`0x04`): 125 / 250 / 500 / 1000 / 2000 / 4000 / 8000 Hz.
  - Sensor, power & indicator settings (`0x53`): LOD, Motion Sync, Angle Snap,
    Power Save, debounce, sleep timers, and high/low battery indicator LED colors.
  - DPI table (`0x54`): up to 8 DPI stages (50-42000 DPI, step 50) + indicator RGB.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import struct
import threading
import time
from typing import Callable

from win32_hid import (
    clamp,
    enumerate_hid_interfaces,
    format_hex_color,
    get_feature_report,
    open_hid_handle,
    parse_hex_color,
    set_feature_report,
)

VID_AJAZZ_MOUSE = 0x3151

MOUSE_PIDS: dict[int, dict] = {
    0x4026: {"link": "2.4g", "label": "AJ159 2.4G", "max_hz": 4000},
    0x4027: {"link": "2.4g", "label": "AJ159 Dongle", "max_hz": 4000},
    0x402D: {"link": "2.4g", "label": "AJAZZ 2.4G 8K", "max_hz": 8000},
    0x5007: {"link": "2.4g", "label": "AJ159 8K Dock", "max_hz": 8000},
    0x5008: {"link": "usb", "label": "AJ159 Wired", "max_hz": 1000},
}

USAGE_PAGE_MOUSE_CTRL = 0xFFFF
USAGE_MOUSE_CTRL = 0x0002
MOUSE_REPORT_SIZE = 65

POLL_RATES: tuple[int, ...] = (125, 250, 500, 1000, 2000, 4000, 8000)
_RATE_TO_CODE: dict[int, int] = {
    125: 0x08,
    250: 0x04,
    500: 0x02,
    1000: 0x01,
    2000: 0x84,
    4000: 0x82,
    8000: 0x81,
}

LOD_OPTIONS: tuple[dict, ...] = (
    {"id": 0, "label": "1 mm"},
    {"id": 1, "label": "2 mm"},
    {"id": 2, "label": "3 mm"},
)

DPI_MIN = 50
DPI_MAX = 42000
DPI_STEP = 50
MAX_DPI_STAGES = 8

CMD_SET_REPORT_RATE = 0x04
CMD_SET_PROFILE = 0x02
CMD_SET_COUNTDOWN = 0x0B
CMD_SET_LOW_LATENCY = 0x0C
CMD_SET_24G_TRUE_8K = 0x0D
CMD_SET_LOD = 0x11
CMD_SET_ANGLE_SNAP = 0x12
CMD_SET_WAVE_REPAIR = 0x13
CMD_SET_MOTION_SYNC = 0x14
CMD_MOUSE_SET_OPTION0 = 0x53
CMD_MOUSE_SET_OPTION1 = 0x54
CMD_MOUSE_GET_OPTION0 = 0xD3
CMD_MOUSE_GET_OPTION1 = 0xD4
CMD_TARGET_SELECT = 0xF6
CMD_STATUS_POLL = 0xF7
CMD_NOTICE_READ = 0xFC

DEFAULT_DPI_STAGES: tuple[dict, ...] = (
    {"dpi": 400, "color": "#ff3b30"},
    {"dpi": 800, "color": "#ff9500"},
    {"dpi": 1200, "color": "#00e640"},
    {"dpi": 1600, "color": "#00e5ff"},
    {"dpi": 3200, "color": "#1a73e8"},
    {"dpi": 6400, "color": "#8b3dff"},
    {"dpi": 12800, "color": "#ffffff"},
    {"dpi": 26000, "color": "#ff2d55"},
)


def _default_mouse_state_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "BatteryMonitor" / "ajazz_mouse.json"


def _default_settings() -> dict:
    return {
        "profile": 0,
        "poll_rate_hz": 1000,
        "active_dpi_stage": 2,
        "stage_count": 6,
        "dpi_stages": [dict(s) for s in DEFAULT_DPI_STAGES],
        "lod": 0,
        "debounce_ms": 1,
        "motion_sync": True,
        "angle_snap": False,
        "power_save": False,
        "sleep_idle_s": 60,
        "sleep_deep_s": 300,
        "battery_led_high": "#00e640",
        "battery_led_low": "#ff2a2a",
        "charging_led": True,
        "updated_at": None,
    }


def _stamp_bit7_checksum(pkt: bytearray) -> bytes:
    """Stamp RongYuan / MicLink Bit7 checksum at pkt[8] (index 7 of 64-byte payload)."""
    pkt[8] = (255 - sum(pkt[1:8])) & 0xFF
    return bytes(pkt)


def build_battery_poll_packet() -> bytes:
    """Build the 65-byte `0xF7` status poll packet for Windows MI_02 Feature Report."""
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_STATUS_POLL
    return bytes(pkt)


def parse_battery_frame(frame: bytes) -> dict | None:
    """Parse `GET_FEATURE(0x05)` battery response into `percent` + `link_up`, or None."""
    if not frame:
        return None
    if len(frame) >= 8 and frame[0] in (0x00, 0x05):
        if frame[1] != 0x00 or frame[2] != 0x00:
            return None
        charge = frame[3]
        flags = frame[4:8]
    elif len(frame) >= 7 and len(frame) == 64 and frame[0] == 0x00 and frame[1] == 0x00:
        charge = frame[2]
        flags = frame[3:7]
    else:
        return None

    link_up = any(b != 0 for b in flags)
    if charge == 0 or charge > 100 or not link_up:
        return None
    return {
        "percent": int(charge),
        "link_up": True,
        "status_hex": bytes(flags).hex(),
    }


def build_set_poll_rate_packet(profile: int, poll_rate_hz: int) -> bytes:
    """Build opcode `0x04` polling rate packet using `_RATE_TO_CODE`."""
    hz = int(poll_rate_hz)
    if hz not in _RATE_TO_CODE:
        raise ValueError(f"Unsupported polling rate: {poll_rate_hz} Hz")
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_SET_REPORT_RATE
    pkt[2] = clamp(profile, 0, 7)
    pkt[3] = _RATE_TO_CODE[hz]
    return _stamp_bit7_checksum(pkt)


def build_set_motion_sync_packet(motion_sync: bool) -> bytes:
    """Build opcode `0x14` dedicated Motion Sync packet."""
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_SET_MOTION_SYNC
    pkt[2] = 1 if motion_sync else 0
    return _stamp_bit7_checksum(pkt)


def build_set_angle_snap_packet(angle_snap: bool) -> bytes:
    """Build opcode `0x12` dedicated Angle Snap (line repair) packet."""
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_SET_ANGLE_SNAP
    pkt[2] = 1 if angle_snap else 0
    return _stamp_bit7_checksum(pkt)


def build_set_lod_packet(lod: int) -> bytes:
    """Build opcode `0x11` dedicated LOD (silent height) packet."""
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_SET_LOD
    pkt[2] = clamp(int(lod), 0, 2)
    return _stamp_bit7_checksum(pkt)


def build_set_dpi_table_packet(
    profile: int,
    active_stage: int,
    stage_count: int,
    dpi_stages: list[dict],
) -> bytes:
    """Build opcode `0x54` atomic 8-stage DPI table (X DPI + Y DPI) + indicator color packet."""
    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_MOUSE_SET_OPTION1
    pkt[2] = clamp(profile, 0, 7)
    pkt[3] = clamp(active_stage, 0, MAX_DPI_STAGES - 1)
    pkt[4] = clamp(stage_count, 1, MAX_DPI_STAGES)
    _stamp_bit7_checksum(pkt)

    for idx in range(min(MAX_DPI_STAGES, len(dpi_stages))):
        stage = dpi_stages[idx]
        dpi = clamp(round(int(stage["dpi"]) / DPI_STEP) * DPI_STEP, DPI_MIN, DPI_MAX)
        struct.pack_into("<H", pkt, 9 + idx * 2, dpi)
        struct.pack_into("<H", pkt, 25 + idx * 2, dpi)
        r, g, b = parse_hex_color(stage["color"])
        base = 41 + idx * 3
        if base + 2 < MOUSE_REPORT_SIZE:
            pkt[base] = r
            pkt[base + 1] = g
            pkt[base + 2] = b

    return bytes(pkt)


def build_set_option0_packet(settings: dict) -> bytes:
    """Build opcode `0x53` omnibus mouse sensor, sleep, and battery-LED settings packet."""
    hz = int(settings["poll_rate_hz"])
    if hz not in _RATE_TO_CODE:
        raise ValueError(f"Unsupported polling rate: {hz} Hz")

    pkt = bytearray(MOUSE_REPORT_SIZE)
    pkt[0] = 0x00
    pkt[1] = CMD_MOUSE_SET_OPTION0
    _stamp_bit7_checksum(pkt)

    pkt[9] = clamp(settings["profile"], 0, 7)
    pkt[10] = _RATE_TO_CODE[hz]
    pkt[11] = clamp(settings["debounce_ms"], 0, 10)

    flags = 0
    if settings.get("motion_sync", True):
        flags |= 1 << 2  # Wave repair / Motion sync
    flags |= 1 << 3  # Enable battery indicator LED color mapping
    if settings.get("power_save", False):
        flags |= 1 << 4
    struct.pack_into("<H", pkt, 13, flags)

    pkt[18] = 255
    pkt[19] = 8

    idle_s = clamp(settings["sleep_idle_s"], 10, 3600)
    deep_s = clamp(max(settings["sleep_deep_s"], idle_s), 10, 7200)
    struct.pack_into("<H", pkt, 41, idle_s)
    struct.pack_into("<H", pkt, 43, deep_s)
    struct.pack_into("<H", pkt, 45, idle_s)
    struct.pack_into("<H", pkt, 47, deep_s)

    pkt[51] = 100  # X sensitivity 100%
    pkt[52] = 100  # Y sensitivity 100%
    pkt[53] = clamp(settings["lod"], 0, 2)
    pkt[54] = 1 if settings.get("angle_snap", False) else 0

    hr, hg, hb = parse_hex_color(settings["battery_led_high"])
    lr, lg, lb = parse_hex_color(settings["battery_led_low"])
    pkt[55], pkt[56], pkt[57] = hr, hg, hb
    pkt[58], pkt[59], pkt[60] = lr, lg, lb
    pkt[61] = 1 if settings.get("charging_led", True) else 0
    return bytes(pkt)


def detect_ajazz_mouse() -> dict | None:
    """Detect connected AJAZZ AJ159 Pro mouse / 8K dongle HID control collection."""
    interfaces = enumerate_hid_interfaces(VID_AJAZZ_MOUSE)
    sorted_ifaces = sorted(
        interfaces,
        key=lambda d: 0 if MOUSE_PIDS.get(d["pid"], {}).get("link") == "usb" else 1,
    )
    for dev in sorted_ifaces:
        meta = MOUSE_PIDS.get(dev["pid"])
        if (
            meta
            and dev["usage_page"] == USAGE_PAGE_MOUSE_CTRL
            and dev["usage"] == USAGE_MOUSE_CTRL
            and dev["feat_len"] == MOUSE_REPORT_SIZE
        ):
            return {**dev, **meta}
    return None


def read_mouse_battery(device: dict) -> dict | None:
    """Query live battery percent from AJ159 Pro over Feature Reports (`0xF7` -> `0x05`)."""
    try:
        with open_hid_handle(device["path"], label="AJAZZ Mouse HID") as (handle, hid, _):
            set_feature_report(handle, hid, build_battery_poll_packet(), context="AJAZZ Mouse Battery Poll")
            time.sleep(0.04)
            raw = get_feature_report(handle, hid, 0x05, size=MOUSE_REPORT_SIZE, context="AJAZZ Mouse Battery Read")
            return parse_battery_frame(raw)
    except OSError:
        return None


def read_mouse_hardware_dpi(device: dict) -> dict | None:
    """Read live 8-stage DPI table and active DPI stage from connected mouse hardware."""
    try:
        with open_hid_handle(device["path"], label="AJAZZ Mouse HID") as (handle, hid, _):
            is_dongle = device.get("link") == "2.4g" or device.get("pid") in (0x4026, 0x4027, 0x402D, 0x5007)
            if is_dongle:
                # Flush unread pending buffer if present
                try:
                    raw_poll = bytearray(MOUSE_REPORT_SIZE)
                    raw_poll[1] = CMD_STATUS_POLL
                    set_feature_report(handle, hid, bytes(raw_poll))
                    time.sleep(0.015)
                    st = get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
                    if st and len(st) > 1 and st[1] == 1:
                        raw_fc = bytearray(MOUSE_REPORT_SIZE)
                        raw_fc[1] = CMD_NOTICE_READ
                        set_feature_report(handle, hid, bytes(raw_fc))
                        time.sleep(0.015)
                        get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
                except OSError:
                    pass

                target_pkt = bytearray(MOUSE_REPORT_SIZE)
                target_pkt[1] = CMD_TARGET_SELECT
                target_pkt[2] = 0x05
                set_feature_report(handle, hid, bytes(target_pkt), context="AJAZZ Target Select")
                time.sleep(0.02)

            cmd = bytearray(MOUSE_REPORT_SIZE)
            cmd[1] = CMD_MOUSE_GET_OPTION1
            cmd[2] = 0x00  # profile 0
            _stamp_bit7_checksum(cmd)
            set_feature_report(handle, hid, bytes(cmd), context="AJAZZ Get DPI")

            if is_dongle:
                for _ in range(15):
                    time.sleep(0.03)
                    poll_pkt = bytearray(MOUSE_REPORT_SIZE)
                    poll_pkt[1] = CMD_STATUS_POLL
                    set_feature_report(handle, hid, bytes(poll_pkt))
                    time.sleep(0.015)
                    st = get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
                    if st and len(st) > 1 and st[1] == 1:
                        break
                notice_pkt = bytearray(MOUSE_REPORT_SIZE)
                notice_pkt[1] = CMD_NOTICE_READ
                set_feature_report(handle, hid, bytes(notice_pkt))
                time.sleep(0.02)

            res = get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
            if not res or len(res) < 65:
                return None
            payload = res[1:]
            if payload[0] != CMD_MOUSE_GET_OPTION1:
                return None

            active_stage = clamp(payload[2], 0, MAX_DPI_STAGES - 1)
            stage_count = clamp(payload[3], 1, MAX_DPI_STAGES)
            stages = []
            for i in range(MAX_DPI_STAGES):
                dpi_x = struct.unpack("<H", payload[8 + i * 2 : 10 + i * 2])[0]
                if dpi_x == 0:
                    dpi_x = DEFAULT_DPI_STAGES[i]["dpi"]
                r = payload[40 + i * 3]
                g = payload[41 + i * 3]
                b = payload[42 + i * 3]
                stages.append({
                    "dpi": dpi_x,
                    "color": format_hex_color(r, g, b),
                })
            return {
                "active_dpi_stage": active_stage,
                "stage_count": stage_count,
                "dpi_stages": stages,
            }
    except Exception:
        return None


def send_mouse_settings_to_hardware(device: dict, settings: dict) -> None:
    """Send polling rate, sensor/power, dedicated Motion Sync/LOD/Angle Snap, and DPI table."""
    packets = [
        ("MotionSync", build_set_motion_sync_packet(settings.get("motion_sync", True))),
        ("AngleSnap", build_set_angle_snap_packet(settings.get("angle_snap", False))),
        ("LOD", build_set_lod_packet(settings.get("lod", 0))),
        ("PollRate", build_set_poll_rate_packet(settings["profile"], settings["poll_rate_hz"])),
        ("Option0", build_set_option0_packet(settings)),
        (
            "DpiTable",
            build_set_dpi_table_packet(
                settings["profile"],
                settings["active_dpi_stage"],
                settings["stage_count"],
                settings["dpi_stages"],
            ),
        ),
    ]

    is_dongle = device.get("link") == "2.4g" or device.get("pid") in (0x4026, 0x4027, 0x402D, 0x5007)
    with open_hid_handle(device["path"], label="AJAZZ Mouse HID") as (handle, hid, _):
        if is_dongle:
            # Flush unread pending buffer if present
            try:
                raw_poll = bytearray(MOUSE_REPORT_SIZE)
                raw_poll[1] = CMD_STATUS_POLL
                set_feature_report(handle, hid, bytes(raw_poll), context="Flush Poll")
                time.sleep(0.015)
                st = get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
                if st and len(st) > 1 and st[1] == 1:
                    raw_fc = bytearray(MOUSE_REPORT_SIZE)
                    raw_fc[1] = CMD_NOTICE_READ
                    set_feature_report(handle, hid, bytes(raw_fc), context="Notice Read")
                    time.sleep(0.015)
                    get_feature_report(handle, hid, 0, MOUSE_REPORT_SIZE)
            except OSError:
                pass

        target_pkt = bytearray(MOUSE_REPORT_SIZE)
        target_pkt[1] = CMD_TARGET_SELECT
        target_pkt[2] = 0x05  # target mouse endpoint

        for name, pkt in packets:
            if is_dongle:
                try:
                    set_feature_report(handle, hid, bytes(target_pkt), context="AJAZZ Mouse Target Select")
                    time.sleep(0.02)
                except OSError:
                    pass
            set_feature_report(handle, hid, pkt, context=f"AJAZZ Mouse {name}")
            time.sleep(0.03)


class AjazzMouseController:
    """Thread-safe state manager, battery reader, and hardware dispatcher for AJ159 Pro."""

    def __init__(
        self,
        state_path: Path | None = None,
        detect_fn: Callable[[], dict | None] = detect_ajazz_mouse,
        battery_fn: Callable[[dict], dict | None] = read_mouse_battery,
        send_fn: Callable[[dict, dict], None] = send_mouse_settings_to_hardware,
    ) -> None:
        self._lock = threading.Lock()
        self._state_path = Path(state_path) if state_path else _default_mouse_state_path()
        self._detect_fn = detect_fn
        self._battery_fn = battery_fn
        self._send_fn = send_fn
        self._settings = self._load_initial_settings()
        self._last_battery: dict | None = None
        self._last_battery_ts: float = 0.0

    def _load_initial_settings(self) -> dict:
        base = _default_settings()
        if self._state_path.is_file():
            try:
                data = json.loads(self._state_path.read_text(encoding="utf-8"))
                return self._validate_settings(data, base=base)
            except Exception:
                pass
        try:
            dev = self._detect_fn()
            if dev:
                hw_dpi = read_mouse_hardware_dpi(dev)
                if hw_dpi:
                    base = self._validate_settings(hw_dpi, base=base)
        except Exception:
            pass
        return base

    def _save_settings(self) -> None:
        try:
            self._state_path.parent.mkdir(parents=True, exist_ok=True)
            self._state_path.write_text(json.dumps(self._settings, indent=2), encoding="utf-8")
        except OSError:
            pass

    @staticmethod
    def _validate_settings(payload: dict, base: dict) -> dict:
        merged = {
            **base,
            "dpi_stages": [dict(s) for s in base["dpi_stages"]],
        }

        if "profile" in payload:
            merged["profile"] = clamp(int(payload["profile"]), 0, 7)

        if "poll_rate_hz" in payload:
            hz = int(payload["poll_rate_hz"])
            if hz not in _RATE_TO_CODE:
                raise ValueError(f"Unsupported polling rate: {hz} Hz")
            merged["poll_rate_hz"] = hz

        if "stage_count" in payload:
            merged["stage_count"] = clamp(int(payload["stage_count"]), 1, MAX_DPI_STAGES)

        if "dpi_stages" in payload:
            raw_stages = payload["dpi_stages"]
            if not isinstance(raw_stages, list) or not raw_stages:
                raise ValueError("dpi_stages must be a non-empty list")
            normalized: list[dict] = []
            for idx in range(MAX_DPI_STAGES):
                src = raw_stages[idx] if idx < len(raw_stages) else merged["dpi_stages"][idx]
                dpi_val = clamp(round(int(src["dpi"]) / DPI_STEP) * DPI_STEP, DPI_MIN, DPI_MAX)
                r, g, b = parse_hex_color(str(src.get("color", merged["dpi_stages"][idx]["color"])))
                normalized.append({"dpi": dpi_val, "color": format_hex_color(r, g, b)})
            merged["dpi_stages"] = normalized

        if "active_dpi_stage" in payload:
            merged["active_dpi_stage"] = clamp(
                int(payload["active_dpi_stage"]), 0, merged["stage_count"] - 1
            )
        else:
            merged["active_dpi_stage"] = clamp(
                merged["active_dpi_stage"], 0, merged["stage_count"] - 1
            )

        if "lod" in payload:
            merged["lod"] = clamp(int(payload["lod"]), 0, 2)

        if "debounce_ms" in payload:
            merged["debounce_ms"] = clamp(int(payload["debounce_ms"]), 0, 10)

        for flag_key in ("motion_sync", "angle_snap", "power_save", "charging_led"):
            if flag_key in payload:
                merged[flag_key] = bool(payload[flag_key])

        if "sleep_idle_s" in payload:
            merged["sleep_idle_s"] = clamp(int(payload["sleep_idle_s"]), 10, 3600)

        if "sleep_deep_s" in payload:
            merged["sleep_deep_s"] = clamp(
                max(int(payload["sleep_deep_s"]), merged["sleep_idle_s"]), 10, 7200
            )
        elif merged["sleep_deep_s"] < merged["sleep_idle_s"]:
            merged["sleep_deep_s"] = merged["sleep_idle_s"]

        for color_key in ("battery_led_high", "battery_led_low"):
            if color_key in payload:
                r, g, b = parse_hex_color(str(payload[color_key]))
                merged[color_key] = format_hex_color(r, g, b)

        if "updated_at" in payload:
            merged["updated_at"] = payload["updated_at"]

        return merged

    def get_state(self, force_battery: bool = False) -> dict:
        device = self._detect_fn()
        battery = None
        if device is not None and device.get("link") != "usb":
            now = time.time()
            with self._lock:
                cached = self._last_battery
                age = now - self._last_battery_ts
            if force_battery or cached is None or age > 10.0:
                fresh = self._battery_fn(device)
                with self._lock:
                    if fresh is not None:
                        self._last_battery = fresh
                        self._last_battery_ts = now
                    battery = self._last_battery
            else:
                battery = cached
        elif device is None:
            with self._lock:
                self._last_battery = None
                self._last_battery_ts = 0.0

        with self._lock:
            settings = {
                **self._settings,
                "dpi_stages": [dict(s) for s in self._settings["dpi_stages"]],
            }

        device_summary = None
        if device:
            device_summary = {
                "link": device["link"],
                "label": device["label"],
                "vid": f"{device['vid']:04X}",
                "pid": f"{device['pid']:04X}",
                "max_hz": int(device.get("max_hz", 8000)),
            }

        return {
            "connected": device is not None,
            "device": device_summary,
            "battery": battery,
            "settings": settings,
            "poll_rates": list(POLL_RATES),
            "lod_options": list(LOD_OPTIONS),
        }

    def apply_settings(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")
        with self._lock:
            next_settings = self._validate_settings(payload, base=self._settings)
            device = self._detect_fn()
            if device is None:
                raise LookupError(
                    "AJAZZ AJ159 Pro not detected. Connect the 2.4G 8K receiver or USB cable."
                )
            max_hz = int(device.get("max_hz", 8000))
            if next_settings["poll_rate_hz"] > max_hz:
                next_settings["poll_rate_hz"] = max_hz
            self._send_fn(device, next_settings)
            next_settings["updated_at"] = time.time()
            self._settings = next_settings
            self._save_settings()
        return self.get_state(force_battery=False)
